"""Local browser UI for Ozon campaigns. Run: python web_app.py --open-browser."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import threading
import time
from urllib.parse import urlsplit
import webbrowser

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from ozon_strategy import (Product, SellerAPI, StrategyError, StrategyService, batches,
                           ensure_strategy, identifier, list_strategies, number, write_json)
from web_demo import make_demo_api


ROOT = Path(__file__).resolve().parent
APP_VERSION = "0.2.2"
USER_DEFAULTS = {"2369234990": {"min_price": "2700", "wb_url": "https://www.wildberries.ru/catalog/386265183/detail.aspx"}}


class BrowserSession:
    def __init__(self):
        self.token, self.csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        self.api, self.mode, self.account = make_demo_api(), "demo", ""
        self.catalog, self.strategies, self.campaigns = {}, [], {}
        self.selected_id, self.setup_state, self.cycle_states = "", {}, {}
        self.jobs, self.busy, self.last_used = {}, False, time.monotonic()
        self.lock = threading.RLock()


def create_app(*, state_dir=None):
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "testserver", "[::1]"])
    sessions, account_locks = {}, {}
    global_lock = threading.Lock()
    pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ozon-web")
    state_dir = Path(state_dir or ROOT / ".local" / "web-state")
    app.state.sessions = sessions

    def session(request, *, mutation=False):
        value = request.cookies.get("ge_session")
        s = sessions.get(value)
        if s is None:
            raise HTTPException(401, "Обновите страницу для создания локальной сессии.")
        s.last_used = time.monotonic()
        if mutation:
            if not secrets.compare_digest(request.headers.get("x-csrf-token", ""), s.csrf):
                raise HTTPException(403, "Обновите страницу: токен формы устарел.")
            origin = request.headers.get("origin")
            if origin and urlsplit(origin).netloc.lower() != request.headers.get("host", "").lower():
                raise HTTPException(403, "Запрос с другого сайта запрещён.")
        return s

    def account_lock(s):
        key = s.account if s.mode == "live" else s.token
        with global_lock:
            return account_locks.setdefault(key, threading.RLock())

    def save(s):
        if s.mode == "live":
            write_json(state_dir / (s.account + ".json"), {
                "selected_id": s.selected_id, "campaigns": {
                    k: {"products": v.get("products", [])} for k, v in s.campaigns.items()},
                "setup_state": s.setup_state, "cycle_states": s.cycle_states})

    def info(s):
        campaign = s.campaigns.get(s.selected_id, {})
        strategies = [dict(row) for row in s.strategies]
        for row in strategies:
            row["membership_verified"] = False
            if row["id"] == s.selected_id and campaign.get("report") is not None:
                row["reported_products_count"] = row.get("products_count")
                row["products_count"] = campaign["report"]["member_count"]
                row["membership_verified"] = True
        return {"version": APP_VERSION, "mode": s.mode, "selected_id": s.selected_id, "strategies": strategies,
                "catalog": list(s.catalog.values()), "products": campaign.get("products", []),
                "report": campaign.get("report"), "configuration_issue": campaign.get("configuration_issue"),
                "busy": s.busy, "scheduled": False}

    def load_catalog(s):
        ids, last_id = [], ""
        for _ in range(100):
            data = s.api.post("/v3/product/list", {"filter": {"visibility": "ALL"}, "last_id": last_id, "limit": 1000}).get("result", {})
            rows = data.get("items")
            if not isinstance(rows, list):
                raise StrategyError("Нет списка товаров Ozon.")
            page_ids = [identifier(r["product_id"]) for r in rows]
            if set(ids) & set(page_ids):
                raise StrategyError("Повторилась страница каталога.")
            ids.extend(page_ids)
            cursor = data.get("last_id") or ""
            if not rows or len(rows) < 1000 or not cursor:
                break
            if cursor == last_id:
                raise StrategyError("Не меняется курсор каталога.")
            last_id = cursor
        else:
            raise StrategyError("Каталог слишком большой для тестового режима.")
        s.catalog = {}
        load_product_ids(s, ids)

    def load_product_ids(s, ids):
        for group in batches(ids, 1000):
            meta = s.api.post("/v3/product/info/list", {"product_id": group}).get("items", [])
            prices = s.api.post("/v5/product/info/prices", {"filter": {"product_id": group, "visibility": "ALL"}, "limit": 1000}).get("items", [])
            by_id = {str(p["product_id"]): p for p in prices}
            for item in meta:
                sku = item.get("sku") or next((p.get("sku") for p in item.get("sources") or [] if p.get("sku")), None)
                if not sku:
                    continue
                sku = identifier(sku)
                detail = by_id.get(str(item["id"]), {})
                price = detail.get("price") or {}
                own = (detail.get("price_indexes") or {}).get("self_marketplaces_index_data") or {}
                default = USER_DEFAULTS.get(sku, {})
                s.catalog[sku] = {"sku": sku, "product_id": str(item["id"]), "offer_id": item.get("offer_id"),
                    "name": item.get("name"), "ozon_price": price.get("price"), "saved_min_price": price.get("min_price"),
                    "price_index": own.get("price_index_value"), "wb_url": default.get("wb_url", "")}
                if s.mode == "demo":
                    s.catalog[sku]["wb_url"] = s.api.products[str(item["id"])]["url"]

    def set_products(s, payload):
        if not isinstance(payload, list) or len(payload) > 2000:
            raise ValueError("Некорректный список товаров.")
        result = [Product(sku=p["sku"], min_price=p["min_price"], wb_url=p.get("wb_url", ""),
                          selected=p.get("selected", False)) for p in payload]
        if len({p.sku for p in result}) != len(result):
            raise ValueError("SKU не должны повторяться.")
        return result

    def service(s, sid=None):
        sid = sid or s.selected_id
        if not sid:
            raise ValueError("Сначала выберите или создайте кампанию.")
        return StrategyService(s.api, sid)

    def select(s, sid):
        current = service(s, sid)
        current.strategy()  # Verify that this is a custom, WB-only strategy.
        members = current.members()
        known_ids = {r["product_id"] for r in s.catalog.values()}
        load_product_ids(s, sorted(members - known_ids))
        campaign = s.campaigns.setdefault(sid, {"products": []})
        products = {p["sku"]: p for p in campaign["products"]}
        for row in s.catalog.values():
            if row["product_id"] in members and row["sku"] not in products:
                products[row["sku"]] = {"sku": row["sku"], "selected": True,
                    "min_price": str(row.get("saved_min_price") or ""), "wb_url": row.get("wb_url", "")}
        campaign["products"] = list(products.values())
        s.selected_id = sid
        try:
            campaign["report"] = current.snapshot(set_products(s, campaign["products"]))
            campaign.pop("configuration_issue", None)
        except ValueError as error:
            campaign["report"] = None
            campaign["configuration_issue"] = str(error)
        save(s)

    def load(s):
        s.strategies = [r for r in list_strategies(s.api) if r.get("type") in {None, "COMP_PRICE"}]
        load_catalog(s)
        available = {r["id"] for r in s.strategies}
        if s.selected_id in available:
            select(s, s.selected_id)
        elif available:
            s.selected_id = ""
            for row in s.strategies:
                try:
                    select(s, row["id"])
                    break
                except StrategyError:
                    continue
        else:
            s.selected_id = ""

    def operate(s, payload, job):
        action = payload.get("action")
        job["message"] = "Читаем данные Ozon…" if s.mode == "live" else "Обрабатываем демонстрационные данные…"
        if action == "connect":
            cid, key = str(payload.get("client_id", "")).strip(), str(payload.get("api_key", "")).strip()
            if not cid or not key or len(cid) > 80 or len(key) > 2048:
                raise ValueError("Введите Client-Id и API-ключ.")
            api = SellerAPI(cid, key)
            list_strategies(api)  # Validate access before replacing the current session.
            s.api, s.mode = api, "live"
            s.catalog, s.strategies = {}, []
            s.account = hashlib.sha256(cid.encode()).hexdigest()
            path = state_dir / (s.account + ".json")
            old = json.loads(path.read_text()) if path.exists() else {}
            s.campaigns, s.setup_state, s.cycle_states = old.get("campaigns", {}), old.get("setup_state", {}), old.get("cycle_states", {})
            s.selected_id = old.get("selected_id", "")
            payload.pop("api_key", None)
            load(s)
        elif action == "demo":
            s.api, s.mode, s.account = make_demo_api(), "demo", ""
            s.campaigns, s.setup_state, s.cycle_states, s.selected_id = {}, {}, {}, ""
            load(s)
        elif action == "load":
            load(s)
        elif action == "select":
            select(s, str(payload.get("strategy_id", "")))
        elif action == "create":
            products = set_products(s, payload.get("products", []))
            if not any(p.selected for p in products) or any(p.selected and not p.wb_url for p in products):
                raise ValueError("Отметьте товары и укажите ограничения и ожидаемые WB-ссылки.")
            job["message"] = "Создаём кампанию и сохраняем её ID…"
            current = ensure_strategy(s.api, strategy_name=payload.get("name", ""),
                initial_coefficient=payload.get("coefficient", "0.960"), state=s.setup_state, persist=lambda _: save(s))
            s.selected_id = current.strategy_id
            s.campaigns.setdefault(current.strategy_id, {})["products"] = [asdict(p) for p in products]
            save(s)
            job["message"] = "ID сохранён. Устанавливаем ограничения, добавляем товары, включаем и проверяем WB…"
            report = current.apply_selection(products)
            s.campaigns[current.strategy_id]["report"] = report
            s.strategies = [r for r in list_strategies(s.api) if r.get("type") in {None, "COMP_PRICE"}]
            save(s)
        else:
            sid = str(payload.get("strategy_id") or s.selected_id)
            if sid != s.selected_id:
                raise ValueError("Выбранная кампания изменилась. Обновите страницу.")
            current = service(s, sid)
            campaign = s.campaigns.setdefault(sid, {})
            products = set_products(s, payload.get("products", campaign.get("products", [])))
            campaign["products"] = [asdict(p) for p in products]
            save(s)
            if action == "apply":
                job["message"] = "Сохраняем ограничения и состав, затем проверяем WB-ссылки…"
                report = current.apply_selection(products)
            elif action == "verify":
                job["message"] = "Проверяем WB-ссылки. Неверный товар будет исключён отдельно…"
                report = current.verify(products)
            elif action == "coefficient":
                report = current.snapshot(products)
                if not report["ready"]:
                    campaign["report"] = report
                    raise StrategyError("До изменения коэффициента подтвердите состав, ограничения и WB-ссылки.")
                pending = {"old_coefficient": report["coefficient"], "new_coefficient": str(payload.get("coefficient")),
                           "baseline": current._baseline(report), "created_at": datetime.now(timezone.utc).isoformat()}
                # Validate the business bounds before persisting an intent.
                value, previous = number(pending["new_coefficient"]), number(report["coefficient"])
                if not current.policy.coefficient_min <= value <= current.policy.coefficient_max or abs(value - previous) > current.policy.max_step:
                    raise ValueError("Коэффициент 0,94–1,00; изменение за шаг не более 0,002.")
                s.cycle_states.setdefault(sid, {})["pending"] = pending
                save(s)
                current.change_coefficient(value, expected_current=previous,
                    expected_members=[r["product_id"] for r in report["rows"] if r["in_strategy"]])
                report = current.snapshot(products)
            elif action == "plan":
                report = current.snapshot(products)
                job["plan"] = current.plan(report)
            elif action == "cycle":
                if payload.get("metric_confirmed") is not True:
                    raise ValueError("Для коррекции сначала подтвердите сверку индекса с AJ.")
                state = s.cycle_states.setdefault(sid, {})
                result = current.cycle(products, state, write=True, metric_confirmed=True, persist=lambda _: save(s))
                job["plan"] = result["plan"]
                report = current.snapshot(products) if result["coefficient_written"] else result["snapshot"]
            elif action == "refresh":
                report = current.snapshot(products)
            else:
                raise ValueError("Неизвестная операция.")
            campaign["report"] = report
            campaign.pop("configuration_issue", None)
            save(s)
        job["message"] = "Готово. Данные обновлены."

    def run_job(s, payload, job):
        try:
            with s.lock, account_lock(s):
                operate(s, payload, job)
            job["status"] = "done"
        except (StrategyError, ValueError, KeyError, OSError) as error:
            job["error"] = str(error)
            job["message"] = "Читаем фактическое состояние после ошибки…"
            # Keep a just-created campaign visible after a partial failure.
            try:
                s.strategies = [r for r in list_strategies(s.api) if r.get("type") in {None, "COMP_PRICE"}]
            except Exception:
                pass
            if s.selected_id and s.selected_id in s.campaigns:
                try:
                    campaign = s.campaigns[s.selected_id]
                    campaign["report"] = service(s).snapshot(set_products(s, campaign.get("products", [])))
                except Exception:
                    # A failed diagnostic read must not hide the original error or leave the job running.
                    pass
            job["status"] = "error"
        except Exception:
            job["status"], job["error"] = "error", "Внутренняя ошибка. Обновите данные перед повтором операции."
        finally:
            payload.pop("api_key", None)
            s.busy = False

    @app.get("/")
    def index():
        return FileResponse(ROOT / "web_static" / "index.html")

    @app.get("/api/session")
    def get_session(request: Request):
        s = sessions.get(request.cookies.get("ge_session"))
        if s is None:
            with global_lock:
                for key, value in list(sessions.items()):
                    if not value.busy and time.monotonic() - value.last_used > 8 * 3600:
                        del sessions[key]
                if len(sessions) >= 50:
                    raise HTTPException(503, "Слишком много сессий. Перезапустите локальный сервер.")
                s = BrowserSession()
                sessions[s.token] = s
        response = JSONResponse({"csrf": s.csrf, "state": info(s)})
        response.set_cookie("ge_session", s.token, httponly=True, samesite="strict", max_age=8 * 3600)
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/api/state")
    def get_state(request: Request):
        return info(session(request))

    @app.get("/api/diagnostics")
    def diagnostics(request: Request):
        s = session(request)
        report = s.campaigns.get(s.selected_id, {}).get("report")
        if report is None:
            raise HTTPException(400, "Сначала обновите данные выбранной кампании.")
        def clean(value):
            if isinstance(value, dict):
                return {key: clean(item) for key, item in value.items()
                        if str(key).lower().replace("-", "_") not in {"headers", "authorization", "api_key", "client_id"}}
            if isinstance(value, list):
                return [clean(item) for item in value]
            if isinstance(value, str) and hasattr(s.api, "_safe"):
                return s.api._safe(value)
            return value
        return JSONResponse(clean({"version": APP_VERSION, "mode": s.mode, "report": report,
                                   "writes": getattr(s.api, "audit_log", [])}),
            headers={"Content-Disposition": f'attachment; filename="ozon-diagnostics-{APP_VERSION}.json"'})

    @app.post("/api/jobs")
    def queue_job(payload: dict, request: Request):
        s = session(request, mutation=True)
        if len(json.dumps(payload)) > 1_000_000:
            raise HTTPException(413, "Слишком большой список.")
        if payload.get("action") not in {"connect", "demo", "load", "select", "create", "apply", "verify", "coefficient", "plan", "cycle", "refresh"}:
            raise HTTPException(400, "Неизвестная операция.")
        with global_lock:
            if s.busy:
                raise HTTPException(409, "Дождитесь текущей операции.")
            s.busy = True
            job = {"id": secrets.token_urlsafe(16), "status": "running", "message": "Задание принято…"}
            s.jobs[job["id"]] = job
            while len(s.jobs) > 20:
                del s.jobs[next(iter(s.jobs))]
        pool.submit(run_job, s, dict(payload), job)
        return JSONResponse({"job_id": job["id"]}, status_code=202)

    @app.get("/api/jobs/{job_id}")
    def get_job(job_id: str, request: Request):
        s = session(request)
        if job_id not in s.jobs:
            raise HTTPException(404, "Задание не найдено.")
        return s.jobs[job_id]

    @app.middleware("http")
    async def local_headers(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'"
        return response

    app.mount("/static", StaticFiles(directory=ROOT / "web_static"), name="static")
    return app


app = create_app()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open-browser", action="store_true")
    args = parser.parse_args()
    if args.open_browser:
        threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{args.port}")).start()
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=args.port, access_log=False)
