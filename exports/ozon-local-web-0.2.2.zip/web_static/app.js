"use strict";
const $ = id => document.getElementById(id);
let csrf = "", state = {}, edits = new Map(), memberOnly = false, newDraft = false, busy = false;
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt = (value, digits=0) => value === null || value === undefined || value === "" ? "—" : Number(value).toLocaleString("ru-RU", {minimumFractionDigits:digits, maximumFractionDigits:digits});
const dateFmt = value => value ? new Date(value).toLocaleString("ru-RU", {timeZone:"Asia/Novosibirsk"}) + " · Новосибирск" : "нет данных";
function notice(message, kind="") { $("notice").textContent=message; $("notice").className="notice " + kind; }
function setBusy(value) { busy=value; document.querySelectorAll("button,input,select").forEach(e=>e.disabled=value); if (!value) updateActionState(); }
function updateActionState() {
  const selected=Boolean(state.selected_id) && !newDraft;
  for (const id of ["apply-coefficient","coefficient","plan","verify","cycle","refresh"]) $(id).disabled=busy || !selected;
  $("download-diagnostics").disabled=busy || !currentReport();
  $("apply").textContent=newDraft ? "Создать и включить" : "Применить выбор";
}
async function request(path, options={}) {
  const response=await fetch(path, {...options, headers:{"Content-Type":"application/json", "X-CSRF-Token":csrf, ...(options.headers || {})}});
  let data; try { data=await response.json(); } catch { throw new Error("Сервер вернул неожиданный ответ. Проверьте окно Python."); }
  if (!response.ok) throw new Error(data.detail || "Ошибка запроса");
  return data;
}
function currentReport() { return newDraft ? null : state.report; }
function initEdits() {
  const stored=new Map((newDraft ? [] : state.products || []).map(p=>[String(p.sku),p]));
  edits=new Map((state.catalog || []).map(row=>{
    const old=stored.get(String(row.sku));
    return [String(row.sku), {sku:String(row.sku), selected:old?.selected || false,
      min_price:old?.min_price ?? (Number(row.saved_min_price)>0 ? String(row.saved_min_price) : ""),
      wb_url:old?.wb_url ?? row.wb_url ?? "", tracked:Boolean(old)}];
  }));
}
function collectProducts() {
  return [...edits.values()].filter(p=>p.selected || (!newDraft && p.tracked)).map(({sku,selected,min_price,wb_url})=>({sku,selected,min_price,wb_url}));
}
function safeLink(url) {
  try { const u=new URL(url); if (!["https:","http:"].includes(u.protocol) || !["wildberries.ru","www.wildberries.ru"].includes(u.hostname) || u.username || u.password) return esc(url); }
  catch { return esc(url); }
  return `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(url)}</a>`;
}
function renderTable() {
  const report=currentReport();
  const bySku=new Map((report?.rows || []).map(r=>[r.sku,r]));
  const query=$("search").value.toLowerCase().trim();
  const all=state.catalog || [];
  const rows=all.filter(row=> (!memberOnly || bySku.get(String(row.sku))?.in_strategy) &&
    (!query || [row.sku,row.offer_id,row.name].some(v=>String(v || "").toLowerCase().includes(query))));
  $("all-tab").textContent=`Все товары ${all.length}`;
  $("members-tab").textContent=`В кампании ${report?.member_count || 0}`;
  $("table-count").textContent=`Показано ${rows.length} из ${all.length}`;
  $("products").innerHTML=rows.length ? rows.map(row=>{
    const sku=String(row.sku), p=edits.get(sku), r=bySku.get(sku), member=r?.in_strategy;
    const linkStatus=r?.link_status;
    const linkLabel=linkStatus==="matched" ? "✓ Совпала" : linkStatus==="mismatch" ? "Другая карточка" : p.wb_url ? "Проверить" : "Указать ссылку";
    const linkClass=linkStatus==="matched" ? "green" : linkStatus==="mismatch" ? "red" : "amber";
    const saved=Number(p.min_price)>0 && Number(p.min_price)===Number(r?.saved_min_price ?? row.saved_min_price);
    const actualUrls=(r?.actual_wb_urls || []).map(safeLink).join("<br>") || "Нет данных — прочитайте после включения";
    return `<tr class="${member ? "member" : ""}" data-product="${esc(sku)}">
      <td><input type="checkbox" data-field="selected" data-sku="${esc(sku)}" aria-label="Вести SKU ${esc(sku)}" ${p.selected ? "checked" : ""}></td>
      <td><div class="product-name" title="${esc(row.name)}">${esc(row.offer_id || row.name || "Товар")}</div><small>${esc(sku)}</small></td>
      <td>${member ? fmt(report.coefficient,3) : "—"}</td>
      <td><input class="price-input" data-field="min_price" data-sku="${esc(sku)}" value="${esc(p.min_price)}" inputmode="decimal" aria-label="Ограничение SKU ${esc(sku)}"><div class="${saved ? "saved" : "pending-floor"}">${saved ? "✓ Сохранено" : "Ожидает применения"}</div></td>
      <td>${fmt(r?.ozon_price ?? row.ozon_price)}</td><td>${fmt(r?.strategy_price)}</td><td>${fmt(r?.price_index ?? row.price_index,3)}</td>
      <td><button class="link-button ${linkClass}" data-details="${esc(sku)}">${esc(linkLabel)}</button></td>
      <td><span class="badge ${r?.active ? "green" : "gray"}">${r?.active ? "Включён" : member ? report?.enabled ? "Ожидаем API" : "В стратегии, выкл." : r?.membership_pending ? "Участие не подтверждено" : p.selected ? "К добавлению" : "Не выбран"}</span></td></tr>
      <tr id="details-${esc(sku)}" hidden><td colspan="9" class="details-cell"><div class="details-grid">
        <div><label>Ожидаемая карточка WB<input data-field="wb_url" data-sku="${esc(sku)}" value="${esc(p.wb_url)}" placeholder="https://www.wildberries.ru/catalog/.../detail.aspx"></label><div class="detail-line">Эту ссылку сравним с сопоставлением Ozon.</div></div>
        <div><b>Товар WB по данным Ozon</b><div>${actualUrls}</div><div class="detail-line">Источник: ${esc(r?.link_source || "нет данных")}</div></div>
        <div class="detail-line">Фактическая привязка: ${esc(r?.strategy_id || "не подтверждена")}<br>Источник: ${esc(r?.assignment_source || "ещё не запрашивали")}<br>product_id: ${esc(row.product_id)}</div>
        <div class="detail-line">ID из данных цены: ${esc(r?.reported_strategy_id || "пусто")}<br>Дата цены по стратегии: ${esc(dateFmt(r?.price_downloaded_at))}${r && !r.price_info_current ? "<br>Цена и ссылка стратегии ещё не подтверждены для текущей привязки." : ""}</div>
      </div></td></tr>`;
  }).join("") : '<tr><td colspan="9" class="empty">Нет товаров по этому фильтру.</td></tr>';
}
function render() {
  const report=currentReport();
  $("mode").textContent=state.mode==="live" ? "Ваш кабинет Ozon" : "ДЕМОНСТРАЦИЯ";
  $("mode").className="badge " + (state.mode==="live" ? "green" : "blue");
  $("connect-open").textContent=state.mode==="live" ? "Сменить кабинет" : "Подключить Ozon";
  $("campaign-select").innerHTML='<option value="">Выберите кампанию</option>' + (state.strategies || []).map(s=>`<option value="${esc(s.id)}">${esc(s.name)} · ${s.products_count ?? "?"} ${s.membership_verified ? "подтверждено" : "по списку"}</option>`).join("");
  $("campaign-select").value=newDraft ? "" : state.selected_id || "";
  $("draft-panel").hidden=!newDraft;
  $("current-coefficient").textContent=report ? fmt(report.coefficient,3) : newDraft ? fmt($("start-coefficient").value,3) : "—";
  if (report && Number(report.coefficient)>=.94 && Number(report.coefficient)<=1) $("coefficient").value=Number(report.coefficient).toFixed(3);
  $("mean-index").textContent=fmt(report?.mean_index,3);
  const labels={in_range:"В диапазоне",above:"Выше цели",below:"Ниже цели",no_data:"Нет данных"};
  $("index-status").textContent=labels[report?.index_status] || "Нет данных";
  $("index-status").className="badge " + (report?.index_status==="in_range" ? "green" : report?.mean_index ? "amber" : "gray");
  $("member-count").textContent=report?.member_count || 0;
  $("coverage").textContent=`Ненулевых: ${report?.nonzero_count || 0} · Нулей: ${report?.zero_count || 0} · Пропусков: ${report?.missing_count || 0}` + ((report?.unconfirmed_member_ids || []).length ? ` · Не подтверждено в списке: ${report.unconfirmed_member_ids.length}` : "");
  $("strategy-status").textContent=newDraft ? "Новая кампания" : report?.enabled ? "Стратегия включена" : state.selected_id ? "Стратегия выключена" : "Нет выбранной кампании";
  $("strategy-status").className="badge " + (report?.enabled && !newDraft ? "green" : "gray");
  $("checked-at").textContent=`Версия ${state.version || "—"}. ` + (report ? `Проверено: ${dateFmt(report.checked_at)}. ID кампании: ${report.strategy_id}` : "Выберите или создайте кампанию.");
  $("diagnostics").hidden=!(report?.notes || []).length;
  $("diagnostic-notes").textContent=(report?.notes || []).join("\n");
  renderTable(); updateActionState();
}
async function perform(action, extras={}) {
  if (busy) return;
  const wasDraft=newDraft, previousId=state.selected_id, previousEdits=edits;
  setBusy(true); notice("Выполняется запрос…", "busy");
  try {
    const payload={action, strategy_id:state.selected_id, ...extras};
    const accepted=await request("/api/jobs", {method:"POST",body:JSON.stringify(payload)});
    let job;
    do { await new Promise(resolve=>setTimeout(resolve,300)); job=await request(`/api/jobs/${accepted.job_id}`); notice(job.message || "Выполняется…", "busy"); } while (job.status==="running");
    state=await request("/api/state");
    const keepDraft=job.status==="error" && action==="create" && wasDraft && state.selected_id===previousId;
    newDraft=keepDraft || !state.selected_id;
    if (keepDraft) edits=previousEdits; else initEdits();
    render();
    if (job.status==="error") throw new Error(job.error);
    let message=state.mode==="demo" ? "Демонстрация: изменения выполнены только в памяти." : "Готово. Данные Ozon обновлены.";
    if (job.plan) {
      const statuses={in_range:"Среднее в диапазоне: коэффициент не меняем.",adjustment_proposed:`Предлагаемый коэффициент: ${job.plan.new_coefficient}. Записи ещё не было.`,limit_reached:"Достигнута граница коэффициента. Среднее пока вне цели.",waiting_for_effect:"Коэффициент записан или ожидает пересчёта. Не повторяем изменение по старым данным.",blocked:"Коррекция заблокирована: проверьте состав, ссылки и ограничения.",effect_observed:"Получены новые цены/индексы. Результат предыдущего изменения прочитан.",pending_conflict:"Предыдущая запись не подтверждена или коэффициент изменён вручную.",pending_composition_changed:"Изменился состав индексов. Требуется проверка."};
      message=statuses[job.plan.status] || job.plan.reason || job.plan.status;
      if (job.plan.new_coefficient && action==="plan") $("coefficient").value=Number(job.plan.new_coefficient).toFixed(3);
    }
    if (state.configuration_issue) message=state.configuration_issue;
    const removed=(state.report?.actions || []).flatMap(a=>a.product_ids || []);
    if (removed.length) message=`Исключены товары с неверной или неподтверждённой WB-ссылкой: ${removed.join(", ")}. Остальные продолжают работу.`;
    notice(message, state.configuration_issue || removed.length ? "" : "success");
  } catch(error) { notice(error.message + " После ошибки записи перечитайте данные перед повтором.", "error"); }
  finally { setBusy(false); }
}
$("products").addEventListener("input",event=>{
  const el=event.target; if (!el.dataset.field) return;
  const p=edits.get(el.dataset.sku); p[el.dataset.field]=el.type==="checkbox" ? el.checked : el.value;
  if (el.dataset.field==="min_price") {
    const actual=currentReport()?.rows.find(r=>r.sku===p.sku)?.saved_min_price ?? state.catalog.find(r=>String(r.sku)===p.sku)?.saved_min_price;
    const saved=Number(p.min_price)>0 && Number(p.min_price)===Number(actual), label=el.parentElement.querySelector("div");
    label.className=saved ? "saved" : "pending-floor";label.textContent=saved ? "✓ Сохранено" : "Ожидает применения";
  }
  if (el.dataset.field==="wb_url") {
    const actual=currentReport()?.rows.find(r=>r.sku===p.sku), button=document.querySelector(`[data-details="${p.sku}"]`);
    const matches=actual?.link_status==="matched" && actual.expected_wb_url===p.wb_url;
    button.className="link-button "+(matches ? "green" : "amber");button.textContent=matches ? "✓ Совпала" : p.wb_url ? "Проверить" : "Указать ссылку";
  }
});
$("products").addEventListener("change",event=>{
  if (event.target.dataset.field==="selected") {
    const p=edits.get(event.target.dataset.sku); p.selected=event.target.checked;
  }
});
$("products").addEventListener("click",event=>{
  const button=event.target.closest("[data-details]"); if (button) { const detail=$("details-"+button.dataset.details); detail.hidden=!detail.hidden; }
});
$("search").addEventListener("input",renderTable);
$("all-tab").addEventListener("click",()=>{memberOnly=false;$("all-tab").classList.add("active");$("members-tab").classList.remove("active");renderTable();});
$("members-tab").addEventListener("click",()=>{memberOnly=true;$("members-tab").classList.add("active");$("all-tab").classList.remove("active");renderTable();});
$("new-campaign").addEventListener("click",()=>{newDraft=true;memberOnly=false;initEdits();render();notice("Новая кампания: отметьте товары, заполните ограничения и WB-ссылки, затем нажмите «Создать и включить».");$("campaign-name").focus();});
$("start-coefficient").addEventListener("input",()=>$("current-coefficient").textContent=fmt($("start-coefficient").value,3));
$("campaign-select").addEventListener("change",()=>{if($("campaign-select").value) perform("select",{strategy_id:$("campaign-select").value});});
$("reload").addEventListener("click",()=>perform("load"));
$("refresh").addEventListener("click",()=>perform("refresh",{products:collectProducts()}));
$("apply").addEventListener("click",()=>newDraft ? perform("create",{name:$("campaign-name").value,coefficient:$("start-coefficient").value,products:collectProducts()}) : perform("apply",{products:collectProducts()}));
$("verify").addEventListener("click",()=>perform("verify",{products:collectProducts()}));
$("download-diagnostics").addEventListener("click",()=>{window.location.assign("/api/diagnostics");});
$("plan").addEventListener("click",()=>perform("plan",{products:collectProducts()}));
$("apply-coefficient").addEventListener("click",()=>perform("coefficient",{products:collectProducts(),coefficient:$("coefficient").value}));
$("cycle").addEventListener("click",()=>perform("cycle",{products:collectProducts(),metric_confirmed:$("metric-confirmed").checked}));
$("connect-open").addEventListener("click",()=>$("connect-dialog").showModal());
$("connect-cancel").addEventListener("click",()=>{$("api-key").value="";$("connect-dialog").close();});
$("connect-form").addEventListener("submit",event=>{event.preventDefault();const data={client_id:$("client-id").value,api_key:$("api-key").value};$("api-key").value="";$("connect-dialog").close();perform("connect",data);});
$("demo-button").addEventListener("click",()=>perform("demo"));
(async()=>{try { const initial=await request("/api/session");csrf=initial.csrf;state=initial.state;newDraft=!state.selected_id;initEdits();render();await perform("load"); } catch(error) {notice(error.message,"error");} })();
