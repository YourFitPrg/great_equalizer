import copy
from contextlib import redirect_stdout
from decimal import Decimal
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from uuid import UUID

import requests

from ozon_strategy import (
    Policy, Product, SellerAPI, StrategyError, StrategyService, wb_article, write_json,
    main, worker_lock,
    ensure_strategy, list_strategies,
)


SID = "b23e6155-26b1-4fa4-a868-c0c15f50de3b"
URL = "https://www.wildberries.ru/catalog/{}/detail.aspx"


class Seller:
    """Stateful campaign API double; no requests leave this test."""

    def __init__(self, count=2):
        self.calls = []
        self.active_id = SID
        self.strategies = {SID: {"coefficient": .96, "enabled": True, "name": "Shared WB",
                                "members": {str(i) for i in range(1, count + 1)}}}
        self.products = {
            str(i): {"id": i, "sku": i * 100, "offer_id": f"offer-{i}", "name": f"Product {i}",
                     "url": URL.format(i), "index": "1.1", "floor": "100", "price": "150"}
            for i in range(1, count + 1)
        }
        self.fail_update = False
        self.reject_floor = False
        self.foreign = {}
        self.own_only = False
        self.external_only = False
        self.before_update = None
        self.fail_create = False
        self.hide_created = False
        self.create_id_field = "id"
        self.unassigned_id = ""
        self.assignment_overrides = {}
        self.stale_members = {}
        self.enabled_to_system = True
        self.route_on_status = False
        self.product_enabled_overrides = {}

    @property
    def coefficient(self): return self.strategies[self.active_id]["coefficient"]

    @coefficient.setter
    def coefficient(self, value): self.strategies[self.active_id]["coefficient"] = value

    @property
    def enabled(self): return self.strategies[self.active_id]["enabled"]

    @enabled.setter
    def enabled(self, value): self.strategies[self.active_id]["enabled"] = value

    @property
    def members(self): return self.strategies[self.active_id]["members"]

    @members.setter
    def members(self, value): self.strategies[self.active_id]["members"] = value

    def post(self, path, payload):
        self.calls.append((path, copy.deepcopy(payload)))
        if path.endswith("/pricing-strategy/list"):
            rows = [] if self.hide_created else [{"id": sid, "name": s["name"], "type": s.get("type", "COMP_PRICE"),
                "enabled": s["enabled"], "products_count": len(s["members"] | self.stale_members.get(sid, set()))} for sid, s in self.strategies.items()]
            start = (payload["page"] - 1) * payload["limit"]
            return {"strategies": rows[start:start + payload["limit"]], "total": len(rows)}
        if path.endswith("/pricing-strategy/create"):
            sid = str(UUID(int=1000 + len(self.strategies)))
            self.strategies[sid] = {"name": payload["strategy_name"], "coefficient": payload["competitors"][0]["coefficient"],
                                    "enabled": True, "members": set()}
            self.active_id = sid
            if self.fail_create:
                raise StrategyError("Connection lost after create")
            return {"result": {self.create_id_field: sid}}
        if path.endswith("/pricing-strategy/info"):
            self.active_id = payload["strategy_id"]
            if self.active_id not in self.strategies:
                error = StrategyError("HTTP 404: strategy not found")
                error.http_status = 404
                raise error
            return {"result": {"type": self.strategies[self.active_id].get("type", "COMP_PRICE"), "enabled": self.enabled, "name": self.strategies[self.active_id]["name"],
                               "competitors": [{"competitor_id": 16942991, "coefficient": self.coefficient}]}}
        if path.endswith("/products/list"):
            sid = payload['strategy_id']
            return {"result": {"product_id": sorted(self.strategies[sid]["members"] | self.stale_members.get(sid, set()))}}
        if path.endswith('/strategy-ids-by-product-ids'):
            rows = []
            for pid in payload['product_id']:
                owner = next((sid for sid, s in self.strategies.items() if pid in s['members']), self.unassigned_id)
                rows.append({'product_id': int(pid), 'strategy_id': self.assignment_overrides.get(pid, owner)})
            return {'result': {'products_info': rows}}
        if path == "/v3/product/info/list":
            return {"items": [dict(p) for key, p in self.products.items()
                    if key in payload.get("product_id", []) or str(p["sku"]) in payload.get("sku", [])]}
        if path == "/v3/product/list":
            return {"result": {"items": [{"product_id": k} for k in self.products], "last_id": "", "total_items": len(self.products)}}
        if path == "/v5/product/info/prices":
            return {"items": [{"product_id": int(k), "offer_id": p["offer_id"],
                    "price": {"price": p["price"], "min_price": p["floor"], "currency_code": "RUB"},
                    "price_indexes": {"self_marketplaces_index_data": {"price_index_value": p["index"]},
                                      "external_index_data": {"price_index_value": .1}}}
                    for k, p in self.products.items() if k in payload["filter"]["product_id"]]}
        if path.endswith("/pricing-strategy/product/info"):
            k = str(payload["product_id"])
            owner = next((sid for sid, s in self.strategies.items() if k in s["members"]), "")
            return {"result": {"strategy_id": self.foreign.get(k, owner),
                               "is_enabled": self.product_enabled_overrides.get(k, bool(owner) and self.strategies[owner]["enabled"]),
                               "strategy_competitor_product_url": "" if self.own_only or self.external_only else self.products[k]["url"],
                               "strategy_product_price": 148}}
        if path == "/v1/product/prices/details":
            return {"prices": [{"sku": str(p["sku"]),
                    "price_indexes": [{"external_index_data": {"url": p["url"]}}] if self.external_only else
                                     [{"self_index_data": {"url": p["url"]}}]}
                    for p in self.products.values() if str(p["sku"]) in payload["skus"]]}
        if path.endswith("/products/delete"):
            for s in self.strategies.values():
                s["members"] -= set(payload["product_id"])
            return {"result": {"failed_product_count": 0}}
        if path.endswith("/products/add"):
            self.active_id = payload["strategy_id"]
            self.members |= set(payload["product_id"])
            return {"result": {"failed_product_count": 0}}
        if path == "/v1/product/import/prices":
            for p in payload["prices"]:
                target = self.products[str(p["product_id"])]
                if not self.reject_floor:
                    target["floor"], target["price"] = p["min_price"], p["price"]
                if p.get('price_strategy_enabled') == 'ENABLED' and self.enabled_to_system:
                    self.move_to_system({str(p['product_id'])})
            return {"result": [{"product_id": p["product_id"], "updated": not self.reject_floor,
                                "errors": []} for p in payload["prices"]]}
        if path.endswith("/pricing-strategy/status"):
            self.active_id = payload["strategy_id"]
            self.enabled = payload["enabled"]
            if self.enabled and self.route_on_status:
                self.move_to_system(set(self.members))
            return {}
        if path.endswith("/pricing-strategy/update"):
            self.active_id = payload["strategy_id"]
            if self.before_update:
                self.before_update()
            self.coefficient = payload["competitors"][0]["coefficient"]
            if self.fail_update:
                raise StrategyError("Connection lost after write")
            return {}
        raise AssertionError(path)

    def targets(self):
        return [Product(str(p["sku"]), "100", URL.format(k)) for k, p in self.products.items()]

    def move_to_system(self, product_ids):
        system_id = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee'
        for sid, record in list(self.strategies.items()):
            if sid != system_id:
                self.stale_members.setdefault(sid, set()).update(record['members'] & product_ids)
                record['members'] -= product_ids
        system = self.strategies.setdefault(system_id, {'name':'Удерживайте выгодную цену','type':'MIN_EXT_PRICE',
            'coefficient':1,'enabled':True,'members':set()})
        system['members'] |= product_ids
        return system_id


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.api = Seller()
        self.service = StrategyService(self.api, SID, sleep=lambda _: None)
        self.targets = self.api.targets()

    def writes(self):
        return [p for p, _ in self.api.calls if p in SellerAPI.WRITE_PATHS]

    def test_snapshot_only_actual_members_arithmetic_mean_excludes_zero(self):
        self.api = Seller(4)
        self.service = StrategyService(self.api, SID)
        self.targets = self.api.targets()
        for i, val in enumerate([".98", "1.01", "0", "1.99"], 1):
            self.api.products[str(i)]["index"] = val
        self.api.members.remove("4")
        self.targets[3] = Product("400", "100", URL.format(4), selected=False)
        report = self.service.snapshot(self.targets)
        self.assertEqual(Decimal(report["mean_index"]), Decimal(".995"))
        self.assertEqual(report["nonzero_count"], 2)
        self.assertEqual(report["zero_count"], 1)
        self.assertTrue(report["ready"])
        self.assertEqual(self.writes(), [])

    def test_missing_index_is_not_zero_and_blocks_changes(self):
        self.api.products["1"]["index"] = None
        report = self.service.snapshot(self.targets)
        self.assertIsNone(report["mean_index"])
        self.assertEqual(report["missing_count"], 1)
        self.assertEqual(self.service.plan(report)["status"], "blocked")

    def test_unknown_member_blocks_mean_and_autoregulation(self):
        report = self.service.snapshot(self.targets[:1])
        self.assertEqual(report["untracked_product_ids"], ["2"])
        self.assertIsNone(report["mean_index"])
        with self.assertRaises(StrategyError):
            self.service.apply_selection(self.targets[:1])
        self.assertEqual(self.writes(), [])

    def test_selected_but_not_added_blocks_regulation(self):
        self.api.members.remove("2")
        report = self.service.snapshot(self.targets)
        self.assertFalse(report["ready"])
        self.assertEqual(report["member_count"], 1)

    def test_bad_link_excludes_only_bad_product_and_does_not_disable_shared_strategy(self):
        self.api.products["1"]["url"] = URL.format(999)
        report = self.service.verify(self.targets, timeout=0)
        self.assertEqual(self.api.members, {"2"})
        self.assertTrue(self.api.enabled)
        self.assertEqual(self.writes(), ["/v1/pricing-strategy/products/delete"])
        self.assertEqual(report["actions"][0]["product_ids"], ["1"])

    def test_own_premium_link_is_used_and_sku_is_string(self):
        self.api.own_only = True
        report = self.service.snapshot(self.targets)
        self.assertTrue(report["ready"])
        self.assertTrue(all(row["link_source"] == "prices/details" for row in report["rows"]))
        payload = next(d for p, d in self.api.calls if p.endswith("prices/details"))
        self.assertEqual(payload["skus"], ["100", "200"])

    def test_external_link_cannot_confirm_own_product(self):
        self.api.external_only = True
        report = self.service.verify(self.targets, timeout=0)
        self.assertEqual(self.api.members, set())
        self.assertFalse(report["ready"])

    def test_remove_never_removes_a_product_moved_to_another_strategy(self):
        self.api.strategies[SID]['members'].remove('1')
        self.api.strategies['other'] = {'name':'Other','members':{'1'},'coefficient':.96,'enabled':True}
        self.assertEqual(self.service._remove({"1"}), [])
        self.assertEqual(self.writes(), [])

    def test_apply_preserves_coefficient_and_name_without_creating_a_strategy(self):
        self.api.enabled = False
        self.api.members.remove("2")
        report = self.service.apply_selection(self.targets, verify_timeout=0)
        self.assertTrue(report["ready"])
        self.assertEqual(self.api.coefficient, .96)
        self.assertEqual(self.api.members, {"1", "2"})
        self.assertNotIn("/v1/pricing-strategy/update", self.writes())
        self.assertTrue(self.api.enabled)

    def test_shared_strategy_additions_are_batched_by_fifty(self):
        self.api = Seller(61)
        self.api.members.clear()
        self.service = StrategyService(self.api, SID)
        report = self.service.apply_selection(self.api.targets(), verify_timeout=0)
        sizes = [len(d["product_id"]) for p, d in self.api.calls if p.endswith("/products/add")]
        self.assertEqual(sizes, [50, 11])
        self.assertEqual(report["member_count"], 61)
        self.assertEqual(self.api.coefficient, .96)

    def test_uncheck_removes_only_that_product(self):
        targets = [self.targets[0], Product("200", "100", URL.format(2), selected=False)]
        report = self.service.apply_selection(targets, verify_timeout=0)
        self.assertTrue(report["ready"])
        self.assertEqual(self.api.members, {"1"})

    def test_other_strategy_is_rejected_before_any_mutation(self):
        self.api.strategies[SID]['members'].remove('2')
        self.api.strategies['other'] = {'name':'Other','members':{'2'},'coefficient':.96,'enabled':True}
        with self.assertRaises(StrategyError):
            self.service.apply_selection(self.targets)
        self.assertEqual(self.writes(), [])

    def test_floor_rejection_does_not_add_product(self):
        self.api.members.remove("2")
        self.api.reject_floor = True
        with self.assertRaises(StrategyError):
            self.service.apply_selection(self.targets)
        self.assertNotIn("2", self.api.members)
        self.assertNotIn("/v1/pricing-strategy/products/add", self.writes())

    def test_regulator_proposes_small_step_and_obeys_hard_limits(self):
        self.assertEqual(self.service.plan(self.service.snapshot(self.targets))["new_coefficient"], "0.958")
        self.api.coefficient = .94
        self.assertEqual(self.service.plan(self.service.snapshot(self.targets))["status"], "limit_reached")
        self.api.coefficient = 1
        for p in self.api.products.values():
            p["index"] = ".9"
        self.assertEqual(self.service.plan(self.service.snapshot(self.targets))["status"], "limit_reached")

    def test_coefficient_outside_business_range_is_visible_but_blocks_writes(self):
        self.api.coefficient = .93
        report = self.service.snapshot(self.targets)
        self.assertEqual(report["coefficient"], "0.93")
        self.assertEqual(report["coefficient_status"], "out_of_range")
        self.assertEqual(self.service.plan(report)["status"], "blocked")
        with self.assertRaises(StrategyError):
            self.service.apply_selection(self.targets)
        self.assertEqual(self.writes(), [])

    def test_index_boundaries_are_inclusive_and_unrounded(self):
        for index, expected in [(".98", "in_range"), ("1.01", "in_range"), (".979999", "adjustment_proposed"), ("1.010001", "adjustment_proposed")]:
            with self.subTest(index=index):
                for p in self.api.products.values():
                    p["index"] = index
                self.assertEqual(self.service.plan(self.service.snapshot(self.targets))["status"], expected)

    def test_manual_change_checks_step_and_concurrent_changes(self):
        for new in [".939", "1.001", ".97"]:
            with self.assertRaises(ValueError):
                self.service.change_coefficient(new, expected_current=".96", expected_members={"1", "2"})
        with self.assertRaises(StrategyError):
            self.service.change_coefficient(".958", expected_current=".95", expected_members={"1", "2"})
        self.assertEqual(self.writes(), [])

    def test_pending_intent_is_saved_before_coefficient_update(self):
        state, saved = {}, []
        self.api.before_update = lambda: self.assertTrue(saved[-1]["pending"])
        result = self.service.cycle(self.targets, state, write=True, metric_confirmed=True,
                                    persist=lambda s: saved.append(copy.deepcopy(s)))
        self.assertTrue(result["coefficient_written"])
        self.assertEqual(result["coefficient_after_write"], "0.958")
        self.assertEqual(self.api.coefficient, .958)
        self.assertEqual(self.service.cycle(self.targets, state, write=True, metric_confirmed=True,
                         persist=lambda s: None)["plan"]["status"], "waiting_for_effect")
        self.assertEqual(self.writes().count("/v1/pricing-strategy/update"), 1)

    def test_uncertain_write_is_not_replayed(self):
        state = {}
        self.api.fail_update = True
        with self.assertRaises(StrategyError):
            self.service.cycle(self.targets, state, write=True, metric_confirmed=True, persist=lambda s: None)
        self.assertIn("pending", state)
        result = self.service.cycle(self.targets, state, write=True, metric_confirmed=True, persist=lambda s: None)
        self.assertEqual(result["plan"]["status"], "waiting_for_effect")
        self.assertEqual(self.writes().count("/v1/pricing-strategy/update"), 1)

    def test_metric_must_be_confirmed_before_auto_write(self):
        result = self.service.cycle(self.targets, {}, write=True, persist=lambda s: None)
        self.assertEqual(result["plan"]["status"], "metric_not_confirmed")
        self.assertEqual(self.writes(), [])

    def test_dry_run_never_changes_state_or_api(self):
        state = {}
        self.service.cycle(self.targets, state)
        self.assertEqual(state, {})
        self.assertEqual(self.writes(), [])
        # Exercise a loaded pending record and the observation branch.
        state = {"pending": {"new_coefficient": ".96", "baseline": [["1", "1.2", "150"], ["2", "1.2", "150"]]}}
        before = copy.deepcopy(state)
        self.assertEqual(self.service.cycle(self.targets, state)["plan"]["status"], "effect_observed")
        self.assertEqual(state, before)

    def test_zero_cohort_change_does_not_trigger_another_correction(self):
        state = {}
        self.service.cycle(self.targets, state, write=True, metric_confirmed=True, persist=lambda s: None)
        self.api.products["1"]["index"] = "0"
        result = self.service.cycle(self.targets, state, write=True, metric_confirmed=True, persist=lambda s: None)
        self.assertEqual(result["plan"]["status"], "pending_composition_changed")
        self.assertEqual(self.writes().count("/v1/pricing-strategy/update"), 1)

    def test_no_same_cycle_correction_when_new_effect_is_observed(self):
        state = {}
        self.service.cycle(self.targets, state, write=True, metric_confirmed=True, persist=lambda s: None)
        self.api.products["1"]["index"] = "1.09"
        result = self.service.cycle(self.targets, state, write=True, metric_confirmed=True, persist=lambda s: None)
        self.assertEqual(result["plan"]["status"], "effect_observed")
        self.assertNotIn("pending", state)
        self.assertEqual(self.writes().count("/v1/pricing-strategy/update"), 1)

    def test_catalog_has_articul_and_membership(self):
        report = self.service.catalog()
        self.assertEqual(report["items"][0]["offer_id"], "offer-1")
        self.assertTrue(report["items"][0]["in_strategy"])
        self.assertEqual(self.writes(), [])


class MembershipTests(unittest.TestCase):
    ZERO = '00000000-0000-0000-0000-000000000000'
    OLD = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'

    def unassigned(self):
        api = Seller(1)
        api.members.clear()
        api.products['1'].update(sku=2067015085, offer_id='Weights/beige_05', floor='2217', price='2325')
        target = Product('2067015085', '2217', URL.format(1))
        service = StrategyService(api, SID, sleep=lambda _: None)
        return api, service, target

    def test_zero_or_empty_uuid_does_not_block_the_users_sku(self):
        for empty in [None, '', 0, '0', self.ZERO, '{' + self.ZERO + '}']:
            with self.subTest(value=empty):
                api, service, target = self.unassigned()
                api.unassigned_id, api.foreign['1'] = empty, empty
                report = service.apply_selection([target], verify_timeout=0)
                self.assertTrue(report['ready'])
                self.assertTrue(report['rows'][0]['active'])
                self.assertEqual(report['rows'][0]['strategy_id'], SID)
                self.assertEqual(report['rows'][0]['reported_strategy_id'], empty)
                self.assertEqual(report['rows'][0]['link_source'], 'prices/details')
                self.assertEqual(api.strategies[SID]['members'], {'1'})
                self.assertFalse(any(p.endswith('/products/delete') for p,_ in api.calls))

    def test_historical_product_info_id_is_not_a_membership_check(self):
        api, service, target = self.unassigned()
        api.foreign['1'] = self.OLD
        original = api.post
        def post(path, payload):
            data = original(path, payload)
            if path.endswith('/pricing-strategy/product/info'):
                data['result']['strategy_competitor_product_url'] = URL.format(999999)
            return data
        api.post = post
        report = service.apply_selection([target], verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(report['rows'][0]['reported_strategy_id'], self.OLD)
        self.assertIsNone(report['rows'][0]['strategy_price'])
        first_write = next(i for i,(p,d) in enumerate(api.calls) if p in SellerAPI.WRITE_PATHS)
        self.assertFalse(any(p.endswith('/pricing-strategy/info') and d.get('strategy_id') == self.OLD
                             for p,d in api.calls[:first_write]))

    def test_bad_assignment_payload_never_gets_treated_as_an_unassigned_product(self):
        for bad in [{'result':[]}, {'result':{'products_info':{}}}, {'result':{'products_info':['wrong']}}]:
            with self.subTest(data=bad):
                api, service, target = self.unassigned()
                original = api.post
                def post(path, payload):
                    if path.endswith('/strategy-ids-by-product-ids'):
                        return bad
                    return original(path, payload)
                api.post = post
                with self.assertRaises(StrategyError):
                    service.apply_selection([target], verify_timeout=0)
                self.assertFalse(any(p in SellerAPI.WRITE_PATHS for p,_ in api.calls))

    def test_deleted_association_is_checked_and_not_called_another_campaign(self):
        api, service, target = self.unassigned()
        api.unassigned_id = self.OLD
        report = service.apply_selection([target], verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertTrue(any('404' in n for n in report['notes']))

    def test_membership_must_be_confirmed_by_the_other_campaigns_composition(self):
        api, service, target = self.unassigned()
        api.strategies[self.OLD] = {'name':'Old empty','members':set(),'coefficient':.96,'enabled':False}
        api.unassigned_id = self.OLD
        report = service.apply_selection([target], verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(api.strategies[self.OLD]['members'], set())
        self.assertFalse(any(p.endswith('/products/delete') for p,_ in api.calls))

    def test_real_custom_membership_blocks_before_any_price_mutation_and_names_owner(self):
        api, service, target = self.unassigned()
        api.strategies[self.OLD] = {'name':'Actual owner','members':{'1'},'coefficient':.96,'enabled':False}
        with self.assertRaises(StrategyError) as error:
            service.apply_selection([target], verify_timeout=0)
        self.assertIn(self.OLD, str(error.exception))
        self.assertIn('Actual owner', str(error.exception))
        self.assertFalse(any(p in SellerAPI.WRITE_PATHS for p,_ in api.calls))

    def test_only_selected_system_products_are_moved_without_disabling_the_system(self):
        api = Seller(3)
        api.strategies[SID]['members'] = {'2'}
        api.strategies[self.OLD] = {'name':'System','type':'MIN_EXT_PRICE','members':{'1','3'},'coefficient':1,'enabled':True}
        service = StrategyService(api, SID, sleep=lambda _: None)
        report = service.apply_selection(api.targets()[:2], verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(api.strategies[SID]['members'], {'1','2'})
        self.assertEqual(api.strategies[self.OLD]['members'], {'3'})
        self.assertTrue(api.strategies[self.OLD]['enabled'])
        deletes = [d['product_id'] for p,d in api.calls if p.endswith('/products/delete')]
        self.assertEqual(deletes, [['1']])
        self.assertFalse(any(p.endswith('/status') and d['strategy_id'] == self.OLD for p,d in api.calls))

    def test_permission_failure_is_not_treated_as_a_deleted_strategy(self):
        api, service, target = self.unassigned()
        api.unassigned_id = self.OLD
        original = api.post
        def post(path, payload):
            if path.endswith('/pricing-strategy/info') and payload['strategy_id'] == self.OLD:
                error = StrategyError('HTTP 403: no permissions')
                error.http_status = 403
                raise error
            return original(path, payload)
        api.post = post
        with self.assertRaisesRegex(StrategyError, '403'):
            service.apply_selection([target], verify_timeout=0)
        self.assertFalse(any(p in SellerAPI.WRITE_PATHS for p,_ in api.calls))

    def test_membership_reads_use_string_ids_in_batches_of_fifty(self):
        api = Seller(61)
        report = StrategyService(api, SID).snapshot(api.targets())
        reads = [d for p,d in api.calls if p.endswith('/strategy-ids-by-product-ids')]
        self.assertEqual([len(r['product_id']) for r in reads], [50,11])
        self.assertTrue(all(isinstance(pid,str) for row in reads for pid in row['product_id']))
        self.assertEqual(report['member_count'], 61)


class SystemRoutingTests(unittest.TestCase):
    def test_custom_campaign_flow_never_sends_generic_autostrategy_enable(self):
        api = Seller(2)
        api.members.clear()
        api.enabled = False
        report = StrategyService(api, SID, sleep=lambda _: None).apply_selection(api.targets(), verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(api.strategies[SID]['members'], {'1','2'})
        self.assertFalse(any(s.get('type') == 'MIN_EXT_PRICE' for s in api.strategies.values()))
        imports = [d['prices'][0] for p,d in api.calls if p.endswith('/import/prices')]
        self.assertTrue(imports)
        self.assertTrue(all(p['price_strategy_enabled'] == 'UNKNOWN' for p in imports))
        self.assertEqual(report['member_count'],2)

    def test_two_stale_custom_list_entries_are_not_counted_when_system_owns_them(self):
        api = Seller(2)
        system = api.move_to_system({'1','2'})
        report = StrategyService(api, SID).snapshot(api.targets())
        self.assertEqual(report['listed_member_count'],2)
        self.assertEqual(report['member_count'],0)
        self.assertEqual(report['unconfirmed_member_ids'],['1','2'])
        self.assertIsNone(report['mean_index'])
        self.assertFalse(report['ready'])
        self.assertTrue(all(r['strategy_id'] == system and not r['in_strategy'] for r in report['rows']))

    def test_readd_after_manual_system_removal_does_not_skip_due_to_a_stale_list(self):
        api = Seller(2)
        system = api.move_to_system({'1','2'})
        api.strategies[system]['members'].clear()  # The user's manual action.
        report = StrategyService(api,SID,sleep=lambda _:None).apply_selection(api.targets(),verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(report['member_count'],2)
        adds = [d['product_id'] for p,d in api.calls if p.endswith('/products/add')]
        self.assertEqual(adds,[['1','2']])
        self.assertEqual(api.strategies[system]['members'],set())
        self.assertEqual(api.strategies[SID]['members'],{'1','2'})

    def test_readd_when_list_and_mapping_are_both_stale_but_product_is_inactive(self):
        api = Seller(2)
        system = api.move_to_system({'1','2'})
        api.strategies[system]['members'].clear()
        api.assignment_overrides = {'1':SID,'2':SID}
        service = StrategyService(api,SID,sleep=lambda _:None)
        before = service.snapshot(api.targets())
        self.assertEqual(before['member_count'],0)
        report = service.apply_selection(api.targets(),verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(report['member_count'],2)
        self.assertEqual(api.strategies[SID]['members'],{'1','2'})
        self.assertEqual(api.strategies[system]['members'],set())

    def test_remaining_system_members_are_moved_only_after_floor_is_saved(self):
        api = Seller(2)
        system = api.move_to_system({'1','2'})
        report = StrategyService(api,SID,sleep=lambda _:None).apply_selection(api.targets(),verify_timeout=0)
        self.assertTrue(report['ready'])
        self.assertEqual(api.strategies[SID]['members'],{'1','2'})
        self.assertEqual(api.strategies[system]['members'],set())
        self.assertTrue(api.strategies[system]['enabled'])
        writes = [(p,d) for p,d in api.calls if p in SellerAPI.WRITE_PATHS]
        first_delete = next(i for i,(p,d) in enumerate(writes) if p.endswith('/products/delete'))
        self.assertTrue(all(p.endswith('/import/prices') for p,d in writes[:first_delete]))

    def test_post_enable_reassignment_cannot_be_reported_as_success(self):
        api = Seller(2)
        api.members.clear()
        api.enabled = False
        api.route_on_status = True
        service = StrategyService(api,SID,sleep=lambda _:None)
        with self.assertRaisesRegex(StrategyError,'После включения'):
            service.apply_selection(api.targets(),verify_timeout=0)
        report = service.snapshot(api.targets())
        self.assertEqual(report['member_count'],0)
        self.assertEqual(report['listed_member_count'],2)

    def test_contradictory_price_and_owner_proofs_block_success_even_if_mapping_is_stale(self):
        api = Seller(2)
        api.move_to_system({'1','2'})
        api.assignment_overrides = {'1':SID,'2':SID}
        service = StrategyService(api,SID,sleep=lambda _:None)
        report = service.snapshot(api.targets())
        self.assertEqual(report['member_count'],0)
        self.assertTrue(all(r['membership_conflict'] for r in report['rows']))
        with self.assertRaisesRegex(StrategyError,'именно в выбранной кампании не подтверждено'):
            service.apply_selection(api.targets(),verify_timeout=0)

    def test_explicitly_inactive_products_do_not_count_as_confirmed_in_enabled_campaign(self):
        api = Seller(2)
        api.product_enabled_overrides = {'1':False,'2':False}
        report = StrategyService(api,SID).snapshot(api.targets())
        self.assertEqual(report['member_count'],0)
        self.assertIsNone(report['mean_index'])
        self.assertTrue(all(r['membership_pending'] for r in report['rows']))

    def test_disabled_campaign_keeps_its_known_composition(self):
        api = Seller(2)
        api.enabled = False
        report = StrategyService(api,SID).snapshot(api.targets())
        self.assertEqual(report['member_count'],2)
        self.assertTrue(all(r['in_strategy'] and not r['active'] for r in report['rows']))


class InputAndTransportTests(unittest.TestCase):
    def test_invalid_values_and_url_hosts_are_rejected(self):
        for floor in ["0", "NaN", "Infinity", "1.001", "-10"]:
            with self.assertRaises(ValueError):
                Product("100", floor, URL.format(1))
        for url in ["https://wildberries.ru.evil.com/catalog/1/detail.aspx", "https://user@wildberries.ru/catalog/1/detail.aspx", "file:///catalog/1/detail.aspx"]:
            with self.assertRaises(ValueError):
                wb_article(url)
        with self.assertRaises(ValueError):
            Policy(coefficient_min=Decimal(".5"))

    def test_atomic_state_round_trip(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "state.json"
            write_json(path, {"pending": {"coefficient": Decimal(".958")}})
            self.assertEqual(json.loads(path.read_text())["pending"]["coefficient"], "0.958")
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_reads_retry_429_writes_do_not_and_secrets_are_redacted(self):
        class Clock:
            now = 0
            def sleep(self, delay): self.now += delay
        class Session:
            def __init__(self, codes): self.codes, self.calls = list(codes), 0
            def post(self, *args, **kwargs):
                self.calls += 1
                r = requests.Response()
                r.status_code = self.codes.pop(0)
                r._content = b'{"error":"secret-value"}' if r.status_code != 200 else b'{}'
                r.headers["Retry-After"] = "2"
                return r
        clock, session = Clock(), Session([429, 200])
        api = SellerAPI("client-id", "secret-value", session=session, sleep=clock.sleep, clock=lambda: clock.now)
        api.post("/v1/pricing-strategy/info", {})
        self.assertEqual(session.calls, 2)
        session.codes = [429, 200]
        with self.assertRaises(StrategyError) as raised:
            api.post("/v1/pricing-strategy/update", {})
        self.assertNotIn("secret-value", str(raised.exception))
        self.assertEqual(session.codes, [200])
        self.assertEqual(len(api.audit_log),1)
        self.assertEqual(api.audit_log[0]['method'],'/v1/pricing-strategy/update')
        self.assertNotIn('secret-value',json.dumps(api.audit_log))
        self.assertNotIn('Client-Id',json.dumps(api.audit_log))

    def test_worker_lock_rejects_an_overlapping_process(self):
        with tempfile.TemporaryDirectory() as folder:
            with worker_lock(Path(folder) / "worker.lock"):
                with self.assertRaises(StrategyError):
                    with worker_lock(Path(folder) / "worker.lock"):
                        self.fail("Lock must be exclusive")

    def test_cli_dry_run_and_durable_write_with_configured_account(self):
        api = Seller()
        with tempfile.TemporaryDirectory() as folder:
            config, state = Path(folder) / "config.json", Path(folder) / "state.json"
            config.write_text(json.dumps({"strategy_id": SID, "autoregulation": True,
                "metric_confirmed": True, "products": [p.__dict__ for p in api.targets()]}))
            args = ["cycle", "--config", str(config), "--state", str(state)]
            with patch.dict("os.environ", {"OZON_CLIENT_ID": "fake-client", "OZON_API_KEY": "fake-key"}), \
                    patch("ozon_strategy.SellerAPI", return_value=api), redirect_stdout(StringIO()) as output:
                self.assertEqual(main(args), 0)
                self.assertFalse(state.exists())
                self.assertFalse(json.loads(output.getvalue())["coefficient_written"])
                output.seek(0)
                output.truncate()
                self.assertEqual(main(args + ["--write"]), 0)
                self.assertEqual(json.loads(state.read_text())["pending"]["new_coefficient"], "0.958")
                self.assertTrue(json.loads(output.getvalue())["coefficient_written"])


class CampaignTests(unittest.TestCase):
    def setUp(self):
        self.api = Seller()
        self.state = {}
        self.saved = []

    def ensure(self, name="WB new", coefficient="0.960"):
        return ensure_strategy(self.api, strategy_name=name, initial_coefficient=coefficient,
            state=self.state, persist=lambda state: self.saved.append(copy.deepcopy(state)))

    def test_create_new_after_deletion_attach_products_and_enable(self):
        self.api.strategies.clear()
        service = self.ensure()
        self.assertNotEqual(service.strategy_id, SID)
        self.assertFalse(service.strategy()["enabled"])
        self.assertEqual(self.saved[0]["strategy_setups"]["WB new"]["status"], "creating")
        self.assertEqual(self.saved[1]["strategy_setups"]["WB new"]["strategy_id"], service.strategy_id)
        report = service.apply_selection(self.api.targets(), verify_timeout=0)
        self.assertTrue(report["ready"])
        self.assertTrue(report["enabled"])
        self.assertEqual(report["coefficient"], "0.96")
        calls = self.api.calls
        first_floor = next(i for i,(p,d) in enumerate(calls) if p.endswith('/import/prices'))
        attachment = next(i for i,(p,d) in enumerate(calls) if p.endswith('/products/add'))
        enabled = next(i for i,(p,d) in enumerate(calls) if p.endswith('/status') and d.get('enabled') is True)
        self.assertEqual(calls[first_floor][1]['prices'][0]['price_strategy_enabled'], 'UNKNOWN')
        self.assertLess(first_floor, attachment)
        self.assertLess(attachment, enabled)
        self.assertFalse(any(p.endswith('/import/prices') and d['prices'][0]['price_strategy_enabled'] != 'UNKNOWN' for p,d in calls))

    def test_deleted_recorded_campaign_can_be_recreated_after_a_confirmed_404(self):
        first = self.ensure()
        del self.api.strategies[first.strategy_id]
        # Fake IDs are deterministic; add a record so the new ID differs.
        self.api.strategies[str(UUID(int=9000))] = {'name':'other','coefficient':.96,'enabled':False,'members':set()}
        second = self.ensure()
        self.assertNotEqual(first.strategy_id, second.strategy_id)
        self.assertEqual(second.strategy()['name'], 'WB new')

    def test_repeat_creation_reuses_id_and_retains_changed_coefficient(self):
        first = self.ensure()
        self.api.coefficient = .958
        second = self.ensure()
        self.assertEqual(first.strategy_id, second.strategy_id)
        self.assertEqual(second.strategy()["competitors"][0]["coefficient"], .958)
        self.assertEqual(sum(p.endswith('/pricing-strategy/create') for p, _ in self.api.calls), 1)

    def test_ambiguous_create_is_recovered_by_name_without_replay(self):
        self.api.fail_create = True
        with self.assertRaises(StrategyError):
            self.ensure()
        self.assertEqual(self.state["strategy_setups"]["WB new"]["status"], "creating")
        service = self.ensure()
        self.assertEqual(service.strategy()["name"], "WB new")
        self.assertEqual(sum(p.endswith('/pricing-strategy/create') for p, _ in self.api.calls), 1)

    def test_ambiguous_create_with_empty_list_is_not_replayed(self):
        self.api.fail_create = True
        with self.assertRaises(StrategyError):
            self.ensure()
        self.api.hide_created = True
        with self.assertRaisesRegex(StrategyError, "не отправлено"):
            self.ensure()
        self.assertEqual(sum(p.endswith('/pricing-strategy/create') for p, _ in self.api.calls), 1)

    def test_both_create_response_id_fields_are_supported(self):
        self.api.create_id_field = "strategy_id"
        self.assertTrue(self.ensure().strategy_id)

    def test_selecting_another_campaign_does_not_change_members_or_coefficients(self):
        second = self.ensure()
        second_id = second.strategy_id
        second.apply_selection([], verify_timeout=0)
        first = StrategyService(self.api, SID)
        self.assertEqual(first.snapshot(self.api.targets())["member_count"], 2)
        self.assertEqual(second.snapshot([])["member_count"], 0)
        self.assertEqual(self.api.strategies[SID]["coefficient"], .96)
        self.assertEqual(self.api.strategies[SID]["members"], {"1", "2"})
        with self.assertRaisesRegex(StrategyError, "другую пользовательскую стратегию"):
            second.apply_selection(self.api.targets())
        self.assertEqual(self.api.strategies[second_id]["members"], set())

    def test_missing_expected_url_is_visible_but_cannot_be_applied(self):
        service = StrategyService(self.api, SID)
        target = Product("100", "100", "")
        report = service.snapshot([target, self.api.targets()[1]])
        self.assertEqual(report["rows"][0]["link_status"], "expected_missing")
        self.assertFalse(report["ready"])
        with self.assertRaises(ValueError):
            service.apply_selection([target])
        self.assertFalse(any(p in SellerAPI.WRITE_PATHS for p, _ in self.api.calls))

    def test_list_has_multiple_campaigns_and_no_mutations(self):
        self.ensure("Campaign A")
        self.ensure("Campaign B", ".95")
        before = len(self.api.calls)
        rows = list_strategies(self.api)
        self.assertEqual({r["name"] for r in rows}, {"Shared WB", "Campaign A", "Campaign B"})
        self.assertTrue(all(p in SellerAPI.READ_PATHS for p, _ in self.api.calls[before:]))


if __name__ == "__main__":
    unittest.main()
