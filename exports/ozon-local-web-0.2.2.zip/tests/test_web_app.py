import importlib.util
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
import requests

HAS_WEB = importlib.util.find_spec("fastapi") is not None and importlib.util.find_spec("httpx") is not None
if HAS_WEB:
    from fastapi.testclient import TestClient
    from web_app import create_app
    from web_demo import make_demo_api
    from ozon_strategy import SellerAPI


@unittest.skipUnless(HAS_WEB, "Install requirements-web.txt and httpx to test the browser backend")
class WebTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.app = create_app(state_dir=self.folder.name)
        self.client = TestClient(self.app)
        response = self.client.get('/api/session')
        self.csrf = response.json()['csrf']
        self.headers = {'X-CSRF-Token': self.csrf}
        self.browser = self.app.state.sessions[self.client.cookies['ge_session']]

    def tearDown(self):
        self.client.close()
        self.folder.cleanup()

    def job(self, action, **payload):
        response = self.client.post('/api/jobs', json={'action': action, **payload}, headers=self.headers)
        self.assertEqual(response.status_code, 202, response.text)
        job_id = response.json()['job_id']
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            result = self.client.get('/api/jobs/' + job_id).json()
            if result['status'] != 'running':
                return result
            time.sleep(.005)
        self.fail('Job did not finish')

    @staticmethod
    def swim():
        return {'sku': '425648785', 'min_price': '469',
                'wb_url': 'https://www.wildberries.ru/catalog/101231686/detail.aspx', 'selected': True}

    def test_demo_loads_and_mean_excludes_unselected_candidates(self):
        self.assertEqual(self.job('load')['status'], 'done')
        state = self.client.get('/api/state').json()
        self.assertEqual(len(state['strategies']), 2)
        self.assertEqual(len(state['catalog']), 3)
        self.assertEqual(state['report']['mean_index'], '0.997')
        self.assertEqual(state['report']['member_count'], 1)
        self.assertEqual(list(Path(self.folder.name).iterdir()), [])

    def test_create_after_deletion_then_select_and_update_only_one_campaign(self):
        self.browser.api.strategies.clear()
        self.assertEqual(self.job('load')['status'], 'done')
        self.assertEqual(self.client.get('/api/state').json()['selected_id'], '')
        result = self.job('create', name='Browser campaign', coefficient='.96', products=[self.swim()])
        self.assertEqual(result['status'], 'done', result)
        state = self.client.get('/api/state').json()
        sid = state['selected_id']
        self.assertTrue(state['report']['enabled'])
        self.assertEqual(state['report']['member_count'], 1)
        self.assertEqual(state['report']['mean_index'], '1.46')
        self.assertEqual(state['report']['coefficient'], '0.96')
        result = self.job('coefficient', strategy_id=sid, coefficient='.958', products=[self.swim()])
        self.assertEqual(result['status'], 'done', result)
        self.assertEqual(self.client.get('/api/state').json()['report']['coefficient'], '0.958')
        result = self.job('coefficient', strategy_id=sid, coefficient='.97', products=[self.swim()])
        self.assertEqual(result['status'], 'error')
        self.assertEqual(self.browser.api.strategies[sid]['coefficient'], .958)

    def test_campaign_selection_never_moves_members_or_resets_coefficients(self):
        self.job('load')
        original = self.browser.selected_id
        self.assertEqual(self.job('create', name='Swim', coefficient='.95', products=[self.swim()])['status'], 'done')
        second = self.browser.selected_id
        self.assertNotEqual(original, second)
        self.assertEqual(self.job('select', strategy_id=original)['status'], 'done')
        self.assertEqual(self.browser.campaigns[original]['report']['coefficient'], '0.96')
        self.assertEqual(self.browser.campaigns[original]['report']['member_count'], 1)
        self.assertEqual(self.browser.api.strategies[second]['coefficient'], .95)
        self.assertEqual(self.browser.api.strategies[second]['members'], {'1000000002'})

    def test_users_sku_can_be_added_when_product_info_returns_an_empty_uuid(self):
        self.browser.api.strategies.clear()
        self.browser.api.unassigned_id = '00000000-0000-0000-0000-000000000000'
        self.browser.api.foreign['1000000002'] = self.browser.api.unassigned_id
        self.browser.api.products['1000000002'].update(sku=2067015085, offer_id='Weights/beige_05',
            floor='2217',price='2325',index='1.0')
        self.job('load')
        product = {'sku':'2067015085','min_price':'2217','wb_url':self.swim()['wb_url'],'selected':True}
        result = self.job('create',name='Weights',coefficient='.96',products=[product])
        self.assertEqual(result['status'],'done',result)
        state = self.client.get('/api/state').json()
        self.assertEqual(state['report']['member_count'],1)
        self.assertTrue(state['report']['ready'])
        self.assertEqual(state['report']['rows'][0]['sku'],'2067015085')
        self.assertEqual(state['report']['rows'][0]['link_source'],'prices/details')

    def test_partial_failure_keeps_the_created_campaign_coefficient_visible(self):
        self.job('load')
        old_product = self.browser.campaigns[self.browser.selected_id]['products'][0]
        result = self.job('create',name='Cannot steal',coefficient='.96',products=[old_product])
        self.assertEqual(result['status'],'error')
        state = self.client.get('/api/state').json()
        self.assertIsNotNone(state['report'])
        self.assertEqual(state['report']['coefficient'],'0.96')
        self.assertEqual(state['report']['member_count'],0)
        self.assertIn('ID ',result['error'])

    def test_stale_list_counter_is_not_displayed_as_two_confirmed_products(self):
        self.job('load')
        sid = self.browser.selected_id
        # Independent API sources: a stale custom list, actual system ownership.
        original = self.browser.api.post
        system = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee'
        self.browser.api.strategies[system] = {'name':'System','type':'MIN_EXT_PRICE','coefficient':1,'enabled':True,'members':{'2077805520'}}
        self.browser.api.strategies[sid]['members'].clear()
        def post(path,payload):
            if path.endswith('/products/list') and payload['strategy_id'] == sid:
                return {'result':{'product_id':['2077805520']}}
            return original(path,payload)
        self.browser.api.post = post
        self.assertEqual(self.job('refresh')['status'],'done')
        state = self.client.get('/api/state').json()
        self.assertEqual(state['report']['member_count'],0)
        self.assertEqual(state['report']['listed_member_count'],1)
        chosen = next(r for r in state['strategies'] if r['id'] == sid)
        self.assertEqual(chosen['products_count'],0)
        self.assertTrue(chosen['membership_verified'])
        response = self.client.get('/api/diagnostics')
        self.assertEqual(response.status_code,200)
        self.assertIn('attachment',response.headers['Content-Disposition'])
        self.assertEqual(response.json()['report']['membership_evidence']['assignments']['2077805520'],system)

    def test_manual_removal_from_system_with_stale_counters_can_be_repaired(self):
        self.job('load')
        sid = self.browser.selected_id
        system = self.browser.api.move_to_system({'2077805520'})
        self.browser.api.strategies[system]['members'].clear()
        self.browser.api.assignment_overrides['2077805520'] = sid
        self.assertEqual(self.job('refresh')['status'],'done')
        self.assertEqual(self.client.get('/api/state').json()['report']['member_count'],0)
        result = self.job('apply',strategy_id=sid,products=self.browser.campaigns[sid]['products'])
        self.assertEqual(result['status'],'done',result)
        self.assertEqual(self.client.get('/api/state').json()['report']['member_count'],1)
        self.assertEqual(self.browser.api.strategies[sid]['members'],{'2077805520'})
        self.assertEqual(self.browser.api.strategies[system]['members'],set())
        self.assertFalse(any(p.endswith('/import/prices') and d['prices'][0]['price_strategy_enabled']=='ENABLED'
                             for p,d in self.browser.api.calls))

    def test_foreign_reassignment_after_enable_is_an_error_with_zero_confirmed_members(self):
        self.browser.api.strategies.clear()
        self.browser.api.route_on_status = True
        self.job('load')
        result = self.job('create',name='Check final owner',coefficient='.96',products=[self.swim()])
        self.assertEqual(result['status'],'error')
        self.assertIn('После включения',result['error'])
        state = self.client.get('/api/state').json()
        self.assertEqual(state['report']['member_count'],0)
        self.assertEqual(state['report']['listed_member_count'],1)
        self.assertFalse(state['report']['ready'])

    def test_unknown_expected_link_does_not_remove_existing_member_on_read(self):
        self.job('load')
        selected = self.browser.selected_id
        products = self.browser.campaigns[selected]['products']
        products[0]['wb_url'] = ''
        result = self.job('refresh', strategy_id=selected, products=products)
        self.assertEqual(result['status'], 'done')
        report = self.browser.campaigns[selected]['report']
        self.assertEqual(report['rows'][0]['link_status'], 'expected_missing')
        self.assertFalse(report['ready'])
        self.assertEqual(self.browser.api.strategies[selected]['members'], {'2077805520'})

    def test_live_keys_never_appear_in_state_or_saved_settings(self):
        with patch('web_app.SellerAPI', return_value=make_demo_api()):
            result = self.job('connect', client_id='123456', api_key='never-save-this-api-key')
        self.assertEqual(result['status'], 'done', result)
        text = self.client.get('/api/state').text
        self.assertNotIn('never-save-this-api-key', text)
        files = list(Path(self.folder.name).glob('*.json'))
        self.assertTrue(files)
        for path in files:
            self.assertNotIn('never-save-this-api-key', path.read_text())
        self.assertNotIn('never-save-this-api-key', json.dumps(self.browser.jobs))

    def test_diagnostics_include_real_client_write_journal_but_never_headers_or_credentials(self):
        fake = make_demo_api()
        class Clock:
            value = 0
            def now(self): return self.value
            def sleep(self,delay): self.value += delay
        class Transport:
            def post(self,url,*,json,**kwargs):
                result = fake.post(url.removeprefix(SellerAPI.BASE_URL),json)
                response = requests.Response()
                response.status_code = 200
                response._content = __import__('json').dumps(result).encode()
                return response
        clock = Clock()
        client = SellerAPI('private-client-230276','super-secret-api-key',session=Transport(),sleep=clock.sleep,clock=clock.now)
        with patch('web_app.SellerAPI',return_value=client):
            self.assertEqual(self.job('connect',client_id='private-client-230276',api_key='super-secret-api-key')['status'],'done')
        result = self.job('create',name='Audit',coefficient='.96',products=[self.swim()])
        self.assertEqual(result['status'],'done',result)
        response = self.client.get('/api/diagnostics')
        self.assertEqual(response.status_code,200)
        self.assertTrue(response.json()['writes'])
        self.assertNotIn('super-secret-api-key',response.text)
        self.assertNotIn('private-client-230276',response.text)
        self.assertNotIn('Api-Key',response.text)
        self.assertNotIn('Client-Id',response.text)
        imports = [json.loads(e['request']) for e in response.json()['writes'] if e['method'].endswith('/import/prices')]
        self.assertTrue(imports)
        self.assertTrue(all(r['prices'][0]['price_strategy_enabled']=='UNKNOWN' for r in imports))

    def test_csrf_and_cross_origin_writes_are_rejected(self):
        self.assertEqual(self.client.post('/api/jobs', json={'action': 'load'}).status_code, 403)
        self.assertEqual(self.client.post('/api/jobs', json={'action': 'load'},
            headers={**self.headers, 'Origin': 'https://another.example'}).status_code, 403)

    def test_browser_sessions_and_jobs_are_isolated(self):
        first_job = self.job('load')
        other = TestClient(self.app)
        other.get('/api/session')
        self.assertEqual(other.get('/api/jobs/' + first_job['id']).status_code, 404)
        self.assertEqual(other.get('/api/state').json()['catalog'], [])
        other.close()

    def test_static_page_and_security_headers(self):
        page = self.client.get('/')
        self.assertEqual(page.status_code, 200)
        self.assertIn('Новая кампания', page.text)
        self.assertIn("frame-ancestors 'none'", page.headers['Content-Security-Policy'])
        self.assertEqual(self.client.get('/static/app.js').status_code, 200)
        self.assertEqual(self.client.get('/', headers={'Host': 'another.example'}).status_code, 400)


if __name__ == '__main__':
    unittest.main()
