"""Ozon/WB campaigns: create, select, and manage a shared strategy per campaign.

Only third-party dependency: requests. No notebook or repository imports.
See docs/website-integration.md for the UI, lifecycle, and worker contract.
"""
from __future__ import annotations

import argparse
import copy
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from email.utils import parsedate_to_datetime
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
from urllib.parse import urlsplit
from uuid import UUID

import requests


class StrategyError(RuntimeError):
    """Safe to display; never contains request headers or credentials."""


def number(value):
    if isinstance(value, bool):
        raise ValueError("Ожидалось число.")
    try:
        result = Decimal(str(value).strip().replace(",", "."))
    except InvalidOperation:
        raise ValueError("Ожидалось число.") from None
    if not result.is_finite():
        raise ValueError("Число должно быть конечным.")
    return result


def identifier(value):
    text = str(value).strip()
    if not re.fullmatch(r"[1-9][0-9]*", text):
        raise ValueError("Некорректный идентификатор товара.")
    return text


def strategy_identifier(value):
    """An empty/zero UUID is an unassigned value, not another campaign."""
    if value is None:
        return ""
    text = str(value).strip()
    if text in {"", "0"}:
        return ""
    try:
        parsed = UUID(text)
    except ValueError:
        # The API declares a string, including for system strategy identifiers.
        return text
    return str(parsed) if parsed.int else ""


def wb_article(url):
    try:
        p = urlsplit(str(url).strip())
        match = re.fullmatch(r"/catalog/([1-9][0-9]*)/detail\.aspx/?", p.path)
        if (p.scheme not in {"https", "http"} or p.username or p.password
                or p.hostname not in {"wildberries.ru", "www.wildberries.ru"}
                or p.port not in {None, 80, 443} or not match):
            raise ValueError
        return match[1]
    except ValueError:
        raise ValueError("Нужна полная ссылка на карточку Wildberries.") from None


def batches(values, size):
    values = list(values)
    for start in range(0, len(values), size):
        yield values[start:start + size]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class Product:
    sku: str
    min_price: str
    wb_url: str
    selected: bool = True

    def __post_init__(self):
        object.__setattr__(self, "sku", identifier(self.sku))
        price = number(self.min_price)
        if price <= 0 or price != price.quantize(Decimal(".01")):
            raise ValueError("Ограничение цены должно быть положительным, до копейки.")
        object.__setattr__(self, "min_price", str(price))
        object.__setattr__(self, "wb_url", str(self.wb_url).strip())
        if self.wb_url:
            wb_article(self.wb_url)
        if not isinstance(self.selected, bool):
            raise ValueError("selected должен быть true или false.")


@dataclass(frozen=True)
class Policy:
    coefficient_min: Decimal = Decimal("0.94")
    coefficient_max: Decimal = Decimal("1.00")
    max_step: Decimal = Decimal("0.002")
    index_min: Decimal = Decimal("0.98")
    index_max: Decimal = Decimal("1.01")
    target: Decimal = Decimal("0.995")

    def __post_init__(self):
        # These limits are business rules, narrower than the API's 0.5–1.2.
        if (self.coefficient_min != Decimal(".94") or self.coefficient_max != 1
                or not Decimal("0") < self.max_step <= Decimal(".002")
                or self.index_min != Decimal(".98") or self.index_max != Decimal("1.01")
                or self.target != Decimal(".995")):
            raise ValueError("Недопустимые границы регулирования.")


class SellerAPI:
    BASE_URL = "https://api-seller.ozon.ru"
    READ_PATHS = frozenset({
        "/v3/product/list", "/v3/product/info/list", "/v5/product/info/prices",
        "/v1/product/prices/details", "/v1/pricing-strategy/info", "/v1/pricing-strategy/list",
        "/v1/pricing-strategy/products/list", "/v1/pricing-strategy/product/info",
        "/v1/pricing-strategy/strategy-ids-by-product-ids",
    })
    WRITE_PATHS = frozenset({
        "/v1/product/import/prices", "/v1/pricing-strategy/update", "/v1/pricing-strategy/create",
        "/v1/pricing-strategy/status", "/v1/pricing-strategy/products/add",
        "/v1/pricing-strategy/products/delete",
    })

    def __init__(self, client_id, api_key, *, session=None, sleep=time.sleep,
                 clock=time.monotonic):
        if not client_id or not api_key:
            raise ValueError("Задайте OZON_CLIENT_ID и OZON_API_KEY на сервере.")
        self._client_id, self._key = str(client_id), str(api_key)
        self._session = session or requests.Session()
        self._sleep, self._clock, self._next = sleep, clock, {}
        self.audit_log = []

    def _safe(self, value):
        text = str(value)
        for secret in (self._key, self._client_id):
            text = text.replace(secret, "[скрыто]")
        return text[:1200]

    def post(self, path, payload):
        if path not in self.READ_PATHS | self.WRITE_PATHS:
            raise ValueError("Метод не разрешён клиентом.")
        read = path in self.READ_PATHS
        event = None
        if not read:
            event = {"at": utc_now(), "method": path, "request": self._safe(json.dumps(payload, ensure_ascii=False)), "status": "pending"}
            self.audit_log.append(event)
            del self.audit_log[:-100]
        for attempt in range(3 if read else 1):
            delay = self._next.get(path, 0) - self._clock()
            if delay > 30:
                raise StrategyError(f"{path}: выдержите Retry-After, ещё {delay:.0f} сек.")
            if delay > 0:
                self._sleep(delay)
            try:
                response = self._session.post(self.BASE_URL + path, json=payload,
                    headers={"Client-Id": self._client_id, "Api-Key": self._key},
                    timeout=(10, 45), allow_redirects=False)
            except requests.RequestException:
                if event is not None:
                    event["status"] = "transport_error"
                raise StrategyError(f"{path}: ошибка соединения; результат записи может быть неизвестен.") from None
            if event is not None:
                event["status"] = response.status_code
                event["response"] = self._safe(response.text)
            self._next[path] = self._clock() + 1
            if response.status_code != 429 or not read:
                break
            retry = response.headers.get("Retry-After", "")
            try:
                delay = max(0., float(retry))
                if not Decimal(str(delay)).is_finite():
                    raise ValueError
            except (ValueError, InvalidOperation):
                try:
                    delay = max(0., parsedate_to_datetime(retry).timestamp() - time.time())
                except (ValueError, TypeError, OverflowError):
                    delay = 2. * (2 ** attempt)
            self._next[path] = self._clock() + max(1., delay)
            if delay > 30:
                raise StrategyError(f"{path}: HTTP 429, подождите {delay:.0f} сек.")
        if response.status_code != 200:
            error = StrategyError(self._safe(f"{path}: HTTP {response.status_code}; {response.text}"))
            error.http_status = response.status_code
            raise error
        try:
            data = response.json()
        except ValueError:
            raise StrategyError(f"{path}: ответ не является JSON.") from None
        if not isinstance(data, dict):
            raise StrategyError(f"{path}: неожиданный формат ответа.")
        return data


class StrategyService:
    """One service per Seller account + existing shared strategy.

    All mutations must run under an account-wide lock supplied by the host.
    snapshot/catalog never write. verify can remove an unsafe product only.
    """

    def __init__(self, api, strategy_id, *, competitor_id=16942991, policy=None,
                 sleep=time.sleep, clock=time.monotonic):
        self.api, self.strategy_id = api, str(UUID(str(strategy_id)))
        self.competitor_id = int(identifier(competitor_id))
        self.policy = policy or Policy()
        self._sleep, self._clock = sleep, clock

    def strategy(self):
        data = self.api.post("/v1/pricing-strategy/info", {"strategy_id": self.strategy_id}).get("result")
        if not isinstance(data, dict):
            raise StrategyError("Нет настроек стратегии.")
        competitors = data.get("competitors")
        if (data.get("type") != "COMP_PRICE" or not isinstance(competitors, list)
                or len(competitors) != 1
                or str(competitors[0].get("competitor_id")) != str(self.competitor_id)):
            raise StrategyError("Нужна пользовательская стратегия только с выбранным Wildberries.")
        coefficient = number(competitors[0].get("coefficient"))
        if not isinstance(data.get("enabled"), bool) or not isinstance(data.get("name"), str):
            raise StrategyError("Не определены имя или активность стратегии.")
        return data

    def members(self):
        return self._members_for(self.strategy_id)

    def _members_for(self, strategy_id):
        data = self.api.post("/v1/pricing-strategy/products/list", {"strategy_id": strategy_id})
        values = data.get("result", {}).get("product_id")
        if not isinstance(values, list):
            raise StrategyError("Не получен состав стратегии.")
        ids = [identifier(v) for v in values]
        if len(set(ids)) != len(ids):
            raise StrategyError("API вернул повторяющиеся товары стратегии.")
        return set(ids)

    def _assignments(self, product_ids):
        """Read actual product membership using the API documented for this purpose."""
        result = {}
        for group in batches(sorted(set(product_ids)), 50):
            data = self.api.post("/v1/pricing-strategy/strategy-ids-by-product-ids", {"product_id": group})
            payload = data.get("result")
            if payload is None:
                payload = {}
            if not isinstance(payload, dict):
                raise StrategyError("Не получены данные привязки товаров к стратегиям.")
            rows = payload.get("products_info")
            if rows is None:
                rows = []
            if not isinstance(rows, list):
                raise StrategyError("Некорректный список привязок товаров к стратегиям.")
            seen = set()
            for row in rows:
                if not isinstance(row, dict):
                    raise StrategyError("Некорректная запись привязки товара к стратегии.")
                pid = identifier(row.get("product_id"))
                if pid not in group or pid in seen:
                    raise StrategyError("Неоднозначный ответ привязки товаров к стратегиям.")
                seen.add(pid)
                result[pid] = strategy_identifier(row.get("strategy_id"))
            for pid in group:
                result.setdefault(pid, "")
        return result

    def _preflight_assignments(self, selected, resolved, assignments):
        """Confirm a foreign owner before blocking; distinguish system membership."""
        owners, owner_members, system, notes = {}, {}, {}, []
        for product in selected:
            pid = str(resolved[product.sku]["id"])
            other = assignments[pid]
            if other in {"", self.strategy_id}:
                continue
            if other not in owners:
                try:
                    raw = self.api.post("/v1/pricing-strategy/info", {"strategy_id": other}).get("result")
                except StrategyError as error:
                    if getattr(error, "http_status", None) != 404:
                        raise
                    raw = None
                if raw is not None and not isinstance(raw, dict):
                    raise StrategyError(f"Не удалось проверить стратегию {other} из привязки товара.")
                owners[other] = raw
                if raw is not None:
                    owner_members[other] = self._members_for(other)
            owner = owners[other]
            if owner is None:
                notes.append(f"SKU {product.sku}: ID {other} относится к удалённой стратегии (HTTP 404); привязка не блокирует добавление.")
                continue
            if pid not in owner_members[other]:
                notes.append(f"SKU {product.sku}: ID {other} не подтверждён составом той стратегии; добавление проверит Ozon.")
                continue
            if owner.get("type") == "MIN_EXT_PRICE":
                system[pid] = other
                continue
            if owner.get("type") != "COMP_PRICE":
                raise StrategyError(f"SKU {product.sku}: неизвестный тип стратегии {owner.get('type')}, ID {other}. Привязка требует проверки.")
            raise StrategyError(f"SKU {product.sku} действительно входит в другую пользовательскую стратегию "
                                f"«{owner.get('name') or other}» (ID {other}). Это подтверждено составом стратегии. "
                                "Сначала исключите товар из неё; остальные кампании автоматически не меняются.")
        return system, notes

    def _detach_system(self, system):
        if not system:
            return []
        current = self._assignments(system)
        confirmed = []
        for pid, expected in system.items():
            if current[pid] in {"", self.strategy_id}:
                continue
            if current[pid] != expected:
                raise StrategyError(f"У товара {pid} изменилась привязка. Обновите данные перед добавлением.")
            owner = self.api.post("/v1/pricing-strategy/info", {"strategy_id": expected}).get("result", {})
            if owner.get("type") != "MIN_EXT_PRICE" or pid not in self._members_for(expected):
                raise StrategyError(f"Системная привязка товара {pid} не подтверждена; удаление не отправлено.")
            confirmed.append(pid)
        for group in batches(confirmed, 50):
            result = self.api.post("/v1/pricing-strategy/products/delete", {"product_id": group}).get("result", {})
            if result.get("failed_product_count") != 0:
                raise StrategyError("Исключение товаров из системной стратегии не подтверждено.")
        for attempt in range(5):
            remaining = self._assignments(confirmed)
            if all(value in {"", self.strategy_id} for value in remaining.values()):
                return confirmed
            if attempt < 4:
                self._sleep(1)
        raise StrategyError("Ozon ещё возвращает привязку к системной стратегии после удаления. Перечитайте состояние, не повторяйте запись вслепую.")

    def _resolve(self, products):
        products = list(products)
        if len({p.sku for p in products}) != len(products):
            raise ValueError("SKU не должны повторяться.")
        result = {}
        for group in batches(products, 1000):
            data = self.api.post("/v3/product/info/list", {"sku": [p.sku for p in group]})
            items = data.get("items")
            if not isinstance(items, list):
                raise StrategyError("Нет списка товаров по SKU.")
            for p in group:
                matches = [row for row in items if p.sku in
                           {str(row.get("sku")), *(str(s.get("sku")) for s in row.get("sources") or [])}]
                if len(matches) != 1:
                    raise StrategyError(f"SKU {p.sku}: нет однозначного товара в кабинете.")
                result[p.sku] = matches[0]
        ids = [identifier(v.get("id")) for v in result.values()]
        if len(set(ids)) != len(ids):
            raise ValueError("Несколько выбранных SKU относятся к одному product_id; оставьте одну строку.")
        return result

    def _prices(self, ids):
        result = {}
        for group in batches(sorted(ids), 1000):
            data = self.api.post("/v5/product/info/prices", {
                "filter": {"product_id": group, "visibility": "ALL"}, "limit": 1000})
            items = data.get("items")
            if not isinstance(items, list):
                raise StrategyError("Нет списка цен товаров.")
            for row in items:
                key = identifier(row.get("product_id"))
                if key not in group or key in result:
                    raise StrategyError("Неоднозначный ответ цен товаров.")
                result[key] = row
            if not set(group) <= result.keys():
                raise StrategyError("Получены не все цены выбранных товаров.")
        return result

    def _binding(self, product_id):
        data = self.api.post("/v1/pricing-strategy/product/info", {"product_id": int(product_id)})
        result = data.get("result")
        if not isinstance(result, dict):
            raise StrategyError("Нет данных участия товара в стратегии.")
        return result

    def _price_owner_conflicts(self, bindings, assignments):
        """Do not confirm the target when active price data proves another owner."""
        conflicts, owners, owner_members = {}, {}, {}
        for pid, binding in bindings.items():
            other = strategy_identifier(binding.get("strategy_id"))
            if assignments.get(pid) != self.strategy_id or other in {"", self.strategy_id} or binding.get("is_enabled") is not True:
                continue
            if other not in owners:
                try:
                    owner = self.api.post("/v1/pricing-strategy/info", {"strategy_id": other}).get("result")
                    owners[other] = owner
                    owner_members[other] = self._members_for(other) if isinstance(owner, dict) else set()
                except StrategyError as error:
                    if getattr(error, "http_status", None) == 404:
                        owners[other], owner_members[other] = None, set()
                    else:
                        conflicts[pid] = f"Не удалось проверить активную привязку из данных цены: {other}. {error}"
                        continue
            if pid in owner_members[other]:
                owner = owners[other]
                conflicts[pid] = f"Данные API расходятся: справочник указывает выбранную кампанию, а данные цены и состав «{owner.get('name') or other}» подтверждают {other}."
        return conflicts

    def catalog(self, *, last_id="", limit=100):
        """A page of candidates. Join saved choices by SKU on the website."""
        if not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit: от 1 до 1000.")
        data = self.api.post("/v3/product/list", {
            "filter": {"visibility": "ALL"}, "last_id": last_id, "limit": limit}).get("result", {})
        items = data.get("items")
        if not isinstance(items, list):
            raise StrategyError("Нет страницы каталога.")
        ids = [identifier(row.get("product_id")) for row in items]
        details = self.api.post("/v3/product/info/list", {"product_id": ids}).get("items", []) if ids else []
        members = self.members()
        return {"items": [{"product_id": identifier(p.get("id")), "offer_id": p.get("offer_id"),
                "name": p.get("name"), "sku": p.get("sku"),
                "source_skus": [str(s["sku"]) for s in p.get("sources") or [] if s.get("sku")],
                "in_strategy": str(p.get("id")) in members} for p in details],
                "last_id": data.get("last_id"), "total_items": data.get("total_items")}

    def _own_links(self, products):
        result = {}
        for group in batches(products, 1000):
            data = self.api.post("/v1/product/prices/details", {"skus": [p.sku for p in group]})
            rows = data.get("prices")
            if not isinstance(rows, list):
                raise StrategyError("Нет собственных цен Premium Pro.")
            for p in group:
                matches = [r for r in rows if str(r.get("sku")) == p.sku]
                if len(matches) != 1:
                    result[p.sku] = []
                    continue
                r = matches[0]
                urls = [v.get("self_wb_url") for v in r.get("weight_index") or []]
                urls += [(v.get("self_index_data") or {}).get("url") for v in r.get("price_indexes") or []]
                valid = []
                for url in urls:
                    try:
                        wb_article(url)
                    except ValueError:
                        continue
                    if url not in valid:
                        valid.append(url)
                result[p.sku] = valid
        return result

    def snapshot(self, products):
        """Fresh detailed rows and arithmetic mean of actual strategy members."""
        products = list(products)
        info, listed_members = self.strategy(), self.members()
        coefficient_ok = self.policy.coefficient_min <= number(info["competitors"][0]["coefficient"]) <= self.policy.coefficient_max
        resolved = self._resolve(products)
        ids = {str(v["id"]) for v in resolved.values()}
        assignments = self._assignments(ids | listed_members)
        prices = self._prices(ids)
        bindings = {p.sku: self._binding(str(resolved[p.sku]["id"])) for p in products}
        by_pid = {str(resolved[p.sku]["id"]): bindings[p.sku] for p in products}
        conflicts = self._price_owner_conflicts(by_pid, assignments)
        inactive_price_ids = {pid for pid, binding in by_pid.items()
                              if info["enabled"] and binding.get("is_enabled") is False}
        members = {pid for pid in listed_members if assignments.get(pid) == self.strategy_id}
        members -= set(conflicts) | inactive_price_ids
        fallback = [p for p in products if str(resolved[p.sku]["id"]) in members and (
                    strategy_identifier(bindings[p.sku].get("strategy_id")) != self.strategy_id
                    or not bindings[p.sku].get("strategy_competitor_product_url"))]
        notes, links = [], {}
        notes.extend(conflicts.values())
        unconfirmed = sorted(listed_members - members)
        if unconfirmed:
            notes.append("Записи из списка стратегии не подтверждены фактическим участием: " + ", ".join(unconfirmed))
        if fallback:
            try:
                links = self._own_links(fallback)
            except StrategyError as error:
                notes.append(str(error))
        rows, indices, zero_count, missing_count, ready = [], [], 0, 0, True
        for p in products:
            meta, binding = resolved[p.sku], bindings[p.sku]
            pid = str(meta["id"])
            item = prices[pid]
            price = item.get("price") or {}
            member = pid in members
            assigned_id = assignments[pid]
            reported_id = strategy_identifier(binding.get("strategy_id"))
            active = member and info["enabled"] and assigned_id == self.strategy_id
            membership_pending = not member and (pid in listed_members or assigned_id == self.strategy_id)
            current_price_info = reported_id == self.strategy_id and assigned_id == self.strategy_id
            raw = binding.get("strategy_competitor_product_url") if current_price_info else None
            urls = [str(raw)] if raw else links.get(p.sku, [])
            source = "pricing-strategy/product/info" if raw else "prices/details" if urls else None
            try:
                matches = bool(urls) and {wb_article(url) for url in urls} == {wb_article(p.wb_url)}
            except ValueError:
                matches = False
            link_status = "expected_missing" if not p.wb_url else "matched" if matches else "mismatch" if urls else "pending"
            try:
                floor_saved = number(price.get("min_price")) == number(p.min_price)
            except ValueError:
                floor_saved = False
            own = (item.get("price_indexes") or {}).get("self_marketplaces_index_data") or {}
            try:
                index = number(own.get("price_index_value"))
                if index < 0:
                    raise ValueError
            except ValueError:
                index = None
            if member:
                if index is None:
                    missing_count += 1
                elif index == 0:
                    zero_count += 1
                else:
                    indices.append(index)
            synchronized = member == p.selected
            ready &= synchronized and (not member or (active and matches and floor_saved and index is not None))
            rows.append({"sku": p.sku, "product_id": pid, "offer_id": meta.get("offer_id"),
                "name": meta.get("name"), "selected": p.selected, "in_strategy": member,
                "listed_in_strategy": pid in listed_members, "membership_pending": membership_pending,
                "membership_conflict": conflicts.get(pid),
                "active": active, "coefficient": str(info["competitors"][0]["coefficient"]),
                "min_price": p.min_price, "saved_min_price": price.get("min_price"),
                "floor_saved": floor_saved, "ozon_price": price.get("price"),
                "strategy_price": binding.get("strategy_product_price") if current_price_info else None,
                "expected_wb_url": p.wb_url, "actual_wb_urls": urls, "link_source": source,
                "link_status": link_status, "strategy_id": assigned_id,
                "reported_strategy_id": binding.get("strategy_id"),
                "assignment_source": "strategy-ids-by-product-ids",
                "price_info_current": current_price_info,
                "price_downloaded_at": (binding.get("price_downloaded_at") or None) if current_price_info else None,
                "price_index": str(index) if index is not None else None})
        unknown = sorted(members - ids)
        complete = not unknown and missing_count == 0
        mean = sum(indices, Decimal(0)) / len(indices) if indices and complete else None
        status = "no_data" if mean is None else "below" if mean < self.policy.index_min else "above" if mean > self.policy.index_max else "in_range"
        return {"checked_at": utc_now(), "strategy_id": self.strategy_id, "strategy_name": info["name"], "enabled": info["enabled"],
            "coefficient": str(info["competitors"][0]["coefficient"]),
            "coefficient_status": "in_range" if coefficient_ok else "out_of_range",
            "coefficient_range": [str(self.policy.coefficient_min), str(self.policy.coefficient_max)],
            "max_step": str(self.policy.max_step), "index_range": [str(self.policy.index_min), str(self.policy.index_max)],
            "mean_index": str(mean) if mean is not None else None, "index_status": status,
            "member_count": len(members), "nonzero_count": len(indices), "zero_count": zero_count,
            "listed_member_count": len(listed_members), "unconfirmed_member_ids": unconfirmed,
            "missing_count": missing_count, "untracked_product_ids": unknown,
            "ready": bool(ready and complete and coefficient_ok and info["enabled"] and indices), "rows": rows, "notes": notes,
            "membership_evidence": {"strategy": info, "listed_product_ids": sorted(listed_members),
                                    "assignments": assignments, "product_info": by_pid}}

    def _remove(self, product_ids):
        """Never disable a whole shared strategy due to a single bad link."""
        owned = []
        assignments = self._assignments(product_ids)
        for pid in sorted(product_ids):
            if assignments[pid] == self.strategy_id:
                owned.append(pid)
        for group in batches(owned, 50):
            result = self.api.post("/v1/pricing-strategy/products/delete", {"product_id": group}).get("result", {})
            if result.get("failed_product_count") != 0:
                raise StrategyError("Удаление части товаров из стратегии не подтверждено.")
        if any(value == self.strategy_id for value in self._assignments(owned).values()):
            raise StrategyError("Исключение товаров не подтверждено фактической привязкой; требуется повторная проверка.")
        return owned

    def verify(self, products, *, timeout=120, interval=5):
        """Wait for own links; remove mismatches immediately, unresolved on timeout."""
        if timeout < 0 or interval <= 0:
            raise ValueError("Некорректное время проверки.")
        products = list(products)
        deadline = self._clock() + timeout
        actions = []
        while True:
            report = self.snapshot(products)
            bad = {r["product_id"] for r in report["rows"] if r["in_strategy"] and (
                r["link_status"] == "mismatch" or not r["floor_saved"])}
            pending = {r["product_id"] for r in report["rows"] if r["selected"] and (
                (r["in_strategy"] and r["link_status"] == "pending") or
                (r["membership_pending"] and not r["membership_conflict"] and r["strategy_id"] in {"", self.strategy_id}))}
            if pending and self._clock() >= deadline:
                bad |= pending
            if bad:
                removed = self._remove(bad)
                actions.append({"action": "products_removed", "product_ids": removed,
                                "reason": "WB-ссылка или участие не подтверждены либо ограничение цены не сохранено"})
                report = self.snapshot(products)
            if not pending or self._clock() >= deadline:
                report["actions"] = actions
                return report
            self._sleep(min(interval, max(0, deadline - self._clock())))

    def _save_floor(self, product, product_id, price):
        floor, current = number(product.min_price), number(price.get("price"))
        if current <= 0:
            raise StrategyError(f"SKU {product.sku}: некорректная предельная цена.")
        result = self.api.post("/v1/product/import/prices", {"prices": [{
            "product_id": int(product_id), "price": str(max(current, floor)), "min_price": str(floor),
            "currency_code": price.get("currency_code") or "RUB",
            "min_price_for_auto_actions_enabled": True, "price_strategy_enabled": "UNKNOWN",
        }]}).get("result", [])
        if (len(result) != 1 or str(result[0].get("product_id")) != product_id
                or result[0].get("updated") is not True or result[0].get("errors")):
            raise StrategyError(f"SKU {product.sku}: сохранение цены отклонено или не подтверждено.")

    def apply_selection(self, products, *, verify_timeout=120):
        """Apply saved choices to the one existing strategy; retain coefficient."""
        products = list(products)
        if any(p.selected and not p.wb_url for p in products):
            raise ValueError("Укажите ожидаемую WB-ссылку каждого выбранного товара до применения.")
        info, listed_members = self.strategy(), self.members()
        if not self.policy.coefficient_min <= number(info["competitors"][0]["coefficient"]) <= self.policy.coefficient_max:
            raise StrategyError("До добавления товаров приведите коэффициент к диапазону 0,94–1,00.")
        resolved = self._resolve(products)
        ids = {str(v["id"]) for v in resolved.values()}
        assignments = self._assignments(ids | listed_members)
        members = {pid for pid in listed_members if assignments.get(pid) == self.strategy_id}
        if members - ids:
            raise StrategyError("Сначала добавьте в список сайта все текущие товары этой стратегии.")
        selected = [p for p in products if p.selected]
        system, preflight_notes = self._preflight_assignments(selected, resolved, assignments)
        # A stale list/ID may remain after manual removal; an explicitly inactive
        # product in an enabled campaign must be attached again by the target ID.
        price_before = {str(resolved[p.sku]["id"]): self._binding(str(resolved[p.sku]["id"])) for p in selected}
        inactive_before = {pid for pid, data in price_before.items() if info["enabled"] and data.get("is_enabled") is False}
        # Complete preflight before any mutation. Never steal a different strategy's product.
        prices = self._prices(ids)
        deselected = {str(resolved[p.sku]["id"]) for p in products if not p.selected} & members
        self._remove(deselected)
        for p in selected:
            pid = str(resolved[p.sku]["id"])
            self._save_floor(p, pid, prices[pid].get("price") or {})
        fresh = self._prices({str(resolved[p.sku]["id"]) for p in selected})
        for p in selected:
            if number(fresh[str(resolved[p.sku]["id"])]["price"].get("min_price")) != number(p.min_price):
                raise StrategyError(f"SKU {p.sku}: ограничение ещё не подтверждено; добавление остановлено.")
        transferred = self._detach_system(system)
        desired = {str(resolved[p.sku]["id"]) for p in selected}
        current_assignments = self._assignments(desired)
        to_add = {pid for pid in desired if current_assignments[pid] != self.strategy_id or pid in inactive_before}
        for group in batches(sorted(to_add), 50):
            result = self.api.post("/v1/pricing-strategy/products/add", {
                "strategy_id": self.strategy_id, "product_id": group}).get("result", {})
            if result.get("failed_product_count") != 0 or result.get("errors"):
                raise StrategyError("Добавление части товаров в стратегию не подтверждено.")
        for attempt in range(5):
            listed = self.members()
            actual = self._assignments(listed | desired)
            actual_ours = {pid for pid, owner in actual.items() if owner == self.strategy_id}
            if actual_ours == desired and desired <= listed:
                break
            if attempt < 4:
                self._sleep(1)
        else:
            details = ", ".join(f"{pid}: {actual.get(pid) or 'нет привязки'}" for pid in sorted(desired))
            raise StrategyError("Добавление именно в выбранную кампанию не подтверждено. Фактическая привязка: " + details)
        if selected and not info["enabled"]:
            self.api.post("/v1/pricing-strategy/status", {"strategy_id": self.strategy_id, "enabled": True})
        if selected and not self.strategy()["enabled"]:
            raise StrategyError("Включение стратегии не подтверждено.")
        # No price_strategy_enabled=ENABLED: it may select Ozon's system strategy.
        final_assignments = self._assignments(desired)
        if any(owner != self.strategy_id for owner in final_assignments.values()):
            details = ", ".join(f"{pid}: {owner or 'нет привязки'}" for pid, owner in final_assignments.items())
            raise StrategyError("После включения товары не подтверждены в выбранной кампании: " + details)
        try:
            report = self.verify(products, timeout=verify_timeout)
        except StrategyError as error:
            try:
                self._remove(desired)
            except StrategyError as cleanup:
                raise StrategyError(f"{error} Исключение товаров также не подтверждено: {cleanup}") from None
            raise StrategyError(f"{error} Выбранные товары исключены из общей стратегии.") from None
        deliberately_removed = {pid for action in report.get("actions", []) for pid in action.get("product_ids", [])}
        confirmed = {row["product_id"] for row in report["rows"] if row["in_strategy"]}
        if desired - confirmed - deliberately_removed:
            raise StrategyError("Участие товаров именно в выбранной кампании не подтверждено. Смотрите диагностику привязки; счётчик списка Ozon не является подтверждением.")
        report["notes"].extend(preflight_notes)
        if transferred:
            report["notes"].append("Товары переведены из системной стратегии в выбранную: " + ", ".join(transferred))
        return report

    def change_coefficient(self, value, *, expected_current, expected_members):
        """Optimistic concurrency check + small bounded change, followed by readback."""
        info = self.strategy()
        old, new = number(info["competitors"][0]["coefficient"]), number(value)
        if not info["enabled"] or old != number(expected_current) or self.members() != set(expected_members):
            raise StrategyError("Настройки или состав изменились; обновите данные и пересчитайте план.")
        if not self.policy.coefficient_min <= new <= self.policy.coefficient_max:
            raise ValueError("Коэффициент должен быть в диапазоне 0,94–1,00.")
        if abs(new - old) > self.policy.max_step:
            raise ValueError("Изменение за один шаг не должно превышать 0,002.")
        if new != old:
            competitors = [dict(c) for c in info["competitors"]]
            competitors[0]["coefficient"] = float(new)
            self.api.post("/v1/pricing-strategy/update", {"strategy_id": self.strategy_id,
                "strategy_name": info["name"], "competitors": competitors})
        if number(self.strategy()["competitors"][0]["coefficient"]) != new:
            raise StrategyError("Новый коэффициент ещё не подтверждён чтением.")
        return str(new)

    def plan(self, report):
        old = number(report["coefficient"])
        if not report["ready"]:
            return {"status": "blocked", "reason": "Неполные данные, состав, ссылки или ограничения не подтверждены."}
        if report["index_status"] == "in_range":
            return {"status": "in_range", "coefficient": str(old)}
        mean = number(report["mean_index"])
        raw = old * self.policy.target / mean
        new = min(self.policy.coefficient_max, old + self.policy.max_step,
                  max(self.policy.coefficient_min, old - self.policy.max_step, raw))
        # Millesimal proposals; actual server precision is checked by readback.
        new = new.quantize(Decimal(".001"))
        if abs(new - old) > self.policy.max_step:
            new = old
        return {"status": "limit_reached" if new == old else "adjustment_proposed",
                "old_coefficient": str(old), "new_coefficient": str(new),
                "mean_index": str(mean), "target": str(self.policy.target)}

    @staticmethod
    def _baseline(report):
        def canonical(value):
            return str(number(value).normalize()) if value is not None else None
        return sorted((r["product_id"], canonical(r["price_index"]), canonical(r["ozon_price"]))
                      for r in report["rows"] if r["in_strategy"])

    def cycle(self, products, state, *, write=False, metric_confirmed=False, persist=None):
        """A scheduled cycle. Caller must persist intent before writes and hold a lock.

        Pending writes are never automatically replayed. A later cycle observes
        changed prices/indices before another correction can be considered.
        """
        products = list(products)
        if not write:
            state = copy.deepcopy(state)
        report = self.verify(products) if write else self.snapshot(products)
        plan = self.plan(report)
        result = {"snapshot": report, "plan": plan, "coefficient_written": False}
        pending = state.get("pending")
        baseline = self._baseline(report)
        if pending:
            current = number(report["coefficient"])
            if current != number(pending["new_coefficient"]):
                result["plan"] = {"status": "pending_conflict", "reason": "Предыдущая запись не подтверждена или коэффициент изменён вручную."}
            elif report["index_status"] == "in_range" and report["ready"]:
                state.pop("pending", None)
                result["plan"] = {"status": "in_range"}
            elif not report["ready"] or [(r[0], number(r[1]) == 0) for r in baseline] != [
                    (r[0], number(r[1]) == 0) for r in pending["baseline"]]:
                result["plan"] = {"status": "pending_composition_changed", "reason": "Состав или качество данных изменились; требуется разбор."}
            elif baseline == [tuple(row) for row in pending["baseline"]]:
                result["plan"] = {"status": "waiting_for_effect"}
            else:
                state.pop("pending", None)
                result["plan"] = {"status": "effect_observed", "reason": "Есть новые цены/индексы. Следующая коррекция возможна в следующем цикле."}
        elif write and plan["status"] == "adjustment_proposed":
            if not metric_confirmed:
                result["plan"] = {**plan, "status": "metric_not_confirmed"}
            elif persist is None:
                raise ValueError("Для записи необходим persist: сохранить намерение до HTTP-запроса.")
            else:
                state["pending"] = {**plan, "created_at": utc_now(), "baseline": baseline}
                persist(state)
                self.change_coefficient(plan["new_coefficient"], expected_current=plan["old_coefficient"],
                                        expected_members=[r[0] for r in baseline])
                result["coefficient_written"] = True
                result["coefficient_after_write"] = plan["new_coefficient"]
                result["plan"] = {**plan, "status": "waiting_for_effect"}
        if write and persist is not None:
            state["last_run"] = result
            persist(state)
        return result


def list_strategies(api):
    """List campaigns without changing selection or enabling anything."""
    result, seen = [], set()
    for page in range(1, 1001):
        data = api.post("/v1/pricing-strategy/list", {"page": page, "limit": 49})
        rows = data.get("strategies")
        if not isinstance(rows, list):
            raise StrategyError("Не получен список стратегий.")
        for row in rows:
            key = str(UUID(str(row.get("id"))))
            if key in seen:
                raise StrategyError("Повторяющаяся страница списка стратегий.")
            seen.add(key)
            result.append({**row, "id": key})
        if len(rows) < 49 or len(result) >= data.get("total", float("inf")):
            return result
    raise StrategyError("Превышен предел страниц стратегий.")


def ensure_strategy(api, *, strategy_name, initial_coefficient="0.960", competitor_id=16942991,
                    state, persist):
    """Create a named campaign once, or recover its recorded ID.

    Persist the intent before create and the ID immediately after its response.
    An ambiguous create is not replayed. Existing matching campaigns retain k.
    The host must hold an account-wide lock, including the call to persist.
    """
    name = str(strategy_name).strip()
    coefficient = number(initial_coefficient)
    policy = Policy()
    if not name or not policy.coefficient_min <= coefficient <= policy.coefficient_max:
        raise ValueError("Задайте название и стартовый коэффициент в пределах 0,94–1,00.")
    if persist is None or not isinstance(state, dict):
        raise ValueError("Нужно хранилище состояния создания кампании.")
    setups = state.setdefault("strategy_setups", {})
    record = setups.get(name, {})
    if record.get("strategy_id"):
        service = StrategyService(api, record["strategy_id"], competitor_id=competitor_id)
        try:
            service.strategy()
        except StrategyError as error:
            if getattr(error, "http_status", None) != 404:
                raise
            setups[name] = {"status": "deleted", "previous_strategy_id": record["strategy_id"]}
            record = setups[name]
            persist(state)
        else:
            return service
    matches = [r for r in list_strategies(api) if r.get("name") == name]
    if len(matches) > 1:
        raise StrategyError("Несколько кампаний с этим названием. Выберите точный ID в списке.")
    if matches:
        service = StrategyService(api, matches[0]["id"], competitor_id=competitor_id)
        service.strategy()
        setups[name] = {"strategy_id": service.strategy_id, "status": "recovered"}
        persist(state)
        return service
    if record.get("status") == "creating":
        raise StrategyError("Результат предыдущего создания неизвестен. Обновите список и проверьте Ozon; повторное создание не отправлено.")
    setups[name] = {"status": "creating", "created_at": utc_now(), "initial_coefficient": str(coefficient)}
    persist(state)
    data = api.post("/v1/pricing-strategy/create", {"strategy_name": name,
        "competitors": [{"competitor_id": int(identifier(competitor_id)), "coefficient": float(coefficient)}]})
    result = data.get("result") or {}
    try:
        new_id = str(UUID(str(result.get("id") or result.get("strategy_id"))))
    except (ValueError, TypeError, AttributeError):
        raise StrategyError("Создание не вернуло корректный ID. Обновите список кампаний; не повторяйте создание вслепую.") from None
    setups[name] = {"status": "created", "strategy_id": new_id}
    persist(state)
    service = StrategyService(api, new_id, competitor_id=competitor_id)
    # Empty new campaign stays disabled until floor-setting and product attachment.
    api.post("/v1/pricing-strategy/status", {"strategy_id": new_id, "enabled": False})
    if service.strategy()["enabled"]:
        raise StrategyError("Кампания создана, но её выключенное состояние ещё не подтверждено. ID сохранён.")
    return service


def write_json(path, data):
    """Atomic mode-0600 state; the parent directory must be outside the web root."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2, default=str)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


@contextmanager
def worker_lock(path):
    """Linux CLI lock; website workers must share this lock or a DB/advisory lock."""
    import fcntl
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise StrategyError("Другой процесс уже работает с этой стратегией.") from None
        yield
    finally:
        os.close(fd)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["strategies", "create-and-enable", "catalog", "snapshot", "apply-selection", "verify", "cycle"])
    parser.add_argument("--config", required=True, help="Private JSON with strategy_id and products")
    parser.add_argument("--state", required=True, help="Persistent private worker state JSON")
    parser.add_argument("--write", action="store_true", help="Execute the requested mutations")
    args = parser.parse_args(argv)
    try:
        with worker_lock(Path(args.state).parent / "ozon-account.lock"):
            config = json.loads(Path(args.config).read_text(encoding="utf-8"))
            products = [Product(**p) for p in config.get("products", [])]
            client_id, key = os.getenv("OZON_CLIENT_ID"), os.getenv("OZON_API_KEY")
            api = SellerAPI(client_id, key)
            state_path = Path(args.state)
            state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
            persist = lambda value: write_json(state_path, value)
            if args.command == "strategies":
                print(json.dumps({"strategies": list_strategies(api)}, ensure_ascii=False, indent=2))
                return 0
            if args.command == "create-and-enable":
                if not args.write:
                    raise ValueError("Для создания и включения требуется --write.")
                if not any(p.selected for p in products) or any(p.selected and not p.wb_url for p in products):
                    raise ValueError("Выберите товары и заполните их ограничения и WB-ссылки.")
                if not config.get("strategy_id"):
                    if state.get("scope"):
                        raise StrategyError("Для новой кампании используйте новый файл состояния, чтобы не смешать её с предыдущей.")
                    service = ensure_strategy(api, strategy_name=config.get("strategy_name", "GE WB"),
                        initial_coefficient=config.get("initial_coefficient", "0.960"), state=state, persist=persist)
                    config["strategy_id"] = service.strategy_id
                    write_json(args.config, config)
                else:
                    service = StrategyService(api, config["strategy_id"])
            else:
                if not config.get("strategy_id"):
                    raise ValueError("Сначала создайте кампанию через create-and-enable или выберите её strategy_id.")
                service = StrategyService(api, config["strategy_id"])
            scope = hashlib.sha256((str(client_id) + ":" + service.strategy_id).encode()).hexdigest()
            if state.get("scope", scope) != scope:
                raise StrategyError("Файл состояния относится к другому кабинету/стратегии.")
            state["scope"] = scope
            if args.command in {"apply-selection", "verify"} and not args.write:
                raise ValueError("Для применения выбора/проверки с исключением товаров требуется --write.")
            if args.command == "create-and-enable":
                persist(state)
                result = service.apply_selection(products)
            elif args.command == "catalog":
                result = service.catalog()
            elif args.command == "snapshot":
                result = service.snapshot(products)
            elif args.command == "apply-selection":
                result = service.apply_selection(products)
            elif args.command == "verify":
                result = service.verify(products)
            else:
                if args.write and config.get("autoregulation") is not True:
                    raise ValueError("Автоматическое регулирование выключено в конфигурации.")
                result = service.cycle(products, state, write=args.write,
                    metric_confirmed=config.get("metric_confirmed") is True, persist=persist)
            if args.command != "cycle" and args.write:
                state["last_operation"] = {"command": args.command, "at": utc_now(), "result": result}
                persist(state)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0
    except (StrategyError, ValueError, KeyError, OSError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
