"""Hourly scheduling metadata. Contains no credentials or network operations."""
from datetime import datetime, timedelta, timezone


def timestamp(value):
    return value.astimezone(timezone.utc).isoformat()


def parse_timestamp(value):
    parsed = datetime.fromisoformat(str(value))
    if parsed.tzinfo is None:
        raise ValueError("Нужна дата с часовым поясом.")
    return parsed.astimezone(timezone.utc)


def default_schedule():
    return {"enabled": False, "interval_hours": 1, "metric_confirmed": False,
            "next_run_at": None, "revision": 0, "in_progress": False, "last_run": None}


def configure_schedule(payload, previous, now):
    enabled = payload.get("enabled")
    interval = payload.get("interval_hours")
    confirmed = payload.get("metric_confirmed", False)
    if not isinstance(enabled, bool) or not isinstance(confirmed, bool):
        raise ValueError("Некорректное состояние расписания.")
    if type(interval) is not int or not 1 <= interval <= 168:
        raise ValueError("Интервал: целое число от 1 до 168 часов.")
    if enabled and not confirmed:
        raise ValueError("Перед включением подтвердите сверку индекса API с шаблоном AJ.")
    result = {**default_schedule(), **previous}
    changed = any(result.get(key) != value for key, value in
                  [("enabled", enabled), ("interval_hours", interval), ("metric_confirmed", confirmed)])
    result.update(enabled=enabled, interval_hours=interval, metric_confirmed=confirmed)
    if changed:
        result["revision"] += 1
        result["next_run_at"] = timestamp(now + timedelta(hours=interval)) if enabled else None
    return result


def resume_schedules(schedules, now):
    """No replay/catch-up after losing the only in-memory credential session."""
    for cfg in schedules.values():
        if cfg.get("in_progress"):
            cfg["in_progress"] = False
            cfg["last_run"] = {"status": "interrupted", "finished_at": timestamp(now),
                               "message": "Прошлый запуск прерван. Запись не повторяется автоматически."}
        if cfg.get("enabled"):
            try:
                overdue = parse_timestamp(cfg.get("next_run_at")) <= now
            except ValueError:
                overdue = True
            if overdue:
                cfg["next_run_at"] = timestamp(now + timedelta(hours=cfg["interval_hours"]))
