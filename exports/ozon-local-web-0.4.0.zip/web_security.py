"""Standalone server settings and password verification; no Ozon credentials."""
from collections import deque
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import re
import secrets
import threading
import time
from urllib.parse import urlsplit

from argon2 import PasswordHasher, Type
from argon2.exceptions import InvalidHashError, VerificationError


PASSWORDS = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=1, type=Type.ID)


@dataclass(frozen=True)
class WebSettings:
    server: bool = False
    prefix: str = ""
    origin: str = ""
    username: str = ""
    password_hash: str = field(default="", repr=False)
    idle_seconds: int = 1800
    absolute_seconds: int = 28800

    def __post_init__(self):
        if self.prefix and not re.fullmatch(r"/[A-Za-z0-9_-]+", self.prefix):
            raise ValueError("GE_URL_PREFIX: нужен один путь без завершающего слеша.")
        if self.server:
            parsed = urlsplit(self.origin)
            if (parsed.scheme != "https" or not parsed.hostname or parsed.path not in {"", "/"}
                    or parsed.query or parsed.fragment or parsed.username or parsed.password
                    or self.origin.endswith("/")):
                raise ValueError("GE_PUBLIC_ORIGIN: нужен HTTPS-адрес без пути и завершающего слеша.")
            if not re.fullmatch(r"[A-Za-z0-9_.-]{3,64}", self.username):
                raise ValueError("Некорректный логин в файле входа.")
            # Fail closed, including malformed or deliberately weak hash settings.
            from argon2 import extract_parameters
            try:
                params = extract_parameters(self.password_hash)
            except (InvalidHashError, ValueError):
                raise ValueError("В файле входа нужен корректный хеш Argon2id.") from None
            if params.type != Type.ID or params.memory_cost < 65536 or params.time_cost < 3:
                raise ValueError("Используйте хеш, созданный configure_server.py.")
        if self.idle_seconds <= 0 or self.absolute_seconds < self.idle_seconds:
            raise ValueError("Некорректное время жизни сеанса.")

    @classmethod
    def from_env(cls):
        mode = os.environ.get("GE_SERVER_MODE", "0")
        if mode not in {"0", "1"}:
            raise ValueError("GE_SERVER_MODE должен быть 0 или 1.")
        if mode == "0":
            return cls()
        filename = os.environ.get("GE_AUTH_FILE", "")
        if not filename:
            raise ValueError("Серверный режим требует GE_AUTH_FILE. Вход без пароля запрещён.")
        try:
            data = json.loads(Path(filename).read_text())
            return cls(server=True, prefix=os.environ.get("GE_URL_PREFIX", "/great_equalizer"),
                       origin=os.environ.get("GE_PUBLIC_ORIGIN", "https://puls-mp.ru"),
                       username=data["username"], password_hash=data["password_hash"])
        except (OSError, KeyError, TypeError, json.JSONDecodeError):
            raise ValueError("Не удалось прочитать файл настройки входа.") from None

    def verify(self, username, password):
        if not isinstance(username, str) or not isinstance(password, str) or len(username) > 64 or len(password) > 1024:
            return False
        try:
            valid = PASSWORDS.verify(self.password_hash, password)
        except (VerificationError, InvalidHashError, UnicodeError):
            valid = False
        return valid and secrets.compare_digest(username.encode("utf-8", "surrogatepass"), self.username.encode())


class LoginLimiter:
    """Bound verification cost: 5 attempts/IP/15 min, 30 total attempts/minute."""
    def __init__(self, clock=time.monotonic):
        self.clock, self.lock = clock, threading.Lock()
        self.by_ip, self.total = {}, deque()
        self.verifications = threading.BoundedSemaphore(2)

    def reserve(self, ip):
        now = self.clock()
        with self.lock:
            self.by_ip = {key: deque(v for v in values if v > now-900)
                          for key, values in self.by_ip.items() if values and values[-1] > now-900}
            while self.total and self.total[0] <= now-60:
                self.total.popleft()
            attempts = self.by_ip.setdefault(ip, deque())
            if len(attempts) >= 5:
                return max(1, int(attempts[0]+900-now)+1)
            if len(self.total) >= 30 or len(self.by_ip) > 4096:
                return 60
            attempts.append(now)
            self.total.append(now)
        return 0

    def success(self, ip):
        with self.lock:
            self.by_ip.pop(ip, None)
