from datetime import datetime,timedelta,timezone
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from web_schedule import configure_schedule,default_schedule,parse_timestamp,resume_schedules

HAS_WEB=all(importlib.util.find_spec(name) is not None for name in ('fastapi','httpx','argon2'))
if HAS_WEB:
    import requests
    from fastapi.testclient import TestClient
    from ozon_strategy import SellerAPI
    from web_app import ACCOUNT_NAMES,create_app
    from web_demo import make_demo_api
    from web_security import PASSWORDS,WebSettings


class IntervalTests(unittest.TestCase):
    def test_whole_hour_intervals_and_no_immediate_first_run(self):
        now=datetime(2026,11,13,tzinfo=timezone.utc)
        for hours in [1,2,3,4,5,24,168]:
            cfg=configure_schedule({'enabled':True,'interval_hours':hours,'metric_confirmed':True},{},now)
            self.assertEqual(parse_timestamp(cfg['next_run_at']),now+timedelta(hours=hours))
        for hours in [0,169,True,1.5,'2',None]:
            with self.assertRaises(ValueError):
                configure_schedule({'enabled':True,'interval_hours':hours,'metric_confirmed':True},{},now)

    def test_resume_keeps_future_slots_and_does_not_replay_interrupted_or_overdue_run(self):
        now=datetime(2026,11,13,tzinfo=timezone.utc)
        cfg=configure_schedule({'enabled':True,'interval_hours':24,'metric_confirmed':True},{},now)
        due=cfg['next_run_at']
        resume_schedules({'sid':cfg},now+timedelta(hours=2))
        self.assertEqual(cfg['next_run_at'],due)
        cfg['in_progress']=True
        resume_schedules({'sid':cfg},now+timedelta(hours=25))
        self.assertFalse(cfg['in_progress'])
        self.assertEqual(cfg['last_run']['status'],'interrupted')
        self.assertGreater(parse_timestamp(cfg['next_run_at']),now+timedelta(hours=25))


class Clock:
    elapsed=0.0
    def mono(self):return 1000+self.elapsed
    def utc(self):return datetime(2026,11,13,tzinfo=timezone.utc)+timedelta(seconds=self.elapsed)
    def advance(self,seconds):self.elapsed+=seconds


class Transport:
    def __init__(self,demo):
        self.demo=demo
        self.pause=False
        self.entered,self.release=threading.Event(),threading.Event()
    def post(self,url,*,json,**kwargs):
        path=url.removeprefix(SellerAPI.BASE_URL)
        if self.pause:
            self.pause=False;self.entered.set();self.release.wait(2)
        response=requests.Response();response.status_code=200
        response._content=__import__('json').dumps(self.demo.post(path,json)).encode()
        return response
    def close(self):self.release.set()


@unittest.skipUnless(HAS_WEB,'Install web dependencies and httpx')
class SchedulerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.password_hash=PASSWORDS.hash('schedule-test-passphrase-2026')

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.clock=Clock()
        self.app=create_app(state_dir=self.temp.name,clock=self.clock.mono,wall_clock=self.clock.utc)
        self.client=TestClient(self.app);self.client.__enter__()
        self.open_session()
        self.job('load')
        self.sid=self.s.selected_id

    def open_session(self):
        initial=self.client.get('/api/session').json()
        self.headers={'X-CSRF-Token':initial['csrf']}
        self.s=self.app.state.sessions[self.client.cookies[self.app.state.cookie_name]]

    def tearDown(self):
        self.client.__exit__(None,None,None);self.temp.cleanup()

    def job(self,action,**data):
        response=self.client.post('/api/jobs',json={'action':action,**data},headers=self.headers)
        self.assertEqual(response.status_code,202,response.text)
        key=response.json()['job_id']
        for _ in range(1000):
            result=self.client.get('/api/jobs/'+key).json()
            if result.get('status')!='running':
                self.assertEqual(result.get('status'),'done',result)
                return result
            time.sleep(.002)
        self.fail('Job timeout')

    def connect(self,cid='230276',demo=None):
        self.demo=demo or make_demo_api()
        self.transport=Transport(self.demo)
        self.api=SellerAPI(cid,'test-only-key-'+cid,session=self.transport,sleep=lambda _:None)
        with patch('web_app.SellerAPI',return_value=self.api):
            self.job('connect',client_id=cid,api_key='test-only-key-'+cid)
        self.sid=self.s.selected_id

    def schedule(self,enabled=True,hours=1,confirmed=True):
        return self.client.post('/api/schedule',json={'enabled':enabled,'interval_hours':hours,
            'metric_confirmed':confirmed,'strategy_id':self.s.selected_id},headers=self.headers)

    def settle(self,sid=None):
        sid=sid or self.sid
        for _ in range(1000):
            if not self.s.busy and not self.s.schedules[sid]['in_progress']:
                return self.s.schedules[sid]
            time.sleep(.002)
        self.fail('Scheduler timeout')

    def writes(self):
        return [path for path,_ in self.demo.calls if path in SellerAPI.WRITE_PATHS]

    def test_initially_disabled_and_configuration_is_validated_without_writes(self):
        self.assertFalse(self.client.get('/api/state').json()['schedule']['enabled'])
        self.assertEqual(self.schedule(confirmed=False).status_code,400)
        for hours in [0,169,'2',True,1.5]:self.assertEqual(self.schedule(hours=hours).status_code,400)
        self.s.api.products['2077805520']['index']=None
        self.assertEqual(self.schedule().status_code,409)

    def test_in_range_cycle_runs_once_at_due_time_and_holds_coefficient(self):
        self.connect()
        self.assertEqual(self.schedule().status_code,200)
        self.app.state.scheduler_tick()
        self.assertEqual(self.writes(),[])
        self.clock.advance(3599);self.app.state.scheduler_tick()
        self.assertEqual(self.writes(),[])
        self.clock.advance(1);self.app.state.scheduler_tick()
        cfg=self.settle()
        self.assertEqual(cfg['last_run']['status'],'in_range')
        self.assertEqual(self.demo.strategies[self.sid]['coefficient'],.96)
        self.assertEqual(self.writes(),[])

    def test_outside_mean_changes_only_once_and_intent_precedes_the_write(self):
        self.connect();self.demo.products['2077805520']['index']='1.05'
        self.assertEqual(self.schedule().status_code,200)
        def before_update():
            saved=json.loads(next(Path(self.temp.name).glob('*.json')).read_text())
            self.assertTrue(saved['schedules'][self.sid]['in_progress'])
            self.assertTrue(saved['cycle_states'][self.sid]['pending'])
        self.demo.before_update=before_update
        self.clock.advance(3600)
        self.app.state.scheduler_tick();self.app.state.scheduler_tick()
        cfg=self.settle()
        self.assertTrue(cfg['last_run']['coefficient_written'])
        self.assertEqual(self.demo.strategies[self.sid]['coefficient'],.95)
        self.assertEqual(self.writes().count('/v1/pricing-strategy/update'),1)
        self.assertNotIn('/v1/product/import/prices',self.writes())
        self.assertEqual(self.demo.products['2077805520']['floor'],'2700')
        self.app.state.scheduler_tick()
        self.assertEqual(self.writes().count('/v1/pricing-strategy/update'),1)

    def test_two_consecutive_intervals_do_not_accumulate_changes_before_observation(self):
        self.connect();self.demo.products['2077805520']['index']='1.05';self.schedule()
        self.clock.advance(3600);self.app.state.scheduler_tick();self.settle()
        self.demo.before_update=None
        self.clock.advance(3600);self.app.state.scheduler_tick();cfg=self.settle()
        self.assertEqual(cfg['last_run']['status'],'effect_observed')
        self.assertEqual(self.writes().count('/v1/pricing-strategy/update'),1)

    def test_missed_interval_is_skipped_without_catch_up(self):
        self.connect();self.schedule()
        self.clock.advance(4200);self.app.state.scheduler_tick()
        self.assertEqual(self.s.schedules[self.sid]['last_run']['status'],'missed')
        self.assertEqual(self.writes(),[])

    def test_busy_owner_defers_instead_of_overlapping(self):
        self.connect();self.schedule();self.clock.advance(3600)
        self.s.busy=True;self.app.state.scheduler_tick()
        self.assertFalse(self.s.schedules[self.sid]['in_progress'])
        self.s.busy=False;self.app.state.scheduler_tick();self.settle()
        self.assertEqual(self.s.schedules[self.sid]['last_run']['status'],'in_range')

    def test_disabling_during_read_stops_new_requests_but_keeps_manual_key_session(self):
        self.connect();self.demo.products['2077805520']['index']='1.05';self.schedule()
        self.transport.pause=True;self.clock.advance(3600);self.app.state.scheduler_tick()
        self.assertTrue(self.transport.entered.wait(1))
        self.assertEqual(self.schedule(enabled=False).status_code,200)
        self.transport.release.set();cfg=self.settle()
        self.assertFalse(cfg['enabled'])
        self.assertEqual(cfg['last_run']['status'],'cancelled')
        self.assertEqual(self.writes(),[])
        self.assertTrue(self.api._key)
        self.assertEqual(self.job('refresh')['status'],'done')

    def test_scheduled_campaign_runs_without_changing_current_campaign_selection(self):
        self.connect();first=self.sid
        self.demo.products['2077805520']['index']='1.05';self.schedule()
        self.job('create',name='Another campaign',coefficient='.96',products=[{'sku':'425648785',
            'min_price':'469','wb_url':'https://www.wildberries.ru/catalog/101231686/detail.aspx','selected':True}])
        second=self.s.selected_id
        self.clock.advance(3600);self.app.state.scheduler_tick();self.settle(first)
        self.assertEqual(self.s.selected_id,second)
        self.assertEqual(self.demo.strategies[first]['coefficient'],.95)
        self.assertEqual(self.demo.strategies[second]['coefficient'],.96)

    def test_failed_claim_persistence_prevents_any_api_write(self):
        self.connect();self.schedule();self.clock.advance(3600)
        with patch('web_app.write_json',side_effect=OSError('Disk full')):
            self.app.state.scheduler_tick()
        self.assertFalse(self.s.schedules[self.sid]['enabled'])
        self.assertFalse(self.s.schedules[self.sid]['in_progress'])
        self.assertEqual(self.writes(),[])

    def test_account_names_are_mapped_by_client_id_and_not_saved_as_credentials(self):
        for cid,name in ACCOUNT_NAMES.items():
            self.connect(cid)
            state=self.client.get('/api/state').json()
            self.assertEqual(state['account_name'],name)
        for path in Path(self.temp.name).glob('*.json'):
            self.assertNotIn('test-only-key-',path.read_text())

    def test_polling_does_not_extend_session_and_logout_stops_schedule(self):
        self.connect();self.schedule()
        last=self.s.last_used
        self.clock.advance(300)
        self.assertEqual(self.client.get('/api/schedule/status').status_code,200)
        self.assertEqual(self.s.last_used,last)
        self.assertEqual(self.client.get('/api/state').status_code,200)
        self.assertEqual(self.s.last_used,last)
        self.assertEqual(self.client.post('/api/logout',headers=self.headers).status_code,200)
        self.clock.advance(3300);self.app.state.scheduler_tick()
        self.assertEqual(self.api._key,'')
        self.assertEqual(self.writes(),[])
        saved=json.loads(next(Path(self.temp.name).glob('*.json')).read_text())
        self.assertTrue(saved['schedules'][self.sid]['enabled'])

    def test_two_sessions_share_schedule_and_cannot_run_it_twice(self):
        self.connect();self.demo.products['2077805520']['index']='1.05';self.schedule()
        second=TestClient(self.app)
        try:
            initial=second.get('/api/session').json()
            headers={'X-CSRF-Token':initial['csrf']}
            s2=self.app.state.sessions[second.cookies['ge_session']]
            transport=Transport(self.demo)
            api2=SellerAPI('230276','secondary-test-key',session=transport,sleep=lambda _:None)
            with patch('web_app.SellerAPI',return_value=api2):
                queued=second.post('/api/jobs',json={'action':'connect','client_id':'230276','api_key':'secondary-test-key'},headers=headers)
                key=queued.json()['job_id']
                for _ in range(1000):
                    result=second.get('/api/jobs/'+key).json()
                    if result.get('status')!='running':break
                    time.sleep(.002)
                self.assertEqual(result.get('status'),'done',result)
            self.assertIs(self.s.schedules,s2.schedules)
            self.assertIs(self.s.cycle_states,s2.cycle_states)
            self.assertIs(self.s.campaigns,s2.campaigns)
            self.clock.advance(3600)
            self.app.state.scheduler_tick();self.app.state.scheduler_tick();self.settle()
            self.assertEqual(self.writes().count('/v1/pricing-strategy/update'),1)
            self.client.post('/api/logout',headers=self.headers)
            self.assertTrue(s2.schedules[self.sid]['enabled'])
            self.assertTrue(s2.campaigns[self.sid]['products'])
            self.assertTrue(api2._key)
        finally:
            second.close()

    def test_logout_during_run_releases_shared_claim_for_other_connected_session(self):
        self.connect();self.demo.products['2077805520']['index']='1.05';self.schedule()
        second=TestClient(self.app)
        try:
            initial=second.get('/api/session').json()
            headers={'X-CSRF-Token':initial['csrf']}
            s2=self.app.state.sessions[second.cookies['ge_session']]
            api2=SellerAPI('230276','secondary-test-key',session=Transport(self.demo),sleep=lambda _:None)
            with patch('web_app.SellerAPI',return_value=api2):
                queued=second.post('/api/jobs',json={'action':'connect','client_id':'230276',
                    'api_key':'secondary-test-key'},headers=headers)
                key=queued.json()['job_id']
                for _ in range(1000):
                    result=second.get('/api/jobs/'+key).json()
                    if result.get('status')!='running':break
                    time.sleep(.002)
                self.assertEqual(result.get('status'),'done',result)
            cfg=s2.schedules[self.sid]
            self.transport.pause=True
            self.clock.advance(3600);self.app.state.scheduler_tick()
            self.assertTrue(self.transport.entered.wait(1))
            self.assertEqual(self.client.post('/api/logout',headers=self.headers).status_code,200)
            for _ in range(1000):
                if not self.s.busy and not cfg['in_progress']:break
                time.sleep(.002)
            self.assertFalse(cfg['in_progress'])
            self.assertEqual(cfg['last_run']['status'],'cancelled')
            self.assertEqual(self.writes(),[])
            saved=json.loads(next(Path(self.temp.name).glob('*.json')).read_text())
            self.assertFalse(saved['schedules'][self.sid]['in_progress'])
            self.clock.advance(3600);self.app.state.scheduler_tick()
            for _ in range(1000):
                if not s2.busy and not cfg['in_progress']:break
                time.sleep(.002)
            self.assertFalse(cfg['in_progress'])
            self.assertEqual(self.writes().count('/v1/pricing-strategy/update'),1)
        finally:
            second.close()

    def test_production_expiry_and_failed_activity_stop_execution_without_storing_key(self):
        settings=WebSettings(server=True,prefix='/great_equalizer',origin='https://puls-mp.ru',
            username='admin',password_hash=self.password_hash)
        app=create_app(settings=settings,state_dir=Path(self.temp.name)/'server',
            clock=self.clock.mono,wall_clock=self.clock.utc)
        with TestClient(app,base_url=settings.origin) as client:
            init=client.get('/great_equalizer/api/session').json()
            headers={'Origin':settings.origin,'X-CSRF-Token':init['csrf']}
            login=client.post('/great_equalizer/api/login',json={'username':'admin','password':'schedule-test-passphrase-2026'},headers=headers)
            self.assertEqual(login.status_code,200)
            init=client.get('/great_equalizer/api/session').json();headers['X-CSRF-Token']=init['csrf']
            session=app.state.sessions[client.cookies[app.state.cookie_name]]
            demo=make_demo_api();api=SellerAPI('230276','production-test-key',session=Transport(demo),sleep=lambda _:None)
            with patch('web_app.SellerAPI',return_value=api):
                queued=client.post('/great_equalizer/api/jobs',json={'action':'connect','client_id':'230276','api_key':'production-test-key'},headers=headers)
                for _ in range(1000):
                    result=client.get('/great_equalizer/api/jobs/'+queued.json()['job_id']).json()
                    if result.get('status')!='running':break
                    time.sleep(.002)
                self.assertEqual(result.get('status'),'done',result)
            response=client.post('/great_equalizer/api/schedule',json={'enabled':True,'interval_hours':1,'metric_confirmed':True},headers=headers)
            self.assertEqual(response.status_code,200,response.text)
            last=session.last_used;self.clock.advance(1000)
            self.assertEqual(client.get('/great_equalizer/api/schedule/status').status_code,200)
            self.assertEqual(client.post('/great_equalizer/api/activity',headers={**headers,'X-CSRF-Token':'wrong'}).status_code,403)
            self.assertEqual(session.last_used,last)
            self.clock.advance(2600);app.state.sweep_sessions();app.state.scheduler_tick()
            self.assertEqual(api._key,'')
            self.assertFalse(any(path in SellerAPI.WRITE_PATHS for path,_ in demo.calls))
            text=''.join(path.read_text() for path in (Path(self.temp.name)/'server').glob('*.json'))
            self.assertNotIn('production-test-key',text)

    def test_failed_enable_persistence_does_not_leave_automation_enabled(self):
        self.connect()
        with patch('web_app.write_json',side_effect=OSError('Disk full')):
            self.assertEqual(self.schedule().status_code,503)
        self.assertFalse(self.s.schedules.get(self.sid,default_schedule()).get('enabled'))

    def test_anonymous_clients_cannot_read_or_change_schedule(self):
        with TestClient(create_app(settings=WebSettings(server=True,prefix='/great_equalizer',
            origin='https://puls-mp.ru',username='admin',password_hash=self.password_hash)),base_url='https://puls-mp.ru') as client:
            self.assertEqual(client.get('/great_equalizer/api/schedule/status').status_code,401)
            self.assertEqual(client.post('/great_equalizer/api/schedule',json={}).status_code,401)
