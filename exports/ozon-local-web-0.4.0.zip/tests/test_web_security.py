import importlib.util
from contextlib import redirect_stdout
from io import StringIO
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import requests

HAS_WEB = all(importlib.util.find_spec(name) is not None for name in ('fastapi','httpx','argon2'))
if HAS_WEB:
    from fastapi.testclient import TestClient
    from ozon_strategy import SellerAPI, StrategyError
    from web_app import create_app
    from web_security import PASSWORDS, WebSettings


@unittest.skipUnless(HAS_WEB, "Install requirements-web.txt and httpx")

class ServerSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.password = "test-only-access-passphrase-2026"
        cls.password_hash = PASSWORDS.hash(cls.password)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.now = 1000.0
        self.settings = WebSettings(server=True, prefix="/great_equalizer", origin="https://puls-mp.ru",
                                    username="admin", password_hash=self.password_hash)
        self.app = create_app(state_dir=self.temp.name, settings=self.settings, clock=lambda: self.now)
        self.client = TestClient(self.app, base_url=self.settings.origin)
        self.client.__enter__()
        self.prefix = self.settings.prefix
        self.initial = self.client.get(self.prefix+"/api/session").json()
        self.headers = {"Origin":self.settings.origin, "X-CSRF-Token":self.initial["csrf"]}
        self.cookie = self.app.state.cookie_name

    def tearDown(self):
        self.client.__exit__(None,None,None)
        self.temp.cleanup()

    def login(self, **override):
        return self.client.post(self.prefix+"/api/login", json={"username":"admin", "password":self.password, **override}, headers=self.headers)

    def logged_in(self):
        self.assertEqual(self.login().status_code, 200)
        initial = self.client.get(self.prefix+"/api/session").json()
        self.headers["X-CSRF-Token"] = initial["csrf"]
        return self.app.state.sessions[self.client.cookies[self.cookie]]

    def test_all_business_apis_require_login_and_page_shows_login_form(self):
        page = self.client.get(self.prefix+"/")
        self.assertIn('id="login-form"', page.text)
        self.assertNotIn('id="products"', page.text)
        self.assertNotIn('catalog', self.initial['state'])
        for path in ['/api/state','/api/diagnostics','/api/jobs/arbitrary']:
            self.assertEqual(self.client.get(self.prefix+path).status_code,401)
        self.assertEqual(self.client.post(self.prefix+'/api/jobs',json={'action':'demo'},headers=self.headers).status_code,401)

    def test_cookie_is_secure_http_only_strict_and_scoped_to_project(self):
        response = self.client.get(self.prefix+'/api/session')
        cookie = response.headers['set-cookie']
        for flag in ['__Secure-ge_session=', 'HttpOnly','Secure','SameSite=strict','Path=/great_equalizer/']:
            self.assertIn(flag,cookie)
        self.assertEqual(response.headers['cache-control'],'no-store')

    def test_login_rotates_token_and_csrf_and_old_token_cannot_access_state(self):
        old_token = self.client.cookies[self.cookie]
        old_csrf = self.initial['csrf']
        self.logged_in()
        self.assertNotIn(old_token,self.app.state.sessions)
        self.assertNotEqual(old_token,self.client.cookies[self.cookie])
        self.assertNotEqual(old_csrf,self.headers['X-CSRF-Token'])
        self.assertEqual(self.client.get(self.prefix+'/api/state').status_code,200)
        self.assertIn('id="products"',self.client.get(self.prefix+'/').text)
        self.assertEqual(self.client.post(self.prefix+'/api/jobs',json={'action':'demo'},
            headers={**self.headers,'X-CSRF-Token':old_csrf}).status_code,403)

    def test_wrong_password_wrong_username_and_throttling_are_generic(self):
        first = self.login(password='wrong-passphrase-value')
        other = self.login(username='someone-else',password=self.password)
        self.assertEqual(first.status_code,401)
        self.assertEqual(first.json(),other.json())
        for _ in range(3):
            self.assertEqual(self.login(password='wrong').status_code,401)
        blocked = self.login()
        self.assertEqual(blocked.status_code,429)
        self.assertIn('retry-after',blocked.headers)

    def test_login_and_logout_require_exact_origin_and_csrf(self):
        for headers in [{}, {'Origin':'https://evil.example','X-CSRF-Token':self.initial['csrf']},
                        {'Origin':self.settings.origin,'X-CSRF-Token':'wrong'}]:
            self.assertEqual(self.client.post(self.prefix+'/api/login',json={'username':'admin','password':self.password},headers=headers).status_code,403)
        self.logged_in()
        self.assertEqual(self.client.post(self.prefix+'/api/logout',headers={}).status_code,403)

    def test_plain_http_and_spoofed_proxy_header_do_not_get_login_cookie(self):
        with TestClient(self.app,base_url='http://puls-mp.ru') as insecure:
            response = insecure.get(self.prefix+'/api/session',headers={'X-Forwarded-Proto':'https'})
            self.assertEqual(response.status_code,403)
            self.assertNotIn('set-cookie',response.headers)

    def test_logout_clears_credentials_payloads_and_revokes_old_session(self):
        session = self.logged_in()
        api = SellerAPI('private-client-id','private-api-key')
        session.api, session.mode = api,'live'
        session.job_payloads['waiting'] = {'action':'connect','api_key':'queued-key','client_id':'queued-id'}
        token = session.token
        response = self.client.post(self.prefix+'/api/logout',headers=self.headers)
        self.assertEqual(response.status_code,200)
        self.assertNotIn(token,self.app.state.sessions)
        self.assertEqual(api._key,'')
        self.assertEqual(api._client_id,'')
        self.assertNotIn('api_key',session.job_payloads['waiting'])
        self.assertEqual(list(Path(self.temp.name).iterdir()),[])
        with self.assertRaises(StrategyError):
            api.post('/v1/pricing-strategy/update',{})
        self.assertEqual(self.client.get(self.prefix+'/api/state').status_code,401)

    def test_idle_expiry_clears_key_without_new_browser_request(self):
        session = self.logged_in()
        api = SellerAPI('test-id','test-key')
        session.api = api
        self.now += self.settings.idle_seconds+1
        self.app.state.sweep_sessions()
        self.assertEqual(api._key,'')
        self.assertNotIn(session.token,self.app.state.sessions)
        self.assertEqual(self.client.get(self.prefix+'/api/state').status_code,401)

    def test_absolute_expiry_cannot_be_extended_by_activity(self):
        session = self.logged_in()
        api = SellerAPI('test-id','test-key')
        session.api = api
        self.now += self.settings.absolute_seconds+1
        session.last_used = self.now
        self.app.state.sweep_sessions()
        self.assertEqual(api._key,'')
        self.assertEqual(self.client.get(self.prefix+'/api/state').status_code,401)

    def test_session_guard_stops_retries_after_revocation(self):
        api = SellerAPI('test-id','test-key')
        api._session_active = lambda:False
        with patch.object(api._session,'post') as post:
            with self.assertRaises(StrategyError):
                api.post('/v1/pricing-strategy/info',{})
        post.assert_not_called()
        self.assertEqual(api._key,'')

    def test_validation_errors_never_echo_credentials(self):
        self.logged_in()
        response = self.client.post(self.prefix+'/api/jobs',json=[{'api_key':'never-echo-this-secret'}],headers=self.headers)
        self.assertEqual(response.status_code,422)
        self.assertNotIn('never-echo-this-secret',response.text)

    def test_api_key_input_is_always_masked_without_a_reveal_control(self):
        self.logged_in()
        page = self.client.get(self.prefix+'/').text
        self.assertIn('id="api-key" type="password"',page)
        script = self.client.get(self.prefix+'/static/app.js').text
        self.assertNotIn('type="text"',script)
        self.assertNotIn('localStorage',script)
        self.assertNotIn('sessionStorage',script)

    def test_reflected_key_is_scrubbed_before_ui_or_persistence_without_corrupting_ids(self):
        response = requests.Response()
        response.status_code=200
        response._content=json.dumps({'items':[{'id':'123456','name':'reflected-private-key-value',
            'nested':['reflected-private-key-value']}]}).encode()
        api = SellerAPI('123','reflected-private-key-value')
        with patch.object(api._session,'post',return_value=response):
            result = api.post('/v3/product/info/list',{})
        self.assertNotIn('reflected-private-key-value',json.dumps(result))
        self.assertEqual(result['items'][0]['id'],'123456')
        session = self.logged_in()
        session.api = api
        session.campaigns['reflected-private-key-value'] = {'products':[]}
        state = self.client.get(self.prefix+'/api/state')
        self.assertNotIn('reflected-private-key-value',state.text)

    def test_config_requires_https_and_strong_hash_and_missing_auth_fails_closed(self):
        with patch.dict('os.environ',{'GE_SERVER_MODE':'1','GE_AUTH_FILE':''}):
            with self.assertRaises(ValueError):
                WebSettings.from_env()
        for updates in [{'origin':'http://puls-mp.ru'}, {'password_hash':'plaintext'}, {'prefix':'/../../other'}]:
            values = {**self.settings.__dict__,**updates}
            with self.assertRaises(ValueError):
                WebSettings(**values)

    def test_password_setup_persists_only_hash_without_printing_password(self):
        import configure_server
        path=Path(self.temp.name)/'login.json'
        output=StringIO()
        with patch('sys.argv',['configure_server.py','--auth-file',str(path)]), \
                patch('getpass.getpass',side_effect=[self.password,self.password]),redirect_stdout(output):
            configure_server.main()
        text=path.read_text()
        self.assertNotIn(self.password,text+output.getvalue())
        data=json.loads(text)
        self.assertEqual(set(data),{'username','password_hash'})
        self.assertTrue(PASSWORDS.verify(data['password_hash'],self.password))
        self.assertEqual(path.stat().st_mode & 0o077,0)


if __name__ == '__main__':
    unittest.main()
