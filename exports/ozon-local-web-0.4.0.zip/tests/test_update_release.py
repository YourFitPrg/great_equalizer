import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


@unittest.skipUnless(os.name=='posix' and shutil.which('sh'),'POSIX shell required')
class UpdateTests(unittest.TestCase):
    def run_update(self,broken=False):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'app';bin_dir=Path(folder)/'bin';bin_dir.mkdir()
            old=root/'releases'/'0.3.0';new=root/'releases'/'0.4.0'
            old.mkdir(parents=True);new.mkdir()
            (new/'web_app.py').write_text("APP_VERSION='0.4.0'\n")
            (root/'venv'/'bin').mkdir(parents=True)
            (root/'venv'/'bin'/'python').symlink_to(sys.executable)
            (root/'current').symlink_to(old)
            log=Path(folder)/'commands'
            commands={
                'systemctl':f'#!/bin/sh\nprintf "%s\\n" "$*" >> "{log}"\n',
                'curl':'#!/bin/sh\nprintf \'{"version":"'+('broken' if broken else '0.4.0')+'"}\'\n',
                'sleep':'#!/bin/sh\nexit 0\n'}
            for name,source in commands.items():
                path=bin_dir/name;path.write_text(source);path.chmod(0o755)
            original=Path(__file__).resolve().parents[1]/'deploy'/'update-release.sh'
            script=Path(folder)/'update.sh'
            script.write_text(original.read_text().replace('/opt/great_equalizer',str(root)))
            result=subprocess.run(['sh',str(script),'0.4.0'],env={**os.environ,'PATH':str(bin_dir)+os.pathsep+os.environ['PATH']},
                capture_output=True,text=True,timeout=15)
            selected=(root/'current').resolve()
            self.assertEqual(selected,old if broken else new)
            self.assertEqual(result.returncode,1 if broken else 0,result.stdout+result.stderr)
            for line in log.read_text().splitlines():
                self.assertIn(line,{'stop great-equalizer.service','start great-equalizer.service'})

    def test_update_switches_only_our_release_and_service(self):self.run_update()
    def test_failed_health_restores_previous_release(self):self.run_update(broken=True)
