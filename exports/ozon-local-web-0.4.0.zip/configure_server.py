"""Create an Argon2id login hash interactively; never accepts Ozon credentials."""
import argparse
import getpass
import json
import os
from pathlib import Path
import re
import tempfile

from web_security import PASSWORDS


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--auth-file", required=True)
    parser.add_argument("--username", default="admin")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,64}", args.username):
        parser.error("Логин: 3–64 символа A–Z, a–z, цифры, _, . или -.")
    password = getpass.getpass("Новый пароль входа (минимум 16 символов): ")
    repeated = getpass.getpass("Повторите пароль: ")
    if len(password) < 16 or len(password) > 1024 or not password.strip() or password != repeated:
        parser.error("Пароли должны совпадать; длина 16–1024 символа.")
    data = {"username": args.username, "password_hash": PASSWORDS.hash(password)}
    password = repeated = ""
    path = Path(args.auth_file)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=".login-")
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(data, stream)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print(f"Хеш пароля сохранён: {path}. Ключи Ozon в этот файл не записываются.")


if __name__ == "__main__":
    main()
