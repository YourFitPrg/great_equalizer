"use strict";
const root=new URL("../",document.currentScript.src);
const endpoint=path=>new URL(path,root).pathname;
const form=document.getElementById("login-form"), button=document.getElementById("sign-in"), status=document.getElementById("login-status");
let csrf="";
async function session() {
  const response=await fetch(endpoint("api/session"),{cache:"no-store"});
  if(!response.ok) throw new Error("Не удалось открыть сеанс входа. Обновите страницу.");
  const initial=await response.json();
  if(!initial.state.authentication_required) {window.location.replace(root.pathname);return;}
  csrf=initial.csrf;button.disabled=false;status.textContent="Введите логин и пароль.";status.className="notice";
}
form.addEventListener("submit",async event=>{
  event.preventDefault();button.disabled=true;
  const username=document.getElementById("username"), password=document.getElementById("password");
  let body=JSON.stringify({username:username.value,password:password.value});password.value="";
  try {
    const response=await fetch(endpoint("api/login"),{method:"POST",cache:"no-store",headers:{"Content-Type":"application/json","X-CSRF-Token":csrf},body});
    body="";
    const result=await response.json();
    if(!response.ok) throw new Error(result.detail || "Не удалось войти.");
    window.location.replace(root.pathname);
  } catch(error) {status.textContent=error.message;status.className="notice error";}
  finally {body="";password.value="";button.disabled=false;}
});
session().catch(error=>{status.textContent=error.message;status.className="notice error";});
