"use strict";
const $ = id => document.getElementById(id);
const appRoot = new URL("../", document.currentScript.src);
const appUrl = path => {const url=new URL(path.replace(/^\/+/, ""),appRoot);return url.pathname+url.search;};
let csrf = "", state = {}, edits = new Map(), memberOnly = false, newDraft = false, busy = false;
let scheduleDirty=false, lastActivitySent=0;
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt = (value, digits=0) => value === null || value === undefined || value === "" ? "—" : Number(value).toLocaleString("ru-RU", {minimumFractionDigits:digits, maximumFractionDigits:digits});
const coefficientFmt = value => fmt(value, Math.abs(Number(value)*100-Math.round(Number(value)*100))<=.0001 ? 2 : 6);
function indexBadge(value) {
  if (value===null || value===undefined || value==="" || !Number.isFinite(Number(value))) return '<span class="badge gray index-missing">—</span>';
  const n=Number(value), good=n>=.98 && n<=1.01;
  const rounded=Number(n.toFixed(3)), digits=!good && rounded>=.98 && rounded<=1.01 ? 6 : 3;
  return `<span class="badge ${good ? "green index-good" : "orange index-outside"}" title="${esc(value)} · ${good ? "В диапазоне 0,980–1,010" : "Вне диапазона 0,980–1,010"}">${fmt(n,digits)}</span>`;
}
function marketplacePrice(price, data, kind) {
  const note=data?.wb_price_note && kind==="wb" ? data.wb_price_note : data?.prices_details_note || "В ответе API нет цены.";
  if (!price) return `<span class="badge gray" data-price="${kind}" title="${esc(note)}">${data?.prices_details_status==="forbidden" ? "Нет доступа" : "—"}</span>`;
  const comment=kind==="wb" ? "Собственная цена WB по данным Ozon. Скидка кошелька отдельно не выделена." : "Покупательская цена по данным Ozon. Способ оплаты в API не указан.";
  return `<span class="market-price" data-price="${kind}" title="${esc(comment + ' Источник: ' + price.source + (price.url ? ' · ' + price.url : ''))}">${fmt(price.amount,2)} ${esc(price.currency==="RUB" ? "₽" : price.currency)}</span>`;
}
const dateFmt = value => value ? new Date(value).toLocaleString("ru-RU", {timeZone:"Asia/Novosibirsk"}) + " · Новосибирск" : "нет данных";
function notice(message, kind="") { $("notice").textContent=message; $("notice").className="notice " + kind; }
function setBusy(value) { busy=value; document.querySelectorAll("button,input,select").forEach(e=>e.disabled=value && e.id!=="logout"); if (!value) updateActionState(); }
function updateActionState() {
  const selected=Boolean(state.selected_id) && !newDraft;
  const working=busy || state.busy;
  for (const id of ["apply-coefficient","coefficient","plan","verify","cycle","refresh"]) $(id).disabled=working || !selected;
  for (const id of ["new-campaign","campaign-select","apply","reload","connect-open","demo-button"]) $(id).disabled=working;
  $("schedule-enabled").disabled=busy || !selected;
  $("schedule-hours").disabled=working || !selected;
  $("schedule-metric").disabled=working || !selected;
  $("schedule-save").disabled=busy || !selected || (state.busy && $("schedule-enabled").checked);
  $("download-diagnostics").disabled=busy || !currentReport();
  $("apply").textContent=newDraft ? "Создать и включить" : "Применить выбор";
}
async function request(path, options={}) {
  const response=await fetch(appUrl(path), {...options, cache:"no-store", headers:{"Content-Type":"application/json", "X-CSRF-Token":csrf, ...(options.headers || {})}});
  let data; try { data=await response.json(); } catch { throw new Error("Сервер вернул неожиданный ответ. Проверьте окно Python."); }
  if (response.status===401) window.location.replace(appRoot.pathname);
  if (!response.ok) throw new Error(data.detail || "Ошибка запроса");
  return data;
}
function currentReport() { return newDraft ? null : state.report; }
function initEdits() {
  const stored=new Map((newDraft ? [] : state.products || []).map(p=>[String(p.sku),p]));
  edits=new Map((state.catalog || []).map(row=>{
    const old=stored.get(String(row.sku));
    return [String(row.sku), {sku:String(row.sku), selected:old?.selected || false,
      min_price:old?.min_price ?? (Number(row.saved_min_price)>0 ? String(row.saved_min_price) : ""),
      wb_url:old?.wb_url ?? row.wb_url ?? "", tracked:Boolean(old)}];
  }));
}
function collectProducts() {
  return [...edits.values()].filter(p=>p.selected || (!newDraft && p.tracked)).map(({sku,selected,min_price,wb_url})=>({sku,selected,min_price,wb_url}));
}
function safeLink(url) {
  try { const u=new URL(url); if (!["https:","http:"].includes(u.protocol) || !["wildberries.ru","www.wildberries.ru"].includes(u.hostname) || u.username || u.password) return esc(url); }
  catch { return esc(url); }
  return `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(url)}</a>`;
}
function renderTable() {
  const report=currentReport();
  const bySku=new Map((report?.rows || []).map(r=>[r.sku,r]));
  const query=$("search").value.toLowerCase().trim();
  const all=state.catalog || [];
  const rows=all.filter(row=> (!memberOnly || bySku.get(String(row.sku))?.in_strategy) &&
    (!query || [row.sku,row.offer_id,row.name].some(v=>String(v || "").toLowerCase().includes(query))));
  $("all-tab").textContent=`Все товары ${all.length}`;
  $("members-tab").textContent=`В кампании ${report?.member_count || 0}`;
  $("table-count").textContent=`Показано ${rows.length} из ${all.length}`;
  $("products").innerHTML=rows.length ? rows.map(row=>{
    const sku=String(row.sku), p=edits.get(sku), r=bySku.get(sku), member=r?.in_strategy;
    const linkStatus=r?.link_status;
    const linkLabel=linkStatus==="matched" ? "✓ Совпала" : linkStatus==="mismatch" ? "Другая карточка" : linkStatus==="unavailable" ? "Нет данных API" : p.wb_url ? "Проверить" : "Указать ссылку";
    const linkClass=linkStatus==="matched" ? "green" : linkStatus==="mismatch" ? "red" : "amber";
    const saved=Number(p.min_price)>0 && Number(p.min_price)===Number(r?.saved_min_price ?? row.saved_min_price);
    const actualUrls=(r?.actual_wb_urls || []).map(safeLink).join("<br>") || "Нет данных — прочитайте после включения";
    return `<tr class="${member ? "member" : ""}" data-product="${esc(sku)}">
      <td><input type="checkbox" data-field="selected" data-sku="${esc(sku)}" aria-label="Вести SKU ${esc(sku)}" ${p.selected ? "checked" : ""}></td>
      <td><div class="product-name" title="${esc(row.name)}">${esc(row.offer_id || row.name || "Товар")}</div><small>${esc(sku)}</small></td>
      <td>${member ? coefficientFmt(report.coefficient) : "—"}</td>
      <td><input class="price-input" data-field="min_price" data-sku="${esc(sku)}" value="${esc(p.min_price)}" inputmode="decimal" aria-label="Ограничение SKU ${esc(sku)}"><div class="${saved ? "saved" : "pending-floor"}">${saved ? "✓ Сохранено" : "Ожидает применения"}</div></td>
      <td>${fmt(r?.ozon_price ?? row.ozon_price)}</td><td>${fmt(r?.strategy_price)}</td><td>${indexBadge(r ? r.price_index : row.price_index)}</td>
      <td>${marketplacePrice(r ? r.wb_price : row.wb_price,r || row,"wb")}</td>
      <td>${marketplacePrice(r ? r.ozon_customer_price : row.ozon_customer_price,r || row,"ozon")}</td>
      <td><button class="link-button ${linkClass}" data-details="${esc(sku)}">${esc(linkLabel)}</button></td>
      <td><span class="badge ${r?.active ? "green" : "gray"}">${r?.active ? "Включён" : member ? report?.enabled ? "Ожидаем API" : "В стратегии, выкл." : r?.membership_pending ? "Участие не подтверждено" : p.selected ? "К добавлению" : "Не выбран"}</span></td></tr>
      <tr id="details-${esc(sku)}" hidden><td colspan="11" class="details-cell"><div class="details-grid">
        <div><label>Ожидаемая карточка WB<input data-field="wb_url" data-sku="${esc(sku)}" value="${esc(p.wb_url)}" placeholder="https://www.wildberries.ru/catalog/.../detail.aspx"></label><div class="detail-line">Эту ссылку сравним с сопоставлением Ozon.</div></div>
        <div><b>Товар WB по данным Ozon</b><div>${actualUrls}</div><div class="detail-line">Источник: ${esc(r?.link_source || "нет данных")}</div></div>
        <div class="detail-line">Фактическая привязка: ${esc(r?.strategy_id || "не подтверждена")}<br>Источник: ${esc(r?.assignment_source || "ещё не запрашивали")}<br>product_id: ${esc(row.product_id)}</div>
        <div class="detail-line">ID из данных цены: ${esc(r?.reported_strategy_id || "пусто")}<br>Дата цены по стратегии: ${esc(dateFmt(r?.price_downloaded_at))}${r && !r.price_info_current ? "<br>Цена и ссылка стратегии ещё не подтверждены для текущей привязки." : ""}</div>
        ${linkStatus==="unavailable" ? '<div class="detail-line">WB-ссылка не подтверждена: метод стратегии не вернул ссылку, детальные цены недоступны. Текущий товар сохранён; автокоррекция заблокирована до проверки.</div>' : ""}
      </div></td></tr>`;
  }).join("") : '<tr><td colspan="11" class="empty">Нет товаров по этому фильтру.</td></tr>';
}
function renderSchedule() {
  const cfg=newDraft ? {} : state.schedule || {}, last=cfg.last_run;
  if(!scheduleDirty) {
    $("schedule-enabled").checked=Boolean(cfg.enabled);
    $("schedule-hours").value=cfg.interval_hours || 1;
    $("schedule-metric").checked=Boolean(cfg.metric_confirmed);
  }
  const labels={disabled:"Выключена",waiting:"По расписанию",running:"Выполняется",stopping:"Останавливается",paused_key:"Нужен ключ"};
  $("schedule-status").textContent=labels[cfg.status] || "Выключена";
  $("schedule-status").className="badge "+(cfg.status==="waiting" ? "green" : cfg.status==="running" ? "blue" : cfg.status==="stopping" || cfg.status==="paused_key" ? "orange" : "gray");
  $("schedule-next").textContent="Ближайший запуск: "+(cfg.enabled && cfg.next_run_at ? dateFmt(cfg.next_run_at) : "—");
  const statuses={running:"выполняется",in_range:"среднее в норме, коэффициент сохранён",waiting_for_effect:"ожидаем пересчёта Ozon",effect_observed:"результат изменения получен",blocked:"коррекция заблокирована",limit_reached:"достигнута граница коэффициента",pending_conflict:"прошлая запись не подтверждена",pending_composition_changed:"изменился состав данных",missed:"пропуск без повторного запуска",cancelled:"отменён",interrupted:"прерван",error:"ошибка"};
  $("schedule-last").textContent=last ? `Последняя проверка: ${dateFmt(last.finished_at || last.started_at)} · ${last.message || last.plan?.reason || statuses[last.status] || last.status}` : "Последняя проверка: —";
  if(last?.coefficient) $("schedule-last").textContent+=` · Коэф. ${coefficientFmt(last.coefficient)}`;
  $("schedule-key").textContent=cfg.enabled && cfg.key_expires_at ? `Без действий сеанс завершится: ${dateFmt(cfg.key_expires_at)}. Автопроверки не продлевают сеанс.` : "";
}
function render() {
  const report=currentReport();
  $("logout").hidden=!state.server_mode;
  const access=state.prices_details_access;
  $("price-access").hidden=!access || !["forbidden","error"].includes(access.status);
  $("price-access").textContent=access?.message ? access.message + " Покупательские цены могут отсутствовать. Проверка WB-ссылок продолжается по данным стратегии; без подтверждённой ссылки автокоррекция блокируется. После изменения подписки или прав переподключите кабинет." : "";
  $("mode").textContent=state.mode==="live" ? state.account_name || "Кабинет Ozon" : "ДЕМОНСТРАЦИЯ";
  $("mode").className="badge " + (state.mode==="live" ? "green" : "blue");
  $("connect-open").textContent=state.mode==="live" ? "Сменить кабинет" : "Подключить Ozon";
  $("campaign-select").innerHTML='<option value="">Выберите кампанию</option>' + (state.strategies || []).map(s=>`<option value="${esc(s.id)}">${esc(s.name)} · ${s.products_count ?? "?"} ${s.membership_verified ? "подтверждено" : "по списку"}</option>`).join("");
  $("campaign-select").value=newDraft ? "" : state.selected_id || "";
  $("draft-panel").hidden=!newDraft;
  $("current-coefficient").textContent=report ? coefficientFmt(report.coefficient) : newDraft ? coefficientFmt($("start-coefficient").value) : "—";
  const change=newDraft ? null : state.coefficient_change;
  const wanted=change && change.status!=="confirmed" ? change.requested : report?.coefficient;
  const onGrid=wanted!=null && Math.abs(Number(wanted)*100-Math.round(Number(wanted)*100))<=.0001;
  $("coefficient").value=onGrid ? Number(wanted).toFixed(2) : "";
  $("coefficient-result").textContent=change ? `Запрошен: ${coefficientFmt(change.requested)} · API: ${coefficientFmt(report?.coefficient)}. ${change.status==="confirmed" ? "Подтверждено." : "Сохранение не подтверждено — обновите данные."}` : report && !onGrid ? "API вернул значение вне сетки 0,01. Выберите новое вручную." : "Вручную — любое значение из списка.";
  $("coefficient-result").className="coefficient-result " + (change && change.status!=="confirmed" ? "pending-floor" : "muted");
  $("mean-index").textContent=fmt(report?.mean_index,3);
  const labels={in_range:"В диапазоне",above:"Выше цели",below:"Ниже цели",no_data:"Нет данных"};
  $("index-status").textContent=labels[report?.index_status] || "Нет данных";
  $("index-status").className="badge " + (report?.index_status==="in_range" ? "green" : report?.mean_index ? "orange" : "gray");
  $("member-count").textContent=report?.member_count || 0;
  $("coverage").textContent=`Ненулевых: ${report?.nonzero_count || 0} · Нулей: ${report?.zero_count || 0} · Пропусков: ${report?.missing_count || 0}` + ((report?.unconfirmed_member_ids || []).length ? ` · Не подтверждено в списке: ${report.unconfirmed_member_ids.length}` : "");
  $("strategy-status").textContent=newDraft ? "Новая кампания" : report?.enabled ? "Стратегия включена" : state.selected_id ? "Стратегия выключена" : "Нет выбранной кампании";
  $("strategy-status").className="badge " + (report?.enabled && !newDraft ? "green" : "gray");
  $("checked-at").textContent=`Версия ${state.version || "—"}. ` + (report ? `Проверено: ${dateFmt(report.checked_at)}. ID кампании: ${report.strategy_id}` : "Выберите или создайте кампанию.");
  $("diagnostics").hidden=!(report?.notes || []).length;
  $("diagnostic-notes").textContent=(report?.notes || []).join("\n");
  renderSchedule(); renderTable(); updateActionState();
}
async function perform(action, extras={}) {
  if (busy) return;
  const wasDraft=newDraft, previousId=state.selected_id, previousEdits=edits;
  setBusy(true); notice("Выполняется запрос…", "busy");
  try {
    const payload={action, strategy_id:state.selected_id, ...extras};
    const accepted=await request("/api/jobs", {method:"POST",body:JSON.stringify(payload)});
    delete payload.api_key; delete extras.api_key; delete payload.client_id; delete extras.client_id;
    let job;
    do { await new Promise(resolve=>setTimeout(resolve,300)); job=await request(`/api/jobs/${accepted.job_id}`); notice(job.message || "Выполняется…", "busy"); } while (job.status==="running");
    state=await request("/api/state");
    if(state.selected_id!==previousId || ["connect","demo","select"].includes(action)) scheduleDirty=false;
    const keepDraft=job.status==="error" && action==="create" && wasDraft && state.selected_id===previousId;
    newDraft=keepDraft || !state.selected_id;
    if (keepDraft) edits=previousEdits; else initEdits();
    render();
    if (job.status==="error") throw new Error(job.error);
    let message=state.mode==="demo" ? "Демонстрация: изменения выполнены только в памяти." : "Готово. Данные Ozon обновлены.";
    if (job.plan) {
      const statuses={in_range:"Среднее в диапазоне: коэффициент не меняем.",adjustment_proposed:`Предлагаемый коэффициент: ${job.plan.new_coefficient}. Записи ещё не было.`,limit_reached:"Достигнута граница коэффициента. Среднее пока вне цели.",waiting_for_effect:"Коэффициент записан или ожидает пересчёта. Не повторяем изменение по старым данным.",blocked:"Коррекция заблокирована: проверьте состав, ссылки и ограничения.",effect_observed:"Получены новые цены/индексы. Результат предыдущего изменения прочитан.",pending_conflict:"Предыдущая запись не подтверждена или коэффициент изменён вручную.",pending_composition_changed:"Изменился состав индексов. Требуется проверка."};
      message=job.plan.reason || statuses[job.plan.status] || job.plan.status;
      if (job.plan.new_coefficient && action==="plan") $("coefficient").value=Number(job.plan.new_coefficient).toFixed(2);
    }
    if (state.configuration_issue) message=state.configuration_issue;
    const removed=(state.report?.actions || []).flatMap(a=>a.product_ids || []);
    if (removed.length) message=`Исключены товары с неверной или неподтверждённой WB-ссылкой: ${removed.join(", ")}. Остальные продолжают работу.`;
    const change=state.coefficient_change, pending=change && change.status!=="confirmed";
    if (action==="coefficient" || pending) message=`Запрошен коэффициент ${coefficientFmt(change.requested)}; API вернул ${coefficientFmt(state.report.coefficient)}. ` + (pending ? "Сохранение не подтверждено. Обновите данные; автоматического повтора записи нет." : "Сохранение подтверждено.");
    const blocked=job.plan && ["blocked","pending_conflict","pending_composition_changed","limit_reached","metric_not_confirmed"].includes(job.plan.status);
    const unavailable=(state.report?.rows || []).filter(r=>r.in_strategy && r.link_status==="unavailable");
    if (unavailable.length && !removed.length && !pending) message=`Не удалось проверить WB-ссылки: ${unavailable.map(r=>r.sku).join(", ")}. Текущие участники сохранены; изменение коэффициента заблокировано до подтверждения ссылки.`;
    notice(message, pending || blocked || unavailable.length ? "warning" : state.configuration_issue || removed.length ? "" : "success");
  } catch(error) { notice(error.message + " После ошибки записи перечитайте данные перед повтором.", "error"); }
  finally { delete extras.api_key; delete extras.client_id; setBusy(false); }
}
$("products").addEventListener("input",event=>{
  const el=event.target; if (!el.dataset.field) return;
  const p=edits.get(el.dataset.sku); p[el.dataset.field]=el.type==="checkbox" ? el.checked : el.value;
  if (el.dataset.field==="min_price") {
    const actual=currentReport()?.rows.find(r=>r.sku===p.sku)?.saved_min_price ?? state.catalog.find(r=>String(r.sku)===p.sku)?.saved_min_price;
    const saved=Number(p.min_price)>0 && Number(p.min_price)===Number(actual), label=el.parentElement.querySelector("div");
    label.className=saved ? "saved" : "pending-floor";label.textContent=saved ? "✓ Сохранено" : "Ожидает применения";
  }
  if (el.dataset.field==="wb_url") {
    const actual=currentReport()?.rows.find(r=>r.sku===p.sku), button=document.querySelector(`[data-details="${p.sku}"]`);
    const matches=actual?.link_status==="matched" && actual.expected_wb_url===p.wb_url;
    button.className="link-button "+(matches ? "green" : "amber");button.textContent=matches ? "✓ Совпала" : p.wb_url ? "Проверить" : "Указать ссылку";
  }
});
$("products").addEventListener("change",event=>{
  if (event.target.dataset.field==="selected") {
    const p=edits.get(event.target.dataset.sku); p.selected=event.target.checked;
  }
});
$("products").addEventListener("click",event=>{
  const button=event.target.closest("[data-details]"); if (button) { const detail=$("details-"+button.dataset.details); detail.hidden=!detail.hidden; }
});
$("search").addEventListener("input",renderTable);
$("all-tab").addEventListener("click",()=>{memberOnly=false;$("all-tab").classList.add("active");$("members-tab").classList.remove("active");renderTable();});
$("members-tab").addEventListener("click",()=>{memberOnly=true;$("members-tab").classList.add("active");$("all-tab").classList.remove("active");renderTable();});
$("new-campaign").addEventListener("click",()=>{newDraft=true;scheduleDirty=false;memberOnly=false;initEdits();render();notice("Новая кампания: отметьте товары, заполните ограничения и WB-ссылки, затем нажмите «Создать и включить».");$("campaign-name").focus();});
$("start-coefficient").addEventListener("input",()=>$("current-coefficient").textContent=coefficientFmt($("start-coefficient").value));
$("campaign-select").addEventListener("change",()=>{if($("campaign-select").value) perform("select",{strategy_id:$("campaign-select").value});});
$("reload").addEventListener("click",()=>perform("load"));
$("refresh").addEventListener("click",()=>perform("refresh",{products:collectProducts()}));
$("apply").addEventListener("click",()=>newDraft ? perform("create",{name:$("campaign-name").value,coefficient:$("start-coefficient").value,products:collectProducts()}) : perform("apply",{products:collectProducts()}));
$("verify").addEventListener("click",()=>perform("verify",{products:collectProducts()}));
$("download-diagnostics").addEventListener("click",()=>{window.location.assign(appUrl("/api/diagnostics"));});
$("plan").addEventListener("click",()=>perform("plan",{products:collectProducts()}));
$("apply-coefficient").addEventListener("click",()=>perform("coefficient",{products:collectProducts(),coefficient:$("coefficient").value}));
$("cycle").addEventListener("click",()=>perform("cycle",{products:collectProducts(),metric_confirmed:$("metric-confirmed").checked}));
$("connect-open").addEventListener("click",()=>$("connect-dialog").showModal());
$("connect-cancel").addEventListener("click",()=>{$("api-key").value="";$("client-id").value="";$("connect-dialog").close();});
$("connect-form").addEventListener("submit",event=>{event.preventDefault();const data={client_id:$("client-id").value,api_key:$("api-key").value};$("api-key").value="";$("client-id").value="";$("connect-dialog").close();perform("connect",data);});
$("logout").addEventListener("click",async()=>{try { await request("/api/logout",{method:"POST"}); } finally { $("api-key").value="";$("client-id").value="";window.location.replace(appRoot.pathname); }});
$("demo-button").addEventListener("click",()=>perform("demo"));
async function saveSchedule() {
  if(busy || newDraft || !state.selected_id) return;
  const enabled=$("schedule-enabled").checked;
  const typed=Number($("schedule-hours").value);
  const hours=!enabled && (!Number.isInteger(typed) || typed<1 || typed>168) ? state.schedule?.interval_hours || 1 : typed;
  setBusy(true);notice("Сохраняем расписание…","busy");
  try {
    await request("/api/schedule",{method:"POST",body:JSON.stringify({strategy_id:state.selected_id,enabled,
      interval_hours:hours,metric_confirmed:$("schedule-metric").checked})});
    state=await request("/api/state");scheduleDirty=false;render();
    notice(enabled ? `Автокоррекция включена: каждые ${hours} ч. Первый запуск — в указанное время. После завершения сеанса нужен повторный вход и подключение кабинета.` : "Автокоррекция выключена. Уже отправленный запрос Ozon может завершиться.","success");
  } catch(error) {notice(error.message,"error");}
  finally {setBusy(false);}
}
for(const id of ["schedule-enabled","schedule-hours","schedule-metric"]) $(id).addEventListener("input",()=>{scheduleDirty=true;updateActionState();});
$("schedule-save").addEventListener("click",saveSchedule);
$("schedule-enabled").addEventListener("change",()=>{if(!$("schedule-enabled").checked && state.schedule?.enabled) saveSchedule();});
setInterval(async()=>{
  if(busy || newDraft || !state.selected_id) return;
  try {
    const selected=state.selected_id;
    const update=await request(`/api/schedule/status?report_at=${encodeURIComponent(state.report?.checked_at || "")}`);
    if(selected!==state.selected_id || update.selected_id!==selected) return;
    state.schedule=update.schedule;state.busy=update.busy;
    const editing=["INPUT","SELECT","TEXTAREA"].includes(document.activeElement?.tagName);
    if(update.report && !editing && !scheduleDirty) {
      state.report=update.report;state.coefficient_change=update.coefficient_change;render();
    } else {renderSchedule();updateActionState();}
  } catch(error) {if(!document.hidden) notice(error.message,"error");}
},15000);
for(const eventName of ["pointerdown","keydown","wheel"]) document.addEventListener(eventName,event=>{
  if(!event.isTrusted || !state.server_mode || !csrf || document.hidden || Date.now()-lastActivitySent<60000) return;
  lastActivitySent=Date.now();request("/api/activity",{method:"POST"}).catch(()=>{});
},{passive:true});
(async()=>{try { const initial=await request("/api/session");if(initial.state.authentication_required){window.location.replace(appRoot.pathname);return;}csrf=initial.csrf;state=initial.state;newDraft=!state.selected_id;initEdits();render();await perform("load"); } catch(error) {notice(error.message,"error");} })();
