"""Local browser UI for Ozon campaigns. Run: python web_app.py --open-browser."""
from __future__ import annotations

import argparse
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import threading
import time
from urllib.parse import urlsplit
import webbrowser

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from ozon_strategy import (CoefficientReadbackError, Product, SellerAPI, StrategyError, StrategyService, batches,
                           coefficient_input, coefficient_number,
                           ensure_strategy, identifier, list_strategies, number, own_price_details, write_json)
from web_demo import make_demo_api
from web_security import LoginLimiter, WebSettings


ROOT = Path(__file__).resolve().parent
APP_VERSION = "0.3.0"
USER_DEFAULTS = {"2369234990": {"min_price": "2700", "wb_url": "https://www.wildberries.ru/catalog/386265183/detail.aspx"}}


class BrowserSession:
    def __init__(self, *, authenticated=True, clock=time.monotonic):
        self.token, self.csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        self.api, self.mode, self.account = make_demo_api(), "demo", ""
        self.catalog, self.strategies, self.campaigns = {}, [], {}
        self.selected_id, self.setup_state, self.cycle_states = "", {}, {}
        self.jobs, self.busy, self.last_used = {}, False, clock()
        self.authenticated, self.login_at = authenticated, clock() if authenticated else None
        self.revoked, self.job_payloads = threading.Event(), {}
        self.lock = threading.RLock()


def create_app(*, state_dir=None, settings=None, clock=time.monotonic):
    settings = settings or WebSettings.from_env()
    sessions, account_locks = {}, {}
    global_lock = threading.RLock()
    pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ozon-web")
    state_dir = Path(state_dir or os.environ.get("GE_STATE_DIR") or ROOT / ".local" / "web-state")
    cookie_name = "__Secure-ge_session" if settings.server else "ge_session"
    cookie_path = settings.prefix + "/"
    limiter = LoginLimiter(clock)

    def valid(s):
        return (not s.revoked.is_set() and clock()-s.last_used < (settings.idle_seconds if settings.server else 28800)
                and (s.login_at is None or clock()-s.login_at < settings.absolute_seconds))

    def drop_session(s):
        with global_lock:
            s.revoked.set()
            for payload in s.job_payloads.values():
                payload.pop("api_key", None)
                payload.pop("client_id", None)
            api, s.api = s.api, None
            if hasattr(api, "close"):
                api.close()
            s.mode, s.account = "closed", ""
            s.catalog.clear()
            s.campaigns.clear()
            s.jobs.clear()
            sessions.pop(s.token, None)

    def sweep_sessions():
        with global_lock:
            for s in list(sessions.values()):
                if not valid(s):
                    drop_session(s)

    @asynccontextmanager
    async def lifespan(_):
        stop = threading.Event()
        def cleanup():
            while not stop.wait(15):
                sweep_sessions()
        thread = threading.Thread(target=cleanup, name="ge-session-cleanup", daemon=True)
        thread.start()
        try:
            yield
        finally:
            stop.set()
            thread.join(timeout=1)
            for s in list(sessions.values()):
                drop_session(s)
            pool.shutdown(wait=False, cancel_futures=True)

    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None,
                  root_path=settings.prefix, lifespan=lifespan)
    hosts = ["127.0.0.1", "localhost", "[::1]"]
    hosts += [urlsplit(settings.origin).hostname] if settings.server else ["testserver"]
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)
    app.state.sessions = sessions
    app.state.cookie_name, app.state.sweep_sessions = cookie_name, sweep_sessions

    def existing(request):
        s = sessions.get(request.cookies.get(cookie_name))
        if s is not None and not valid(s):
            drop_session(s)
            s = None
        return s

    def session(request, *, mutation=False, anonymous=False):
        s = existing(request)
        if s is None:
            raise HTTPException(401, "Сеанс завершён. Войдите заново.")
        if settings.server and not s.authenticated and not anonymous:
            raise HTTPException(401, "Требуется вход.")
        s.last_used = clock()
        if mutation:
            if not secrets.compare_digest(request.headers.get("x-csrf-token", ""), s.csrf):
                raise HTTPException(403, "Обновите страницу: токен формы устарел.")
            origin = request.headers.get("origin")
            if settings.server and origin != settings.origin or not settings.server and origin and urlsplit(origin).netloc.lower() != request.headers.get("host", "").lower():
                raise HTTPException(403, "Запрос с другого сайта запрещён.")
        return s

    def set_cookie(response, s):
        remaining = settings.absolute_seconds if s.login_at is None else max(1, int(settings.absolute_seconds-(clock()-s.login_at)))
        response.set_cookie(cookie_name, s.token, path=cookie_path, secure=settings.server,
                            httponly=True, samesite="strict", max_age=remaining)

    def account_lock(s):
        key = s.account if s.mode == "live" else s.token
        with global_lock:
            return account_locks.setdefault(key, threading.RLock())

    def save(s):
        with global_lock:
            if s.mode == "live" and valid(s):
                value = {
                    "selected_id": s.selected_id, "campaigns": {
                        k: {"products": v.get("products", []), "coefficient_change": v.get("coefficient_change")}
                        for k, v in s.campaigns.items()},
                    "setup_state": s.setup_state, "cycle_states": s.cycle_states}
                write_json(state_dir / (s.account + ".json"), s.api._scrub(value) if hasattr(s.api,"_scrub") else value)

    def info(s):
        if settings.server and not s.authenticated:
            return {"version": APP_VERSION, "authentication_required": True}
        campaign = s.campaigns.get(s.selected_id, {})
        change = campaign.get("coefficient_change")
        if change and campaign.get("report"):
            change["actual"] = str(coefficient_number(campaign["report"]["coefficient"]))
            if coefficient_number(change["actual"]) == coefficient_number(change["requested"]):
                change["status"] = "confirmed"
            elif change["status"] == "confirmed":
                change["status"] = "changed_externally"
        strategies = [dict(row) for row in s.strategies]
        for row in strategies:
            row["membership_verified"] = False
            if row["id"] == s.selected_id and campaign.get("report") is not None:
                row["reported_products_count"] = row.get("products_count")
                row["products_count"] = campaign["report"]["member_count"]
                row["membership_verified"] = True
        value = {"version": APP_VERSION, "mode": s.mode, "selected_id": s.selected_id, "strategies": strategies,
                "server_mode": settings.server, "authentication_required": False,
                "catalog": list(s.catalog.values()), "products": campaign.get("products", []),
                "report": campaign.get("report"), "configuration_issue": campaign.get("configuration_issue"),
                "coefficient_change": change,
                "prices_details_access": {k: v for k, v in getattr(s.api, "_prices_details_access", {}).items()
                                          if not k.startswith("_")},
                "busy": s.busy, "scheduled": False}
        return s.api._scrub(value) if hasattr(s.api,"_scrub") else value

    def load_catalog(s):
        ids, last_id = [], ""
        for _ in range(100):
            data = s.api.post("/v3/product/list", {"filter": {"visibility": "ALL"}, "last_id": last_id, "limit": 1000}).get("result", {})
            rows = data.get("items")
            if not isinstance(rows, list):
                raise StrategyError("Нет списка товаров Ozon.")
            page_ids = [identifier(r["product_id"]) for r in rows]
            if set(ids) & set(page_ids):
                raise StrategyError("Повторилась страница каталога.")
            ids.extend(page_ids)
            cursor = data.get("last_id") or ""
            if not rows or len(rows) < 1000 or not cursor:
                break
            if cursor == last_id:
                raise StrategyError("Не меняется курсор каталога.")
            last_id = cursor
        else:
            raise StrategyError("Каталог слишком большой для тестового режима.")
        s.catalog = {}
        load_product_ids(s, ids)

    def load_product_ids(s, ids):
        for group in batches(ids, 1000):
            meta = s.api.post("/v3/product/info/list", {"product_id": group}).get("items", [])
            prices = s.api.post("/v5/product/info/prices", {"filter": {"product_id": group, "visibility": "ALL"}, "limit": 1000}).get("items", [])
            by_id = {str(p["product_id"]): p for p in prices}
            skus = [item.get("sku") or next((p.get("sku") for p in item.get("sources") or [] if p.get("sku")), None)
                    for item in meta]
            details = own_price_details(s.api, [sku for sku in skus if sku])
            for item in meta:
                sku = item.get("sku") or next((p.get("sku") for p in item.get("sources") or [] if p.get("sku")), None)
                if not sku:
                    continue
                sku = identifier(sku)
                detail = by_id.get(str(item["id"]), {})
                price = detail.get("price") or {}
                own = (detail.get("price_indexes") or {}).get("self_marketplaces_index_data") or {}
                default = USER_DEFAULTS.get(sku, {})
                extra = details["products"][sku]
                s.catalog[sku] = {"sku": sku, "product_id": str(item["id"]), "offer_id": item.get("offer_id"),
                    "name": item.get("name"), "ozon_price": price.get("price"), "saved_min_price": price.get("min_price"),
                    "wb_price": extra["wb_price"], "ozon_customer_price": extra["ozon_customer_price"],
                    "wb_price_note": extra.get("wb_price_note", ""),
                    "prices_details_status": extra["prices_details_status"],
                    "prices_details_note": extra.get("prices_details_note", ""),
                    "price_index": own.get("price_index_value"), "wb_url": default.get("wb_url", "")}
                if s.mode == "demo":
                    s.catalog[sku]["wb_url"] = s.api.products[str(item["id"])]["url"]

    def set_products(s, payload):
        if not isinstance(payload, list) or len(payload) > 2000:
            raise ValueError("Некорректный список товаров.")
        result = [Product(sku=p["sku"], min_price=p["min_price"], wb_url=p.get("wb_url", ""),
                          selected=p.get("selected", False)) for p in payload]
        if len({p.sku for p in result}) != len(result):
            raise ValueError("SKU не должны повторяться.")
        return result

    def service(s, sid=None):
        sid = sid or s.selected_id
        if not sid:
            raise ValueError("Сначала выберите или создайте кампанию.")
        return StrategyService(s.api, sid)

    def select(s, sid):
        current = service(s, sid)
        current.strategy()  # Verify that this is a custom, WB-only strategy.
        members = current.members()
        known_ids = {r["product_id"] for r in s.catalog.values()}
        load_product_ids(s, sorted(members - known_ids))
        campaign = s.campaigns.setdefault(sid, {"products": []})
        products = {p["sku"]: p for p in campaign["products"]}
        for row in s.catalog.values():
            if row["product_id"] in members and row["sku"] not in products:
                products[row["sku"]] = {"sku": row["sku"], "selected": True,
                    "min_price": str(row.get("saved_min_price") or ""), "wb_url": row.get("wb_url", "")}
        campaign["products"] = list(products.values())
        s.selected_id = sid
        try:
            campaign["report"] = current.snapshot(set_products(s, campaign["products"]))
            campaign.pop("configuration_issue", None)
        except ValueError as error:
            campaign["report"] = None
            campaign["configuration_issue"] = str(error)
        save(s)

    def load(s):
        s.strategies = [r for r in list_strategies(s.api) if r.get("type") in {None, "COMP_PRICE"}]
        load_catalog(s)
        available = {r["id"] for r in s.strategies}
        if s.selected_id in available:
            select(s, s.selected_id)
        elif available:
            s.selected_id = ""
            for row in s.strategies:
                try:
                    select(s, row["id"])
                    break
                except StrategyError:
                    continue
        else:
            s.selected_id = ""

    def operate(s, payload, job):
        action = payload.get("action")
        job["message"] = "Читаем данные Ozon…" if s.mode == "live" else "Обрабатываем демонстрационные данные…"
        if action == "connect":
            cid, key = str(payload.get("client_id", "")).strip(), str(payload.get("api_key", "")).strip()
            if not cid or not key or len(cid) > 80 or len(key) > 2048:
                raise ValueError("Введите Client-Id и API-ключ.")
            api = SellerAPI(cid, key)
            payload.pop("api_key", None)
            payload.pop("client_id", None)
            account = hashlib.sha256(cid.encode()).hexdigest()
            cid = key = ""
            api._session_active = lambda: valid(s)
            try:
                list_strategies(api)  # Validate access before replacing the current session.
                if not valid(s):
                    raise StrategyError("Сеанс завершён.")
            except Exception:
                if hasattr(api, "close"):
                    api.close()
                raise
            if hasattr(s.api, "close"):
                s.api.close()
            s.api, s.mode = api, "live"
            s.catalog, s.strategies = {}, []
            s.account = account
            path = state_dir / (s.account + ".json")
            old = json.loads(path.read_text()) if path.exists() else {}
            s.campaigns, s.setup_state, s.cycle_states = old.get("campaigns", {}), old.get("setup_state", {}), old.get("cycle_states", {})
            s.selected_id = old.get("selected_id", "")
            payload.pop("api_key", None)
            load(s)
        elif action == "demo":
            if hasattr(s.api, "close"):
                s.api.close()
            s.api, s.mode, s.account = make_demo_api(), "demo", ""
            s.campaigns, s.setup_state, s.cycle_states, s.selected_id = {}, {}, {}, ""
            load(s)
        elif action == "load":
            load(s)
        elif action == "select":
            select(s, str(payload.get("strategy_id", "")))
        elif action == "create":
            products = set_products(s, payload.get("products", []))
            if not any(p.selected for p in products) or any(p.selected and not p.wb_url for p in products):
                raise ValueError("Отметьте товары и укажите ограничения и ожидаемые WB-ссылки.")
            job["message"] = "Создаём кампанию и сохраняем её ID…"
            current = ensure_strategy(s.api, strategy_name=payload.get("name", ""),
                initial_coefficient=payload.get("coefficient", "0.960"), state=s.setup_state, persist=lambda _: save(s))
            s.selected_id = current.strategy_id
            s.campaigns.setdefault(current.strategy_id, {})["products"] = [asdict(p) for p in products]
            save(s)
            job["message"] = "ID сохранён. Устанавливаем ограничения, добавляем товары, включаем и проверяем WB…"
            report = current.apply_selection(products)
            s.campaigns[current.strategy_id]["report"] = report
            s.strategies = [r for r in list_strategies(s.api) if r.get("type") in {None, "COMP_PRICE"}]
            save(s)
        else:
            sid = str(payload.get("strategy_id") or s.selected_id)
            if sid != s.selected_id:
                raise ValueError("Выбранная кампания изменилась. Обновите страницу.")
            current = service(s, sid)
            campaign = s.campaigns.setdefault(sid, {})
            products = set_products(s, payload.get("products", campaign.get("products", [])))
            campaign["products"] = [asdict(p) for p in products]
            save(s)
            if action == "apply":
                job["message"] = "Сохраняем ограничения и состав, затем проверяем WB-ссылки…"
                report = current.apply_selection(products)
            elif action == "verify":
                job["message"] = "Проверяем WB-ссылки. Неверный товар будет исключён отдельно…"
                report = current.verify(products)
            elif action == "coefficient":
                report = current.snapshot(products)
                if not report["ready"]:
                    campaign["report"] = report
                    raise StrategyError("До изменения коэффициента подтвердите состав, ограничения и WB-ссылки.")
                value = coefficient_input(payload.get("coefficient"))
                previous = coefficient_number(report["coefficient"])
                pending = {"old_coefficient": str(previous), "new_coefficient": str(value),
                           "baseline": current._baseline(report), "created_at": datetime.now(timezone.utc).isoformat()}
                change = {"previous": str(previous), "requested": str(value), "actual": str(previous),
                          "status": "pending", "created_at": pending["created_at"]}
                campaign["coefficient_change"] = change
                cycle_state = s.cycle_states.setdefault(sid, {})
                if value == previous:
                    cycle_state.pop("pending", None)
                else:
                    cycle_state["pending"] = pending
                save(s)
                try:
                    actual = current.change_coefficient(value, expected_current=previous, manual=True,
                        expected_members=[r["product_id"] for r in report["rows"] if r["in_strategy"]])
                    change.update(actual=actual, status="confirmed")
                except CoefficientReadbackError as error:
                    change.update(error.change)
                job["coefficient_change"] = change
                report = current.snapshot(products)
            elif action == "plan":
                report = current.snapshot(products)
                job["plan"] = current.plan(report)
            elif action == "cycle":
                if payload.get("metric_confirmed") is not True:
                    raise ValueError("Для коррекции сначала подтвердите сверку индекса с AJ.")
                state = s.cycle_states.setdefault(sid, {})
                result = current.cycle(products, state, write=True, metric_confirmed=True, persist=lambda _: save(s))
                job["plan"] = result["plan"]
                report = current.snapshot(products) if result["coefficient_written"] else result["snapshot"]
                if result["coefficient_written"]:
                    campaign["coefficient_change"] = {"previous": result["plan"]["old_coefficient"],
                        "requested": result["coefficient_after_write"], "actual": report["coefficient"],
                        "status": "confirmed", "created_at": datetime.now(timezone.utc).isoformat()}
            elif action == "refresh":
                report = current.snapshot(products)
            else:
                raise ValueError("Неизвестная операция.")
            campaign["report"] = report
            campaign.pop("configuration_issue", None)
            save(s)
        job["message"] = "Готово. Данные обновлены."

    def run_job(s, payload, job):
        try:
            with s.lock, account_lock(s):
                if not valid(s):
                    raise StrategyError("Сеанс завершён.")
                operate(s, payload, job)
            job["status"] = "done"
        except (StrategyError, ValueError, KeyError, OSError) as error:
            job["error"] = str(error)
            job["message"] = "Читаем фактическое состояние после ошибки…"
            # Keep a just-created campaign visible after a partial failure.
            try:
                s.strategies = [r for r in list_strategies(s.api) if r.get("type") in {None, "COMP_PRICE"}]
            except Exception:
                pass
            if s.selected_id and s.selected_id in s.campaigns:
                try:
                    campaign = s.campaigns[s.selected_id]
                    campaign["report"] = service(s).snapshot(set_products(s, campaign.get("products", [])))
                except Exception:
                    # A failed diagnostic read must not hide the original error or leave the job running.
                    pass
            job["status"] = "error"
        except Exception:
            job["status"], job["error"] = "error", "Внутренняя ошибка. Обновите данные перед повтором операции."
        finally:
            payload.pop("api_key", None)
            payload.pop("client_id", None)
            with global_lock:
                s.job_payloads.pop(job["id"], None)
                s.busy = False

    @app.get("/")
    def index(request: Request):
        s = existing(request)
        filename = "login.html" if settings.server and (s is None or not s.authenticated) else "index.html"
        return FileResponse(ROOT / "web_static" / filename)

    @app.get("/health")
    def health():
        return {"status": "ok", "version": APP_VERSION}

    @app.get("/api/session")
    def get_session(request: Request):
        s = existing(request)
        if s is None:
            with global_lock:
                sweep_sessions()
                if len(sessions) >= 50:
                    anonymous = [value for value in sessions.values() if not value.authenticated]
                    if anonymous:
                        drop_session(min(anonymous, key=lambda value:value.last_used))
                    else:
                        raise HTTPException(503, "Слишком много сессий. Повторите позже.")
                s = BrowserSession(authenticated=not settings.server, clock=clock)
                sessions[s.token] = s
        s.last_used = clock()
        response = JSONResponse({"csrf": s.csrf, "state": info(s)})
        set_cookie(response, s)
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.post("/api/login")
    async def login(request: Request):
        if not settings.server:
            raise HTTPException(404)
        s = session(request, mutation=True, anonymous=True)
        body = await request.body()
        if len(body) > 4096:
            raise HTTPException(413, "Слишком большой запрос входа.")
        try:
            payload = json.loads(body)
            username, password = payload.get("username"), payload.get("password")
        except (ValueError, AttributeError):
            raise HTTPException(400, "Некорректный запрос входа.") from None
        ip = request.client.host if request.client else "unknown"
        retry = limiter.reserve(ip)
        if retry:
            raise HTTPException(429, "Слишком много попыток. Повторите позже.", headers={"Retry-After": str(retry)})
        if not limiter.verifications.acquire(blocking=False):
            raise HTTPException(429, "Вход занят. Повторите позже.", headers={"Retry-After": "5"})
        try:
            # Argon2 runs off the event loop; concurrent checks have a memory bound.
            from starlette.concurrency import run_in_threadpool
            correct = await run_in_threadpool(settings.verify, username, password)
        finally:
            limiter.verifications.release()
            payload.clear()
            username = password = body = None
        if not correct:
            raise HTTPException(401, "Неверный логин или пароль.")
        if not valid(s):
            raise HTTPException(401, "Сеанс завершён. Обновите страницу.")
        limiter.success(ip)
        drop_session(s)
        new = BrowserSession(authenticated=True, clock=clock)
        with global_lock:
            sessions[new.token] = new
        response = JSONResponse({"ok": True})
        set_cookie(response, new)
        return response

    @app.post("/api/logout")
    def logout(request: Request):
        s = session(request, mutation=True)
        drop_session(s)
        response = JSONResponse({"ok": True})
        response.delete_cookie(cookie_name, path=cookie_path, secure=settings.server, httponly=True, samesite="strict")
        return response

    @app.get("/api/state")
    def get_state(request: Request):
        return info(session(request))

    @app.get("/api/diagnostics")
    def diagnostics(request: Request):
        s = session(request)
        report = s.campaigns.get(s.selected_id, {}).get("report")
        if report is None:
            raise HTTPException(400, "Сначала обновите данные выбранной кампании.")
        def clean(value):
            if isinstance(value, dict):
                return {key: clean(item) for key, item in value.items()
                        if str(key).lower().replace("-", "_") not in {"headers", "authorization", "api_key", "client_id"}}
            if isinstance(value, list):
                return [clean(item) for item in value]
            if isinstance(value, str) and hasattr(s.api, "_safe"):
                return s.api._safe(value)
            return value
        return JSONResponse(clean({"version": APP_VERSION, "mode": s.mode, "report": report,
                                   "coefficient_change": s.campaigns.get(s.selected_id, {}).get("coefficient_change"),
                                   "cycle_state": s.cycle_states.get(s.selected_id, {}),
                                   "writes": getattr(s.api, "audit_log", [])}),
            headers={"Content-Disposition": f'attachment; filename="ozon-diagnostics-{APP_VERSION}.json"'})

    @app.post("/api/jobs")
    def queue_job(payload: dict, request: Request):
        s = session(request, mutation=True)
        if len(json.dumps(payload)) > 1_000_000:
            raise HTTPException(413, "Слишком большой список.")
        if payload.get("action") not in {"connect", "demo", "load", "select", "create", "apply", "verify", "coefficient", "plan", "cycle", "refresh"}:
            raise HTTPException(400, "Неизвестная операция.")
        with global_lock:
            if not valid(s):
                raise HTTPException(401, "Сеанс завершён.")
            if s.busy:
                raise HTTPException(409, "Дождитесь текущей операции.")
            s.busy = True
            job = {"id": secrets.token_urlsafe(16), "status": "running", "message": "Задание принято…"}
            s.jobs[job["id"]] = job
            while len(s.jobs) > 20:
                del s.jobs[next(iter(s.jobs))]
            task_payload = dict(payload)
            payload.pop("api_key", None)
            payload.pop("client_id", None)
            s.job_payloads[job["id"]] = task_payload
            pool.submit(run_job, s, task_payload, job)
        return JSONResponse({"job_id": job["id"]}, status_code=202)

    @app.get("/api/jobs/{job_id}")
    def get_job(job_id: str, request: Request):
        s = session(request)
        if job_id not in s.jobs:
            raise HTTPException(404, "Задание не найдено.")
        return s.api._scrub(s.jobs[job_id]) if hasattr(s.api,"_scrub") else s.jobs[job_id]

    @app.middleware("http")
    async def local_headers(request, call_next):
        is_health = request.url.path == settings.prefix+"/health" and request.client and request.client.host in {"127.0.0.1", "::1"}
        if settings.server and request.url.scheme != "https" and not is_health:
            response = JSONResponse({"detail": "Для входа используйте HTTPS."}, status_code=403)
        else:
            response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'"
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, error):
        # FastAPI's default details may echo submitted passwords/API keys.
        return JSONResponse({"detail": "Некорректные параметры запроса."}, status_code=422)

    app.mount("/static", StaticFiles(directory=ROOT / "web_static"), name="static")
    return app


app = create_app()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open-browser", action="store_true")
    args = parser.parse_args()
    if args.open_browser:
        threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{args.port}")).start()
    import uvicorn
    if WebSettings.from_env().server:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    uvicorn.run(app, host="127.0.0.1", port=args.port, access_log=False,
                proxy_headers=True, forwarded_allow_ips="127.0.0.1")
