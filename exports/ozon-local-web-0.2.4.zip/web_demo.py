"""In-memory Ozon Seller API demonstration. No network or credentials."""
import copy
from decimal import Decimal
from uuid import UUID
from ozon_strategy import StrategyError

DEMO_ID = "11111111-1111-4111-8111-111111111111"
DEMO_URL = "https://www.wildberries.ru/catalog/{}/detail.aspx"

class DemoSellerAPI:
    """In-memory Seller API demonstration; no network or credentials."""

    def __init__(self, count=2):
        self.calls = []
        self.active_id = DEMO_ID
        self.strategies = {DEMO_ID: {'coefficient': 0.96, 'enabled': True, 'name': 'Shared WB', 'members': {str(i) for i in range(1, count + 1)}}}
        self.products = {str(i): {'id': i, 'sku': i * 100, 'offer_id': f'offer-{i}', 'name': f'Product {i}', 'url': DEMO_URL.format(i), 'index': '1.1', 'floor': '100', 'price': '150'} for i in range(1, count + 1)}
        self.fail_update = False
        self.reject_floor = False
        self.foreign = {}
        self.own_only = False
        self.external_only = False
        self.before_update = None
        self.fail_create = False
        self.hide_created = False
        self.create_id_field = 'id'
        self.unassigned_id = ''
        self.assignment_overrides = {}
        self.stale_members = {}
        self.enabled_to_system = True
        self.route_on_status = False
        self.product_enabled_overrides = {}

    @property
    def coefficient(self):
        return self.strategies[self.active_id]['coefficient']

    @coefficient.setter
    def coefficient(self, value):
        self.strategies[self.active_id]['coefficient'] = value

    @property
    def enabled(self):
        return self.strategies[self.active_id]['enabled']

    @enabled.setter
    def enabled(self, value):
        self.strategies[self.active_id]['enabled'] = value

    @property
    def members(self):
        return self.strategies[self.active_id]['members']

    @members.setter
    def members(self, value):
        self.strategies[self.active_id]['members'] = value

    def post(self, path, payload):
        self.calls.append((path, copy.deepcopy(payload)))
        if path.endswith('/pricing-strategy/list'):
            rows = [] if self.hide_created else [{'id': sid, 'name': s['name'], 'type': s.get('type', 'COMP_PRICE'), 'enabled': s['enabled'], 'products_count': len(s['members'] | self.stale_members.get(sid, set()))} for sid, s in self.strategies.items()]
            start = (payload['page'] - 1) * payload['limit']
            return {'strategies': rows[start:start + payload['limit']], 'total': len(rows)}
        if path.endswith('/pricing-strategy/create'):
            sid = str(UUID(int=1000 + len(self.strategies)))
            self.strategies[sid] = {'name': payload['strategy_name'], 'coefficient': payload['competitors'][0]['coefficient'], 'enabled': True, 'members': set()}
            self.active_id = sid
            if self.fail_create:
                raise StrategyError('Connection lost after create')
            return {'result': {self.create_id_field: sid}}
        if path.endswith('/pricing-strategy/info'):
            self.active_id = payload['strategy_id']
            if self.active_id not in self.strategies:
                error = StrategyError('HTTP 404: strategy not found')
                error.http_status = 404
                raise error
            return {'result': {'type': self.strategies[self.active_id].get('type', 'COMP_PRICE'), 'enabled': self.enabled, 'name': self.strategies[self.active_id]['name'], 'competitors': [{'competitor_id': 16942991, 'coefficient': self.coefficient}]}}
        if path.endswith('/products/list'):
            sid = payload['strategy_id']
            return {'result': {'product_id': sorted(self.strategies[sid]['members'] | self.stale_members.get(sid, set()))}}
        if path.endswith('/strategy-ids-by-product-ids'):
            rows = []
            for pid in payload['product_id']:
                owner = next((sid for sid, s in self.strategies.items() if pid in s['members']), self.unassigned_id)
                rows.append({'product_id': int(pid), 'strategy_id': self.assignment_overrides.get(pid, owner)})
            return {'result': {'products_info': rows}}
        if path == '/v3/product/info/list':
            return {'items': [dict(p) for key, p in self.products.items() if key in payload.get('product_id', []) or str(p['sku']) in payload.get('sku', [])]}
        if path == '/v3/product/list':
            return {'result': {'items': [{'product_id': k} for k in self.products], 'last_id': '', 'total_items': len(self.products)}}
        if path == '/v5/product/info/prices':
            return {'items': [{'product_id': int(k), 'offer_id': p['offer_id'], 'price': {'price': p['price'], 'min_price': p['floor'], 'currency_code': 'RUB'}, 'price_indexes': {'self_marketplaces_index_data': {'price_index_value': p['index']}, 'external_index_data': {'price_index_value': 0.1}}} for k, p in self.products.items() if k in payload['filter']['product_id']]}
        if path.endswith('/pricing-strategy/product/info'):
            k = str(payload['product_id'])
            owner = next((sid for sid, s in self.strategies.items() if k in s['members']), '')
            return {'result': {'strategy_id': self.foreign.get(k, owner or self.unassigned_id), 'is_enabled': self.product_enabled_overrides.get(k, bool(owner) and self.strategies[owner]['enabled']), 'strategy_competitor_product_url': '' if self.own_only or self.external_only else self.products[k]['url'], 'strategy_product_price': int(self.products[k]['price'])}}
        if path == '/v1/product/prices/details':
            return {'prices': [{'sku': str(p['sku']),
                'customer_price': {'amount': p.get('customer_price', str((Decimal(p['price'])*Decimal('.70')).quantize(Decimal('.01')))), 'currency': 'RUB'},
                'price_indexes': [{'external_index_data': {'url': p['url'], 'min_price': {'amount': '1', 'currency': 'RUB'}}}] if self.external_only else
                    [{'self_index_data': {'url': p['url'], 'min_price': {'amount': p.get('wb_price', '500'), 'currency': 'RUB'}}}]
                } for p in self.products.values() if str(p['sku']) in payload['skus']]}
        if path.endswith('/products/delete'):
            for s in self.strategies.values():
                s['members'] -= set(payload['product_id'])
            return {'result': {'failed_product_count': 0}}
        if path.endswith('/products/add'):
            self.active_id = payload['strategy_id']
            self.members |= set(payload['product_id'])
            return {'result': {'failed_product_count': 0}}
        if path == '/v1/product/import/prices':
            for p in payload['prices']:
                target = self.products[str(p['product_id'])]
                if not self.reject_floor:
                    target['floor'], target['price'] = (p['min_price'], p['price'])
                if p.get('price_strategy_enabled') == 'ENABLED' and self.enabled_to_system:
                    self.move_to_system({str(p['product_id'])})
            return {'result': [{'product_id': p['product_id'], 'updated': not self.reject_floor, 'errors': []} for p in payload['prices']]}
        if path.endswith('/pricing-strategy/status'):
            self.active_id = payload['strategy_id']
            self.enabled = payload['enabled']
            if self.enabled and self.route_on_status:
                self.move_to_system(set(self.members))
            return {}
        if path.endswith('/pricing-strategy/update'):
            self.active_id = payload['strategy_id']
            if self.before_update:
                self.before_update()
            old = Decimal(str(self.coefficient))
            self.coefficient = payload['competitors'][0]['coefficient']
            for pid in self.members:
                p = self.products[pid]
                before = Decimal(p['price'])
                after = max(Decimal(p['floor']), (before * Decimal(str(self.coefficient)) / old).quantize(Decimal('1')))
                p['price'] = str(after)
                p['index'] = str(Decimal(p['index']) * after / before)
            if self.fail_update:
                raise StrategyError('Connection lost after write')
            return {}
        raise AssertionError(path)

    def move_to_system(self, product_ids):
        system_id = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee'
        for sid, record in list(self.strategies.items()):
            if sid != system_id:
                self.stale_members.setdefault(sid, set()).update(record['members'] & product_ids)
                record['members'] -= product_ids
        system = self.strategies.setdefault(system_id, {'name': 'Удерживайте выгодную цену', 'type': 'MIN_EXT_PRICE', 'coefficient': 1, 'enabled': True, 'members': set()})
        system['members'] |= product_ids
        return system_id

def make_demo_api():
    api = DemoSellerAPI(3)
    api.unassigned_id = '00000000-0000-0000-0000-000000000000'
    api.products = {
        "2077805520": {"id": 2077805520, "sku": 2369234990, "offer_id": "Weights/grey_1",
            "name": "Утяжелители 1 кг · пример", "url": DEMO_URL.format(386265183),
            "index": "0.997", "floor": "2700", "price": "2958", "wb_price": "2068", "customer_price": "2062"},
        "1000000002": {"id": 1000000002, "sku": 425648785, "offer_id": "swim/nblue",
            "name": "Товар 2 · пример", "url": DEMO_URL.format(101231686),
            "index": "1.46", "floor": "469", "price": "700"},
        "1000000003": {"id": 1000000003, "sku": 463668384, "offer_id": "TPE/Purple-pink",
            "name": "Товар 3 · пример", "url": DEMO_URL.format(123456789),
            "index": "1.06", "floor": "1000", "price": "1500"},
    }
    api.members = {"2077805520"}
    api.strategies[DEMO_ID]["name"] = "WB · демонстрация"
    api.strategies["22222222-2222-4222-8222-222222222222"] = {
        "name": "Коврики · демонстрация", "coefficient": .95, "enabled": False, "members": set()}
    return api
