@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv-web\Scripts\python.exe" (
  py -3 -m venv .venv-web
  if errorlevel 1 python -m venv .venv-web
)
if not exist ".venv-web\Scripts\python.exe" (
  echo Install Python 3.10 or newer and run this file again.
  pause
  exit /b 1
)
".venv-web\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements-web.txt
if errorlevel 1 (
  echo Package installation failed. Check the Internet connection.
  pause
  exit /b 1
)
".venv-web\Scripts\python.exe" web_app.py --open-browser
pause
